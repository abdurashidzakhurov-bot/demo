/* =========================================================
   UY MARKET — xizmat sahifasi (service.html?s=<slug>)
   Mazmun js/services.js dan chiziladi; xizmatlar orasida
   sahifa qayta yuklanmaydi, o'rtada xizmat nomi bilan o'tish bo'ladi.
   ========================================================= */

const svcRoot = document.getElementById("svc-root");
const svcTabs = document.getElementById("svc-tabs");

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const lang = () => (SERVICE_CONTENT[document.documentElement.lang] ? document.documentElement.lang : "uz");
const icon = (d, cls = "") => `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`;
const CHECK = "M5 12.5l4.5 4.5L19 7.5";

function currentSlug() {
  const s = new URLSearchParams(location.search).get("s");
  return SERVICE_META[s] ? s : SERVICE_ORDER[0];
}

// So'zma-so'z chiqadigan sarlavha (bosh sahifadagi .word animatsiyasi bilan bir xil)
function words(text, start) {
  return text.split(/\s+/).map((w, i, a) => `<span class="word" style="--i:${start + i}">${esc(w)}${i < a.length - 1 ? " " : ""}</span>`).join("");
}

// Bo'lim sarlavhasi: konturli raqamli teg + katta sarlavha (bosh sahifadagi uslubda)
const head = (n, title, cls = "") => `<div class="svc-head reveal${cls ? " " + cls : ""}"><span class="tag-outline">${String(n).padStart(2, "0")}</span><h2 class="section-title">${esc(title)}</h2></div>`;

/* ---------- Tablar ---------- */
function renderTabs(slug) {
  const c = SERVICE_CONTENT[lang()];
  svcTabs.innerHTML = SERVICE_ORDER.map((s) => `
    <a class="svc-tab${s === slug ? " is-active" : ""}" href="service.html?s=${s}" data-svc-link="${s}"${s === slug ? ' aria-current="page"' : ""}>
      ${icon(SERVICE_META[s].icon)}<span>${esc(c[s].name)}</span>
    </a>`).join("");
  svcTabs.querySelector(".is-active")?.scrollIntoView({ block: "nearest", inline: "center" });
}

/* ---------- Bloklar ---------- */
function heroBlock(d, ui, meta) {
  const n1 = d.t1.split(/\s+/).length;
  const mini = d.stats.slice(0, 2).map(([n, suf, title]) => `
      <div><p class="svc-mini-n"><span data-count="${n}">${Number(n).toLocaleString("ru-RU")}</span>${esc(suf)}</p><p class="svc-mini-l">${esc(title)}</p></div>`).join("");
  return `
  <section class="svc-hero container">
    <div class="svc-hero-grid">
      <div class="svc-hero-panel">
        <div class="hero-grid" aria-hidden="true"></div>
        <p class="svc-crumb"><a href="index.html#services">${esc(ui.crumb)}</a><span>/</span><span>${esc(d.name)}</span></p>
        <h1 class="svc-title"><span class="muted-line">${words(d.t1, 0)}</span> <span>${words(d.t2, n1)}</span></h1>
        <p class="svc-sub reveal">${esc(d.sub)}</p>
        <div class="svc-actions reveal">
          <button class="btn btn-primary btn-lg" type="button" data-open-modal data-service="${meta.form}">${esc(ui.consult)}</button>
          <a class="btn btn-ghost btn-lg" href="#how">${esc(ui.how)}</a>
        </div>
      </div>
      <div class="svc-hero-side">
        <div class="svc-cover ph reveal">
          <img src="${meta.hero}" alt="" data-parallax>
          <span class="svc-chip svc-chip--a">${icon(CHECK)}${esc(ui.legal)}</span>
          <span class="svc-chip svc-chip--b">${icon(CHECK)}${esc(ui.verified)}</span>
        </div>
        <div class="svc-hero-stats reveal">${mini}</div>
      </div>
    </div>
  </section>`;
}

// Sarlavhaning oxirgi ikki so'zi brend ko'k rangda
function accentTitle(text) {
  const w = text.trim().split(/\s+/);
  const k = Math.min(2, Math.max(1, w.length - 1));
  return `${esc(w.slice(0, -k).join(" "))} <span class="accent">${esc(w.slice(-k).join(" "))}</span>`;
}

const STAT_ICONS = [
  "M3 3v18h18M7 14l4-4 3 3 5-6",                                   // o'sish grafigi
  "M12 7v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z",              // soat
  "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75", // odamlar
];

function aboutBlock(d, ui, meta) {
  const stat = ([n, suf, title, text], i) => `
    <article class="mi-card mi-stat reveal">
      <p class="mi-num"><span data-count="${n}">${Number(n).toLocaleString("ru-RU")}</span>${esc(suf)}</p>
      <span class="mi-icon">${icon(STAT_ICONS[i % 3])}</span>
      <h3>${esc(title)}</h3>
      <p>${esc(text)}</p>
    </article>`;
  return `
  <section class="section svc-mission">
    <div class="mi-bg" aria-hidden="true"></div>
    <div class="container">
      <div class="mi-head reveal">
        <div>
          <span class="mi-tag"><span class="mi-tag-dot">${icon("M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z")}</span>${esc(ui.about)}</span>
          <h2 class="mi-title">${accentTitle(d.aboutLead)}</h2>
        </div>
        <div class="mi-side">
          <p>${esc(d.aboutText)}</p>
          <button class="btn btn-dark btn-lg" type="button" data-open-modal data-service="${meta.form}">${esc(ui.consult)}</button>
        </div>
      </div>

      <div class="mi-grid" data-stagger>
        ${stat(d.stats[0], 0)}
        <article class="mi-card mi-feature reveal">
          <div class="mi-feature-media ph">
            <video src="assets/video/menu.mp4" poster="assets/img/menu-poster.jpg" muted loop playsinline autoplay aria-hidden="true"></video>
          </div>
          <span class="mi-icon">${icon(CHECK)}</span>
          <h3>${esc(meta.form === 'sale' ? ({uz:'Professional baholash',ru:'Профессиональная оценка',en:'Professional valuation'}[lang()] || 'Professional baholash') : ui.legal)}</h3>
          <p>${esc(d.sub)}</p>
        </article>
        ${stat(d.stats[1], 1)}
        ${stat(d.stats[2], 2)}
      </div>
    </div>
  </section>`;
}

// Izometrik chiziqli belgilar kutubxonasi. .acc — ko'k urg'u qismi, .soft — ikkinchi darajali chiziq
const WF_ICON_SET = {
  // lupa va uy: obyektni tahlil qilish
  search: '<path d="M8 36 22 23 36 36v16H8z"/><path d="M8 36h28M18 52V42h8v10" class="soft"/><circle class="acc" cx="42" cy="22" r="11"/><path d="m50 30 9 9"/>',
  // narx yorlig'i
  price: '<path d="M8 32 32 8h22v22L30 54z"/><circle class="acc" cx="44" cy="18" r="4"/><path d="M26 34 38 22M24 42l8-8" class="soft"/>',
  // karnay: reklama, marketing
  megaphone: '<path d="M8 26v12h10l22 10V16L18 26z"/><path class="acc" d="M18 26 40 16v32L18 38z"/><path d="M45 25a9 9 0 0 1 0 14M50 18a17 17 0 0 1 0 28" class="soft"/>',
  // qalamli hujjat: shartnoma, xulosa
  contract: '<path d="M12 6h26l12 12v40H12z"/><path d="M38 6v12h12M20 28h20M20 36h14M20 44h10" class="soft"/><path class="acc" d="M38 52 50 40l5 5-12 12-7 2z"/>',
  // kamera: foto va video
  camera: '<path d="M6 20h12l4-6h20l4 6h12v32H6z"/><circle cx="32" cy="35" r="10"/><circle class="acc" cx="32" cy="35" r="4.5"/><path d="M12 14h6" class="soft"/>',
  // ikkita muloqot bulutchasi: konsultatsiya, muzokara
  chat: '<path d="M6 10h34v22H22l-9 8v-8H6z"/><path class="acc" d="M24 28h34v22h-7v8l-9-8H24z"/><path d="M14 18h18M14 24h10" class="soft"/>',
  // qalqon va belgi: yuridik nazorat
  legal: '<path d="M32 5 54 13v18c0 14-10 22-22 27C20 53 10 45 10 31V13z"/><path class="acc-l" d="m21 31 8 8 15-16"/>',
  // nishon: strategiya
  target: '<circle cx="30" cy="34" r="22"/><circle cx="30" cy="34" r="13" class="soft"/><circle class="acc" cx="30" cy="34" r="5"/><path d="M34 30 56 8M48 6h10v10"/>',
  // raketa: start
  rocket: '<path d="M32 4c11 8 14 22 11 38L32 52 21 42C18 26 21 12 32 4z"/><circle class="acc" cx="32" cy="24" r="6"/><path d="M21 42 10 50h11M43 42l11 8H43M27 52l5 8 5-8" class="soft"/>',
  // ustunlar diagrammasi: monitoring, bozor tahlili, hisobot
  chart: '<path d="M6 56h52"/><path d="M12 56V40h10v16M27 56V28h10v28" /><path class="acc" d="M42 56V14h10v42z"/><path d="m12 32 15-12 12 4 15-14" class="soft"/>',
  // bank binosi
  bank: '<path class="acc" d="m6 24 26-17 26 17z"/><path d="M13 29v19M26 29v19M38 29v19M51 29v19M6 54h52M10 48h44"/>',
  // hujjatlar to'plami
  docs: '<path d="M22 6h24v38" class="soft"/><path d="M10 14h26l10 10v34H10z"/><path class="acc" d="M36 14v10h10z"/><path d="M18 34h20M18 42h20M18 50h12" class="soft"/>',
  // kalit: bitim yakuni, topshirish
  key: '<circle cx="21" cy="23" r="13"/><circle class="acc" cx="21" cy="23" r="4.5"/><path d="m31 33 25 25M46 48l7-7M53 55l6-6"/>',
  // yozuv taxtasi: ariza
  clipboard: '<path d="M14 12h36v46H14z"/><path class="acc" d="M23 6h18v10H23z"/><path d="M22 28h20M22 36h20M22 44h12" class="soft"/>',
  // uy va chizg'ich: joyida ko'rik
  inspect: '<path d="M6 36 24 20l18 16v20H6z"/><path d="M18 56V44h12v12" class="soft"/><path class="acc" d="m48 4 12 12-8 8-12-12z"/><path d="m46 10 2.5 2.5M50.5 5.5 53 8" class="soft"/>',
  // qog'oz samolyot: joylashtirish
  send: '<path d="M58 6 6 28l20 8 8 20z"/><path class="acc" d="M26 36 58 6 34 56z"/><path d="m26 36 8 4" class="soft"/>',
};

// Har bir xizmatning 4 ta bosqichi uchun belgilar: bosqich matniga mos
const STEP_ICONS = {
  ijara:       ["search", "price", "megaphone", "contract", "key"],
  sotuv:       ["price", "megaphone", "chat", "legal"],
  novostroyka: ["search", "target", "rocket", "chart"],
  ipoteka:     ["chat", "bank", "docs", "key"],
  baholash:    ["clipboard", "inspect", "chart", "contract"],
  reklama:     ["search", "camera", "send", "chart"],
};

function stepsBlock(d, ui, meta, slug) {
  return `
  <section class="section" id="how">
    <div class="container">
      <div class="wf-head reveal">
        <h2 class="section-title"><i>/</i> ${esc(ui.how)} <i>/</i></h2>
        <button class="btn btn-dark" type="button" data-open-modal data-service="${meta.form}">${esc(ui.consult)}</button>
      </div>
      <div class="wf${d.steps.length === 5 ? " wf-five" : ""}" data-stagger>
        ${d.steps.map(([title, text], i) => `
          <article class="wf-cell reveal${i === 0 ? " is-active" : ""}" data-step="${i}" tabindex="0" aria-label="${esc(title)}">
            <span class="wf-n">// ${String(i + 1).padStart(3, "0")}</span>
            <p class="wf-text">${esc(text)}</p>
            <div class="wf-bar" aria-hidden="true"><span></span></div>
            <div class="wf-foot">
              <h3>${esc(title)}</h3>
              <svg class="wf-icon" viewBox="0 0 64 64" aria-hidden="true">${WF_ICON_SET[(STEP_ICONS[slug] || STEP_ICONS.ijara)[i % (STEP_ICONS[slug] || STEP_ICONS.ijara).length]]}</svg>
            </div>
          </article>`).join("")}
      </div>
    </div>
  </section>`;
}

// Har bir xizmat uchun 3D sahnalar: [chap karta (kimlar uchun / muammo), o'ng karta (afzalliklar)]
const SERVICE_SCENES = {
  ijara:       ["rentTypes", "rentKey"],
  sotuv:       ["shield", "soldHouse"],
  novostroyka: ["towersDown", "towers"],
  ipoteka:     ["family", "mortgage"],
  baholash:    ["docsStack", "appraisal"],
  reklama:     ["people", "phoneAds"],
};

function duoBlock(d, meta, ui, slug) {
  const [left, right] = d.blocks;
  const problem = meta.duo === "problem";
  const li = (it, kind) => {
    const mark = kind === "x" ? icon("M6 6l12 12M18 6 6 18") : kind === "dot" ? '<i class="dot"></i>' : icon(CHECK);
    return `<li class="${kind}">${mark}<span>${esc(it)}</span></li>`;
  };
  const [n, suf, statTitle] = d.stats[0];

  const [s1, s2] = [d.stats[1], d.stats[2]].filter(Boolean);
  const ico = (path) => `<span class="duo-chip">${icon(path)}</span>`;
  const banner = [s1, s2].filter(Boolean).map(([bn, bs, bt, btx], i) => `
      <div class="duo-stat ${i ? "is-gray" : "is-blue"}">
        <p class="duo-stat-n"><span data-count="${bn}">${Number(bn).toLocaleString("ru-RU")}</span>${esc(bs)}</p>
        <div><h4>${esc(bt)}</h4><p>${esc(btx)}</p></div>
      </div>`).join("");

  return `
  <section class="section container">
    <div class="duo" data-stagger>
      <div class="duo-card is-left reveal">
        ${ico(problem ? "M6 6l12 12M18 6 6 18" : "M12 8v5M12 16.5v.01M10.3 3.9 2.6 17.5A2 2 0 0 0 4.3 20.5h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z")}
        <h3>${esc(left[0])}</h3>
        <div class="duo-panel">
          <ul>${left[1].map((it) => li(it, problem ? "x" : "dot")).join("")}</ul>
        </div>
      </div>

      <div class="duo-card is-mid reveal">
        <div class="duo-big">
          <div class="duo-bars" aria-hidden="true">${[34, 48, 42, 62, 56, 78, 94].map((h, i) => `<i style="--h:${h}%;--i:${i}"></i>`).join("")}</div>
          <span class="dd-ico">${icon("M3 3v18h18M7 14l4-4 3 3 5-6")}</span>
          <p class="duo-big-n"><span data-count="${n}">${Number(n).toLocaleString("ru-RU")}</span>${esc(suf)}</p>
          <p class="duo-big-t">${esc(statTitle)}</p>
          ${banner ? `<div class="duo-mini">${[s1, s2].filter(Boolean).map(([bn, bs, bt, btx]) => `<div><b><span data-count="${bn}">${Number(bn).toLocaleString("ru-RU")}</span>${esc(bs)}</b><span><strong>${esc(bt)}</strong><em>${esc(btx)}</em></span></div>`).join("")}</div>` : ""}
        </div>
      </div>

      <div class="duo-card is-right reveal">
        ${ico(CHECK)}
        <h3>${esc(right[0])}</h3>
        <div class="duo-panel">
          <ul>${right[1].map((it) => li(it, "check")).join("")}</ul>
          <button class="btn btn-primary btn-lg duo-cta" type="button" data-open-modal data-service="${meta.form}">${esc(ui.consult)}</button>
        </div>
      </div>
    </div>
  </section>`;
}

function faqBlock(d, ui, meta) {
  return `
  <section class="section">
    <div class="container faq-layout">
      <div class="faq-aside reveal">
        <h2 class="section-title">${esc(ui.faq)}</h2>
        <div class="faq-help">
          <p class="faq-help-title">${esc(window.t("faq.helpT"))}</p>
          <p>${esc(window.t("faq.helpD"))}</p>
          <button class="btn btn-dark btn-sm" type="button" data-open-modal data-service="${meta.form}">${esc(window.t("faq.helpBtn"))}</button>
        </div>
      </div>
      <div class="faq">
        ${d.faq.map(([q, a], i) => `
          <div class="faq-item reveal${i === 0 ? " is-open" : ""}">
            <button class="faq-q" type="button" aria-expanded="${i === 0}"><span class="faq-n">0${i + 1}</span><span>${esc(q)}</span><i class="faq-icon" aria-hidden="true"></i></button>
            <div class="faq-a"><p>${esc(a)}</p></div>
          </div>`).join("")}
      </div>
    </div>
  </section>`;
}

/* ---------- Har bir xizmatga xos qo'shimcha blok ---------- */
const deckCard = () => {
  if (!window.DECK) return "";
  const l = window.DECK.lang(), u = window.DECK.texts[l].ui, n = window.DECK.count;
  const fan = [[1, "fan-b"], [4, "fan-c"], [0, "fan-a"]];
  return `
    <div class="deck-card reveal">
      <div class="deck-card-text">
        <span class="deck-chip-live"><i></i>${esc(u.tag)}</span>
        <h3>${esc(u.cardTitle)}</h3>
        <p>${esc(u.cardText)}</p>
        <div class="deck-facts"><span><b>${n}</b> ${esc(u.page.toLowerCase())}</span><span><b>4</b> ${l === "ru" ? "языка" : l === "en" ? "languages" : l === "zh" ? "种语言" : "til"}</span><span><b>PDF</b></span></div>
        <div class="deck-actions-row">
          <button type="button" class="btn btn-white btn-lg" data-open-deck>${esc(u.cardBtn)}${icon("M9 6l6 6-6 6")}</button>
          <a class="deck-dl" href="${window.DECK.pdfHref(l)}" download>${icon("M12 4v11M7 11l5 5 5-5M5 20h14")}<span>${esc(u.pdf)}</span></a>
        </div>
      </div>
      <div class="deck-fan" data-open-deck aria-hidden="true">
        ${fan.map(([i, cls]) => `<div class="deck-card-thumb ${cls}"><div class="deck-slide-in">${window.DECK.html(i)}</div></div>`).join("")}
      </div>
    </div>`;
};

/* Baholash omillari: kartochka illyustratsiyalari (240×130) */
const FACTOR_ART = [
  // 01 Joylashuv — xarita, marker va yaqin obyektlar halqalari
  `<svg viewBox="0 0 240 130"><g fill="none" stroke="#C9D7EA" stroke-width="1"><path d="M0 36h240M0 78h240M0 112h240M44 0v130M104 0v130M168 0v130M214 0v130"/></g>
   <circle class="fa-ring" cx="120" cy="66" r="52" fill="none" stroke="#215FC1" stroke-opacity=".18"/><circle class="fa-ring fa-ring2" cx="120" cy="66" r="34" fill="none" stroke="#215FC1" stroke-opacity=".3"/>
   <g fill="#fff" stroke="#215FC1" stroke-width="2"><circle cx="64" cy="40" r="7"/><circle cx="178" cy="92" r="7"/><circle cx="188" cy="36" r="7"/></g>
   <g fill="#215FC1"><circle cx="64" cy="40" r="2.5"/><circle cx="178" cy="92" r="2.5"/><circle cx="188" cy="36" r="2.5"/></g>
   <path class="fa-pin" d="M120 94s-18-17-18-31a18 18 0 0 1 36 0c0 14-18 31-18 31z" fill="#215FC1"/><circle class="fa-pin" cx="120" cy="63" r="6.5" fill="#fff"/></svg>`,
  // 02 Maydon va planirovka — reja va o'lcham chizig'i
  `<svg viewBox="0 0 240 130"><rect x="46" y="22" width="148" height="84" rx="4" fill="#fff" stroke="#173F94" stroke-width="2.4"/>
   <g class="fa-d" fill="none" stroke="#173F94" stroke-width="2.4" stroke-linecap="round"><path pathLength="1" d="M114 22v36M46 62h46M114 80v26M150 62h44"/></g>
   <g fill="none" stroke="#215FC1" stroke-width="1.6"><path pathLength="1" class="fa-d" d="M92 62a14 14 0 0 1 14-14M150 62a14 14 0 0 0-14 18"/></g>
   <rect x="52" y="28" width="56" height="28" fill="#D9E8FA"/><rect x="120" y="28" width="68" height="28" fill="#EDF4FD"/><rect x="120" y="68" width="68" height="32" fill="#D9E8FA"/>
   <g stroke="#1884CA" stroke-width="1.6" fill="none" stroke-linecap="round"><path d="M46 118h148M46 113v10M194 113v10"/></g><text x="120" y="127" font-size="9" fill="#1884CA" text-anchor="middle" font-family="Helvetica Neue, Arial">m²</text></svg>`,
  // 03 Qavat va bino — qavatlar va lift
  `<svg viewBox="0 0 240 130"><rect x="76" y="14" width="88" height="106" rx="4" fill="#fff" stroke="#173F94" stroke-width="2.4"/>
   <g fill="#D9E8FA">${[0,1,2,3].map((r)=>[0,1,2].map((c)=>`<rect x="${84+c*26}" y="${22+r*24}" width="18" height="14" rx="2"/>`).join("")).join("")}</g>
   <rect class="fa-hl" x="84" y="70" width="70" height="14" rx="2" fill="#215FC1" opacity=".9"/>
   <rect x="108" y="100" width="24" height="20" rx="2" fill="#173F94"/>
   <g fill="none" stroke="#215FC1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M188 96V34M180 42l8-8 8 8"/></g><circle cx="188" cy="104" r="3" fill="#215FC1"/></svg>`,
  // 04 Ta'mir holati — devor, valik
  `<svg viewBox="0 0 240 130"><rect x="40" y="22" width="150" height="86" rx="6" fill="#EDF4FD"/>
   <rect class="fa-paint" x="40" y="22" width="96" height="86" rx="6" fill="#215FC1" opacity=".85"/>
   <g class="fa-roll"><rect x="112" y="30" width="62" height="20" rx="6" fill="#fff" stroke="#173F94" stroke-width="2.4"/><path d="M174 40h14v28h-34v10" fill="none" stroke="#173F94" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><rect x="148" y="78" width="12" height="30" rx="4" fill="#173F94"/></g>
   <g fill="#fff" opacity=".7"><circle cx="64" cy="48" r="2"/><circle cx="92" cy="74" r="2"/><circle cx="70" cy="92" r="2"/></g></svg>`,
  // 05 Hujjatlar — varaqlar va tasdiq
  `<svg viewBox="0 0 240 130"><rect x="84" y="20" width="84" height="98" rx="6" fill="#D9E8FA" transform="rotate(7 126 69)"/>
   <rect x="70" y="14" width="88" height="104" rx="6" fill="#fff" stroke="#173F94" stroke-width="2.4"/>
   <g class="fa-d" fill="none" stroke="#9AA9C2" stroke-width="3" stroke-linecap="round"><path pathLength="1" d="M84 38h38M84 52h60M84 66h52"/></g>
   <circle class="fa-stamp" cx="148" cy="92" r="20" fill="#215FC1"/><path class="fa-stamp" d="M138 92l7 7 12-14" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  // 06 Bozor talabi — ustunlar va o'sish chizig'i
  `<svg viewBox="0 0 240 130"><g stroke="#C9D7EA"><path d="M30 112h180M30 82h180M30 52h180"/></g>
   <g fill="#D9E8FA"><rect class="fa-bar" x="44" y="84" width="22" height="28" rx="4"/><rect class="fa-bar" style="--i:1" x="80" y="70" width="22" height="42" rx="4"/><rect class="fa-bar" style="--i:2" x="116" y="56" width="22" height="56" rx="4"/></g>
   <rect class="fa-bar" style="--i:3" x="152" y="38" width="22" height="74" rx="4" fill="#215FC1"/><rect class="fa-bar" style="--i:4" x="188" y="26" width="22" height="86" rx="4" fill="#173F94"/>
   <path class="fa-d" pathLength="1" d="M40 74l38-16 38-12 36-20 44-12" fill="none" stroke="#1884CA" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle class="fa-stamp" cx="200" cy="14" r="5" fill="#1884CA"/></svg>`,
];

/* Portfolio kartochkasi: rasm ustida nom, sotuv egri chizig'i, vaqt shkalasi va ko'rsatkichlar */
const pfIdx = (ym) => { const [y, m] = ym.split("-").map(Number); return y * 12 + m - 1; };
function pfCard(p) {
  const f = portfolioFacts(p, lang()), L = f.labels;
  const s0 = Math.min(...PORTFOLIO.map((x) => pfIdx(x.start)));
  const e0 = Math.max(...PORTFOLIO.map((x) => pfIdx(x.start) + x.months));
  const span = e0 - s0;
  const left = ((pfIdx(p.start) - s0) / span) * 100, width = (p.months / span) * 100;
  const yrs = []; for (let y = Math.ceil(s0 / 12); y * 12 <= e0; y++) yrs.push([((y * 12 - s0) / span) * 100, y]);
  // S-shaklidagi jamlanma sotuv egri chizig'i (units asosida)
  const pts = Array.from({ length: 13 }, (_, i) => { const t = i / 12, v = t * t * (3 - 2 * t) * 0.55 + t * 0.45; return [t * 120, 34 - v * 30]; });
  const line = pts.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`).join("");
  const [avgU, avgS] = f.avg.split(" · ");
  return `
        <article class="svc-project reveal">
          <div class="svc-project-img ph">
            <img src="${p.img}" alt="${esc(p.name)}" loading="lazy">
            <span class="pf-badge">${esc(f.months)}</span>
            <div class="pf-cap"><h3>${esc(p.name)}</h3><p class="svc-project-area">${esc(f.area)}</p></div>
          </div>
          <div class="pf-key">
            <div><span>${esc(L.turnover)}</span><strong>${esc(f.turnover)}</strong></div>
            <svg viewBox="0 0 120 38" preserveAspectRatio="none" aria-hidden="true"><path class="pf-area" d="${line}L120 38L0 38Z"/><path class="pf-line" pathLength="1" d="${line}"/><circle cx="120" cy="${pts[12][1].toFixed(1)}" r="2.6"/></svg>
          </div>
          <div class="pf-tl" title="${esc(f.period)}">
            <div class="pf-tl-bar"><i style="left:${left.toFixed(1)}%;width:${width.toFixed(1)}%"></i>${yrs.map(([x]) => `<u style="left:${x.toFixed(1)}%"></u>`).join("")}</div>
            <div class="pf-tl-yrs">${yrs.map(([x, y]) => `<span style="left:${x.toFixed(1)}%">${y}</span>`).join("")}</div>
            <p><b>${esc(L.period)}</b> ${esc(f.period)}</p>
          </div>
          <div class="pf-tiles">
            <div><b>${p.units}</b><span>${esc(L.unit)}</span></div>
            <div><b>${esc(avgU.split(" ")[0])}</b><span>${esc(L.unit)} / ${esc(L.mo)}</span></div>
            <div><b>${esc(avgS.split(" ")[0])}</b><span>${esc(avgS.split(" ").slice(1).join(" "))} / ${esc(L.mo)}</span></div>
          </div>
        </article>`;
}

/* Shartnoma bandlari ikonkalari: taraflar, to'lov, depozit, kommunal, muddat, jihozlar, bekor qilish, javobgarlik */
const CLAUSE_ICONS = [
  "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8",
  "M2 6h20v13H2zM2 10h20M6 15h4",
  "M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6zM9 12l2 2 4-4",
  "M13 2 4 14h7l-1 8 9-12h-7z",
  "M3 5h18v16H3zM3 10h18M8 3v4M16 3v4",
  "M4 10V7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3M2 14a2 2 0 0 1 2-2 2 2 0 0 1 2 2v1h12v-1a2 2 0 0 1 2-2 2 2 0 0 1 2 2v5H2zM6 19v2M18 19v2",
  "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5M9.5 13.5l5 5M14.5 13.5l-5 5",
  "M12 3v18M5 7h14M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0zM8 21h8",
];

const EXTRAS = {
  checklist: (d, ui) => {
    const T = { uz: ["Ijara shartnomasi", "Namunaviy shakl · PDF · 2 sahifa", "Shartnomani yuklab olish", "Hujjatda quyidagilar bor", "Shartnoma bandlari", "Ijaraga beruvchi", "Ijarachi", "Oylik toʻlov", "Depozit", "Muddat"], ru: ["Договор аренды", "Образец · PDF (на узбекском)", "Скачать договор", "В документе есть", "Пункты договора", "Наймодатель", "Наниматель", "Аренда в месяц", "Депозит", "Срок"], en: ["Lease agreement", "Sample form · PDF (in Uzbek)", "Download the agreement", "The document covers", "Agreement clauses", "Landlord", "Tenant", "Monthly rent", "Deposit", "Term"] }[lang()];
    return `
  <section class="section container">
    <div class="svc-checklist">
      ${head(d.checklist.length, ui.checklistTitle)}
      <div class="doc-split">
        <div class="doc-side reveal">
          <div class="doc-stage" aria-hidden="true">
            <div class="ds-glow"></div>
            <svg class="ds-house" viewBox="0 0 120 70"><path d="M4 66V32L30 12l26 20v34M56 66V40h22v26M78 66V22l22-12 18 12v44"/></svg>
            <div class="doc-paper">
              <div class="doc-pg back"></div>
              <div class="doc-pg mid"></div>
              <div class="doc-pg">
                <div class="dp-top"><b><i></i>UY MARKET</b><span>NAMUNA</span></div>
                <p class="dp-h">${esc(T[0])}</p>
                <p class="dp-sub">№ ____ &nbsp;·&nbsp; Andijon sh.</p>
                <div class="dp-parties"><div><small>${esc(T[5])}</small><i class="dp-l w9"></i></div><div><small>${esc(T[6])}</small><i class="dp-l w8"></i></div></div>
                ${d.checklist.slice(0, 4).map((it, i) => `<div class="dp-row"><em>${i + 1}</em><span>${esc(it)}</span></div>`).join("")}
                <i class="dp-l w9"></i><i class="dp-l w6"></i>
                <div class="dp-sig"><div><span class="sg1"></span><small>${esc(T[5])}</small></div><div><span class="sg2"></span><small>${esc(T[6])}</small></div></div>
                <u class="dp-stamp">${icon(CHECK)}</u>
              </div>
              <svg class="ds-pen" viewBox="0 0 24 24"><path d="M3 21l3.5-1 12-12a2.1 2.1 0 0 0-3-3l-12 12zM14 6l3 3"/></svg>
            </div>
            <span class="ds-chip c1">${icon("M2 6h20v13H2zM2 10h20M6 15h4")}${esc(T[7])}</span>
            <span class="ds-chip c2">${icon("M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6zM9 12l2 2 4-4")}${esc(T[8])}</span>
            <span class="ds-chip c3">${icon("M3 5h18v16H3zM3 10h18M8 3v4M16 3v4")}${esc(T[9])}</span>
            <svg class="ds-key" viewBox="0 0 40 70"><circle cx="20" cy="14" r="9"/><circle cx="20" cy="14" r="3"/><path d="M20 23v40M20 44h9M20 56h7"/></svg>
          </div>
          <div class="doc-meta">
            <h3>${esc(T[0])}</h3>
            <p>${esc(T[1])}</p>
            <a class="btn btn-primary btn-lg" href="assets/docs/ijara-shartnomasi-namuna.pdf" download="uy-market-ijara-shartnomasi-namuna.pdf">${icon("M12 4v11M7 11l5 5 5-5M5 20h14")}<span>${esc(T[2])}</span></a>
          </div>
        </div>
        <div class="doc-list">
          <p class="doc-list-t">${esc(T[3])}</p>
          <ol class="svc-check-list is-icons" data-stagger>
            ${d.checklist.map((it, i) => `<li class="reveal"><span class="svc-check-n">${String(i + 1).padStart(2, "0")}</span>${icon(CLAUSE_ICONS[i % CLAUSE_ICONS.length])}<span>${esc(it)}</span></li>`).join("")}
          </ol>
        </div>
      </div>
    </div>
  </section>`;
  },

  compare: (d, ui) => {
    const CI = ["M20 12V8H6a2 2 0 0 1 0-4h12v4M4 6v12a2 2 0 0 0 2 2h14v-4M18 12a2 2 0 0 0 0 4h4v-4z", "M3 11v2a1 1 0 0 0 1 1h3l5 4V6L7 10H4a1 1 0 0 0-1 1zM16 9a4 4 0 0 1 0 6", "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9", "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z", "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5M9 14l2 2 4-4", "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2"];
    const last = d.compare[d.compare.length - 1];
    const L = { uz: ["Sizning yoʻlingiz", "UY MARKET bilan", "Sotuv muddati", "Boshlash", "Koʻproq xavf", "oy", "Sotildi", "Sotuv davom etadi"], ru: ["Ваш путь", "С UY MARKET", "Срок продажи", "Начать", "Больше рисков", "мес.", "Продано", "Продажа продолжается"], en: ["Your way", "With UY MARKET", "Time to sell", "Get started", "More risk", "mo", "Sold", "Still selling"] }[lang()];
    return `
  <section class="section container cmp-sec">
    ${head(d.compare.length, ui.compareTitle, "is-wide")}
    <div class="cmpx reveal">
      <div class="cmpx-head">
        <span></span>
        <div class="cmpx-h is-self"><i>${icon("M6 6l12 12M18 6 6 18")}</i><b>${esc(ui.compareSelf)}</b><em>${esc(L[4])}</em></div>
        <div class="cmpx-h is-us"><img src="assets/img/logo.png" alt=""><b>${esc(ui.compareUs)}</b><em>${icon(CHECK)}</em></div>
      </div>
      ${d.compare.map(([k, a, b], i) => `
      <div class="cmpx-row" style="--i:${i}">
        <div class="cmpx-k"><span>${icon(CI[i % CI.length])}</span><b>${esc(k)}</b></div>
        <div class="cmpx-a"><i>${icon("M6 6l12 12M18 6 6 18")}</i><span>${esc(a)}</span></div>
        <div class="cmpx-b"><i>${icon(CHECK)}</i><span>${esc(b)}</span></div>
      </div>`).join("")}
      <div class="cmpx-time">
        <p>${esc(L[2])}</p>
        <div class="tl">
          <div class="tl-lane is-self"><span class="tl-who">${esc(ui.compareSelf)}</span><div class="tl-track"><u class="tl-fill"></u><em class="tl-open">${esc(L[7])}<i>${icon("M5 12h14M13 6l6 6-6 6")}</i></em></div><b class="tl-res">${esc(last[1])}</b></div>
          <div class="tl-lane is-us"><span class="tl-who">${esc(ui.compareUs)}</span><div class="tl-track"><u class="tl-fill"></u><em class="tl-done">${icon(CHECK)}${esc(L[6])}</em></div><b class="tl-res">${esc(last[2])}</b></div>
          <div class="tl-axis" aria-hidden="true">${[0, 1, 2, 3, 4, 5, 6].map((n) => `<span>${n === 6 ? "6+" : n}${n === 0 ? "" : ""}</span>`).join("")}<small>${esc(L[5])}</small></div>
        </div>
      </div>
      <div class="cmpx-foot"><button class="btn btn-white btn-lg" type="button" data-open-modal data-service="sale">${esc(L[3])}${icon("M9 6l6 6-6 6")}</button></div>
    </div>
  </section>`;
  },

  portfolio: (d, ui) => `
  <section class="section container">
    ${head(PORTFOLIO.length, ui.portfolio)}
    <div class="svc-portfolio" data-stagger>
      ${PORTFOLIO.map((p) => pfCard(p)).join("")}
    </div>
  </section>
  <section class="section container">
    ${head(d.advantages.length, ui.advantages)}
    ${deckCard()}
  </section>`,

  calculator: (d, ui) => `
  <section class="section container">
    <div class="svc-calc reveal" data-calc>
      <div class="svc-calc-form">
        <h2 class="section-title">${esc(ui.calcTitle)}</h2>
        <div class="calc-price">
          <label for="calc-price">${esc(ui.calcPrice)}</label>
          <div class="svc-money"><span aria-hidden="true">$</span><input id="calc-price" type="text" name="price" inputmode="numeric" autocomplete="off" value="60 000"></div>
          <div class="svc-presets" role="group">${[30000, 50000, 80000, 120000].map((v) => `<button type="button" data-preset="${v}">$${String(v).replace(/\B(?=(\d{3})+(?!\d))/g, " ")}</button>`).join("")}</div>
        </div>
        <div class="svc-terms">
          ${[["down", ui.calcDown, 20, 70, 1, 30, "%"], ["years", ui.calcYears, 1, 20, 1, 15, ""], ["rate", ui.calcRate, 10, 30, 0.5, 22, "%"]].map(([k, label, min, max, step, val, u]) => `
          <label class="svc-range">
            <span class="svc-range-head"><span>${esc(label)}</span><output data-out="${k}"></output></span>
            <input type="range" name="${k}" min="${min}" max="${max}" step="${step}" value="${val}">
            <span class="svc-minmax"><i>${min}${u}</i><i>${max}${u || (k === "years" ? " " + esc(ui.calcYearsUnit) : "")}</i></span>
          </label>`).join("")}
        </div>
      </div>
      <div class="svc-calc-result">
        <p class="svc-calc-label">${esc(ui.calcMonthly)}</p>
        <p class="svc-calc-main" data-res="monthly" data-unit="${esc(ui.calcPerMonth)}">—</p>
        <div class="svc-split" aria-hidden="true"><i class="s-down"></i><i class="s-loan"></i><i class="s-int"></i></div>
        <ul class="svc-legend">
          <li><i class="s-down"></i><span>${esc(ui.calcDown)}</span><b data-res="downv">—</b></li>
          <li><i class="s-loan"></i><span>${esc(ui.calcLoan)}</span><b data-res="loan">—</b></li>
          <li><i class="s-int"></i><span>${esc(ui.calcOver)}</span><b data-res="over">—</b></li>
        </ul>
        <p class="svc-calc-total"><span>${esc(ui.calcTotal)}</span><strong data-res="total">—</strong></p>
        <p class="svc-calc-note">${esc(ui.calcNote)}</p>
        <button class="btn btn-white btn-lg" type="button" data-open-modal data-service="mortgage">${esc(ui.consult)}</button>
      </div>
    </div>
  </section>`,

  factors: (d, ui) => `
  <section class="section container">
    ${head(d.factors.length, ui.factorsTitle)}
    <div class="svc-factors" data-stagger>
      ${d.factors.map(([title, text], i) => `
        <div class="svc-factor reveal">
          <div class="factor-art" aria-hidden="true">${FACTOR_ART[i] || ""}<span class="svc-factor-n">0${i + 1}</span></div>
          <h3>${esc(title)}</h3><p>${esc(text)}</p>
        </div>`).join("")}
    </div>
  </section>`,

  pricing: (d, ui) => {
    const P = AD_PLANS[lang()];
    return `
  <section class="section container ad-plans">
    <div class="section-head reveal">
      <h2 class="section-title">${esc(ui.pricingTitle)}</h2>
      <div class="svc-switch ad-tabs" role="tablist">
        ${[["telegram", "m22 3-20 8 7 2 2 7 4-5 5 4z"], ["instagram", "M7.5 3h9A4.5 4.5 0 0 1 21 7.5v9a4.5 4.5 0 0 1-4.5 4.5h-9A4.5 4.5 0 0 1 3 16.5v-9A4.5 4.5 0 0 1 7.5 3zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM17.4 6.6h.01"], ["website", "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"]].map(([k, path], i) => `
        <button type="button" class="${i === 0 ? "is-active" : ""}" data-platform="${k}" role="tab">${icon(path)}<span>${esc(P.tabs[k])}</span></button>`).join("")}
      </div>
    </div>
    <div class="ad-bannerbox">${adBanner("telegram")}</div>
    <div class="ad-actions" id="ad-actions">${adActions("telegram")}</div>
    <div class="ad-panel" data-stagger>${adPanel("telegram", ui)}</div>
    <p class="svc-price-note reveal">${esc(ui.pricingNote)}</p>
  </section>`;
  },
};

const AD_ICONS = {
  telegram: "m22 3-20 8 7 2 2 7 4-5 5 4z",
  instagram: "M7.5 3h9A4.5 4.5 0 0 1 21 7.5v9a4.5 4.5 0 0 1-4.5 4.5h-9A4.5 4.5 0 0 1 3 16.5v-9A4.5 4.5 0 0 1 7.5 3zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM17.4 6.6h.01",
  website: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",
};
const AD_PNG = (k) => `assets/ads/uy-market-reklama-${k}.png?v=20261101-brand-rates`;

// Prepare PNG files before a click so native file sharing retains user activation.
const adShareFiles = new Map();
function prepareAdFile(platform) {
  const existing = adShareFiles.get(platform);
  if (existing) return existing.promise;
  const entry = { file: null, promise: null };
  entry.promise = fetch(AD_PNG(platform)).then(response => {
    if (!response.ok) throw new Error("PNG download failed");
    return response.blob();
  }).then(blob => {
    entry.file = new File([blob], `uy-market-reklama-${platform}.png`, {type: "image/png"});
    return entry.file;
  }).catch(error => { adShareFiles.delete(platform); throw error; });
  adShareFiles.set(platform, entry);
  return entry.promise;
}

function adActions(platform) {
  prepareAdFile(platform).catch(() => {});
  const P = AD_PLANS[lang()];
  return `
    <a class="ad-act" href="${AD_PNG(platform)}" download="uy-market-reklama-${platform}.png" data-ad-dl>${icon("M12 4v11M7 11l5 5 5-5M5 20h14")}<span>${esc(P.dlPng)}</span></a>
    <button class="ad-act is-main" type="button" data-ad-share="${platform}">${icon("M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M16 6l-4-4-4 4M12 2v14")}<span>${esc(P.sharePng)}</span></button>
    <button class="ad-act" type="button" data-open-payment>${icon("M3 5h18v14H3zM3 9h18M7 14h4")}<span>${esc(({uz:"Bank kartasi",ru:"Банковская карта",en:"Bank card"})[lang()])}</span></button>
    <span class="ad-act-hint" id="ad-hint" role="status" aria-live="polite" hidden></span>`;
}
function adBanner(platform) {
  const L = AD_LINKS[platform], B = AD_PLANS[lang()].banner[platform];
  return `
    <a class="ad-banner is-${platform}" href="${esc(L.url)}" target="_blank" rel="noopener" style="--img:url('${new URL(L.img, document.baseURI).href}');--pos:${L.pos}">
      <span class="ad-banner-ico">${icon(AD_ICONS[platform])}</span>
      <span class="ad-banner-text"><strong>${esc(B.title)}</strong><em>${esc(B.sub)}</em></span>
      <span class="ad-banner-btn">${esc(B.btn)}${icon("M7 17 17 7M8 7h9v9")}</span>
    </a>`;
}

const fmtSum = (n) => n.toLocaleString("ru-RU");
const adCheck = (items) => `<ul class="ad-list">${items.map((t) => `<li>${icon(CHECK)}<span>${esc(t)}</span></li>`).join("")}</ul>`;
const adBtn = (ui, cls = "btn-dark") => `<button class="btn ${cls} btn-sm" type="button" data-open-modal data-service="ads">${esc(ui.order)}</button>`;

function tgRateTable(rates, ui, P) {
  return `<table class="ad-newbuild-table"><thead><tr><th>${esc(({uz:"Eʼlonlar soni",ru:"Количество",en:"Listings"})[lang()])}</th><th>${esc(({uz:"Jami narx",ru:"Стоимость",en:"Total price"})[lang()])}</th></tr></thead><tbody>${rates.map(([n, price]) => `<tr><td><span class="newbuild-count">${n}</span><span class="newbuild-times">${esc(ui.perTimes)}</span></td><td><strong>${fmtSum(price)}</strong> <small>${esc(ui.currency)}</small>${n > 1 ? `<span class="newbuild-saving">−${new Intl.NumberFormat(lang(), {maximumFractionDigits:1}).format((1-price/(rates[0][1]*n))*100)}% ${esc(P.tg.qty.save)}</span>` : ""}</td></tr>`).join("")}</tbody></table>`;
}

function adPanel(platform, ui) {
  const P = AD_PLANS[lang()], cur = esc(ui.currency);
  if (platform === "telegram") {
    const Q = P.tg.qty, first = AD_PRICES.telegram[0];
    return `
    <div class="ad-grid ad-grid-3 tg-row">
      <article class="ad-card ad-home-services reveal">
        <span class="ad-chip">Telegram</span>
        <h3>${esc(({uz:"Uylar reklamasi",ru:"Реклама жилья",en:"Property advertising"})[lang()])}</h3>
        ${tgRateTable(AD_PRICES.telegram, ui, P)}
        <h4 class="ad-service-heading">${esc(({uz:"Xizmatlar reklamasi",ru:"Реклама услуг",en:"Service advertising"})[lang()])}</h4>
        ${tgRateTable(AD_PRICES.telegramServices, ui, P)}
        ${adBtn(ui)}
      </article>
      <article class="ad-card ad-newbuild reveal">
        <span class="ad-chip">Telegram · TM</span>
        <h3>${esc(({uz: "Novostroyka eʼlonlari", ru: "Объявления новостроек", en: "New development listings"})[lang()])}</h3>
        <div class="newbuild-scene" aria-hidden="true">
          <img src="assets/img/services/telegram-novostroyka.jpg" alt="" width="960" height="540" loading="lazy">
          <span class="newbuild-label">${esc(({uz:"Turar-joy majmualari",ru:"Жилые комплексы",en:"Residential developments"})[lang()])}</span>
          <span class="newbuild-channel">${icon("M22 2 11 13M22 2l-7 20-4-9-9-4z")}<b>Telegram</b></span>
          <span class="newbuild-corner">TM</span>
        </div>
        <table class="ad-newbuild-table">
          <thead><tr><th>${esc(({uz:"Eʼlonlar soni",ru:"Количество",en:"Listings"})[lang()])}</th><th>${esc(({uz:"Jami narx",ru:"Стоимость",en:"Total price"})[lang()])}</th></tr></thead>
          <tbody>${AD_PRICES.telegramNew.map(([n, price]) => `<tr><td><span class="newbuild-count">${n}</span><span class="newbuild-times">${esc(ui.perTimes)}</span></td><td><strong>${fmtSum(price)}</strong> <small>${cur}</small>${n > 1 ? `<span class="newbuild-saving">−${new Intl.NumberFormat(lang(), {maximumFractionDigits: 1}).format((1 - price / (AD_PRICES.telegramNew[0][1] * n)) * 100)}% ${esc(P.tg.qty.save)}</span>` : ""}</td></tr>`).join("")}</tbody>
        </table>
        ${adBtn(ui)}
      </article>
      <article class="ad-card is-featured ad-pack reveal">
        <span class="ad-chip">${esc(P.tg.tag)}</span>
        <div class="broker-viz">
          <div class="broker-profile"><span class="broker-avatar" aria-hidden="true">${icon("M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM4 21v-2a8 8 0 0 1 16 0v2M10 15l2 3 2-3")}</span><div><b>${esc(({uz:"Maklerlar uchun",ru:"Для риелторов",en:"For realtors"})[lang()])}</b><span>${esc(({uz:"Obyektlar portfelingiz uchun",ru:"Для вашего портфеля объектов",en:"For your property portfolio"})[lang()])}</span></div></div>
          <div class="broker-properties" aria-hidden="true">${["M3 11 12 3l9 8M5 9v12h14V9M9 21v-7h6v7","M4 21V3h16v18M8 7h2M14 7h2M8 11h2M14 11h2M10 21v-5h4v5","M3 21h18M5 21V9l7-5 7 5v12M9 13h6M9 17h6"].map(d=>`<i>${icon(d)}<span></span><span></span></i>`).join("")}</div>
        </div>
        <h3>${esc(P.tg.title)}</h3>
        <p class="ad-sub">${esc(P.tg.sub)}</p>
        <p class="ad-sum">${fmtSum(P.tg.price)} <span>${cur} · ${esc(P.unitMonth)}</span></p>
        ${adCheck(P.tg.items)}
        ${adBtn(ui, "btn-white")}
      </article>

    </div>`;
  }
  if (platform === "instagram") {
    const R = P.ig.receipt, total = R.price;
    const stepIcons = ["M12 21s-7-6-7-11a7 7 0 1 1 14 0c0 5-7 11-7 11zM12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6z", "M3 6h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3zM17 10l4-2.5v9L17 14", "M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12", "M22 2 11 13M22 2l-7 20-4-9-9-4z", "M21 12a9 9 0 1 1-9-9M17 12a5 5 0 1 1-5-5M12 12l9-9M16 3h5v5"];
    const save = Math.round((1 - P.ig.bulk.price / P.ig.bulk.old) * 100);
    return `
    <div class="ad-grid ad-grid-3 ig-row">
    <article class="ad-flow reveal">
      <div class="ad-flow-head"><h3>${esc(R.flow)}</h3></div>
      <div class="ad-steps">
        ${R.rows.map(([label, v, desc], i) => `
        <div class="ad-step">
          <span class="ad-step-ico">${icon(stepIcons[i])}<i>${i + 1}</i></span>
          <h4>${esc(label)}</h4>
          <p>${esc(desc)}</p>

        </div>`).join("")}
      </div>
      <div class="ad-flow-total">
        <div><span>${esc(R.total)}</span><p>${esc(R.note)}</p></div>
        <div class="ig-single-price"><del>${fmtSum(R.old)} ${cur}</del><strong>${fmtSum(total)} <small>${cur}</small></strong><span>${esc(({uz:"Chegirmali narx",ru:"Цена со скидкой",en:"Discounted price"})[lang()])}</span></div>
        ${adBtn(ui)}
      </div>
    </article>
      <article class="ad-card ad-bulk reveal">
        <span class="ad-chip">${esc(P.ig.bulk.tag)}</span>
        <span class="ad-save">−${save}%</span>
        <h3>${esc(P.ig.bulk.title)}</h3>
        <div class="ad-bulkviz" aria-hidden="true"><span class="bv-badge"><b>5</b> Reels</span><div class="bv-fan">${[1, 2, 3, 4, 5].map((n, i) => `<i style="--i:${i};background-image:url('assets/ads/instagram-cover-${n}.jpg')"><u>${icon("M9 7v10l8-5z")}</u><em>${i + 1}</em></i>`).join("")}</div><span class="bv-each">${fmtSum(Math.round(P.ig.bulk.price / 5))} <small>${cur} / dona</small></span></div>
        <p class="ad-old">${fmtSum(P.ig.bulk.old)}</p>
        <p class="ad-sum">${fmtSum(P.ig.bulk.price)} <span>${cur}</span></p>
        ${adCheck(P.ig.bulk.items)}
        <div class="bulk-details">
          <div class="bulk-saving-head"><span>${icon("M5 12.5l4.5 4.5L19 7.5")}${esc(({uz:"Paket bilan tejaysiz",ru:"Экономия с пакетом",en:"Your package savings"})[lang()])}</span><strong>${fmtSum(P.ig.bulk.old-P.ig.bulk.price)} <small>${cur}</small></strong></div>
          <p>${esc(({uz:"Har bir videoda 500 000 soʻm tejash — 5 ta videoni alohida buyurtma qilishga nisbatan.",ru:"Экономия 500 000 сум на каждом видео по сравнению с отдельным заказом 5 роликов.",en:"Save 500,000 UZS per video compared with ordering 5 videos individually."})[lang()])}</p>
          <div class="bulk-schedule">${icon("M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14H3V6a2 2 0 0 1 2-2z")}<span>${esc(({uz:"Joylashtirish jadvali oldindan kelishiladi",ru:"График публикаций согласовывается заранее",en:"Publication schedule agreed in advance"})[lang()])}</span></div>
        </div>
        ${adBtn(ui)}
      </article>
      <article class="ad-card is-featured ad-tm reveal">
        <span class="ad-chip">${esc(P.ig.tm.tag)}</span>
        <h3>${esc(P.ig.tm.title)}</h3>
        ${`<div class="ad-tmviz"><i class="tm-photo"></i><span class="tm-chip c1">${icon("M9 7v10l8-5z")}Reels</span><span class="tm-chip c2">${icon("M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z")}Stories</span><span class="tm-chip c3">${icon("M3 8h4l2-3h6l2 3h4v12H3z")}Foto</span><div class="tm-phone"><i class="tm-btn b1"></i><i class="tm-btn b2"></i><i class="tm-btn b3"></i><i class="tm-btn b4"></i><div class="tm-screen"><span class="tm-island"></span><video class="tm-reel" src="assets/video/tm-reel.mp4" poster="assets/img/portfolio/p3.webp" autoplay muted loop playsinline preload="metadata"></video></div><span class="tm-home"></span></div></div>`}
        ${tgRateTable(AD_PRICES.instagramTM, ui, P)}
        ${adCheck(P.ig.tm.items.slice(1))}
        ${adBtn(ui, "btn-white")}
      </article>
    </div>`;
  }
  const tiers = ["standard", "silver", "gold"];
  const ghost = '<div class="mk-row is-ghost"><i></i><span></span><span></span></div>';
  const hit = (extra = "") => `<div class="mk-row is-hit"><i class="mk-thumb"></i><span></span><span></span><b></b>${extra}</div>`;
  const mocks = [
    `${ghost}${hit()}${ghost}`,
    `<div class="mk-row is-hit is-top"><i class="mk-thumb"><em>15</em></i><span></span><span></span><b></b><u>${icon("M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z")}</u></div>${ghost}${ghost}`,
    `<div class="mk-hero"><i class="mk-thumb"></i><div><span></span><span></span><b></b></div><u>${icon("M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z")}</u></div><div class="mk-mini">${ghost}${ghost}</div>`,
  ];
  return `
    <div class="ad-grid ad-grid-3">
      ${P.web.map((t, i) => `
      <article class="ad-card ad-tier is-${tiers[i]} reveal">
        <div class="ad-tier-top"><span class="ad-medal">${["1", "2", "3"][i]}</span><div class="ad-meter" title="${esc(P.vis)}">${[0, 1, 2].map((k) => `<i class="${k <= i ? "on" : ""}"></i>`).join("")}</div>${i === 2 ? `<span class="ad-premium">${esc(P.premium)}</span>` : `<span class="ad-chip">Website</span>`}</div>
        <div class="ad-mock mk-${tiers[i]}" aria-hidden="true">${mocks[i]}</div>
        <div class="ad-tier-title"><h3>${esc(t.name)}</h3><p class="ad-tier-text">${esc(t.text)}</p></div>
        <p class="ad-sum">${fmtSum(t.price)} <span>${cur} · ${esc(P.unitMonth)}</span></p>
        <div class="ad-reach">
          <p>${esc(P.reachT)}</p>
          <div>
            <span>${icon("M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z")}<b>~${fmtSum(t.views)}</b><em>${esc(P.views)}</em></span>
            <span>${icon("M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2")}<b>~${fmtSum(t.calls)}</b><em>${esc(P.calls)}</em></span>
          </div>
          <i class="ad-reach-bar"><u style="width:${[18, 45, 100][i]}%"></u></i>
        </div>
        ${adCheck(t.items)}
        ${adBtn(ui, i === 2 ? "btn-white" : "btn-dark")}
      </article>`).join("")}
    </div>`;
}

/* ---------- Interaktiv qismlar ---------- */
let sliderTimer = null;
let wfTimer = null;

function initInteractive() {
  // "Biz qanday ishlaymiz": bosqichlar ketma-ket faollashadi (ko'ringanda boshlanadi, ustiga olib borilsa to'xtaydi)
  clearTimeout(wfTimer);
  const wf = svcRoot.querySelector(".wf");
  if (wf) {
    const cells = [...wf.querySelectorAll(".wf-cell")];
    const setStep = (n) => {
      cells.forEach((c, i) => {
        c.classList.toggle("is-done", i < n);
        c.classList.toggle("is-active", i === n);
      });
      wf.dataset.step = n;
    };
    if (reduceMotion || !("IntersectionObserver" in window)) {
      cells.forEach((c) => c.classList.add("is-done"));
      cells.at(-1)?.classList.add("is-active");
    } else {
      setStep(-1); // ko'ringunga qadar hammasi kutib turadi
      let started = false;
      new IntersectionObserver(([e], io) => {
        if (!e.isIntersecting || started) return;
        started = true; io.disconnect(); setStep(0);
      }, { threshold: 0.4 }).observe(wf);

      // Faol katakning chizig'i to'lgach, keyingisiga o'tiladi; oxirgisidan keyin yana boshlanadi
      wf.addEventListener("animationend", (e) => {
        if (!e.target.matches(".is-active .wf-bar span")) return;
        const cur = Number(wf.dataset.step);
        wfTimer = setTimeout(() => setStep(cur + 1 >= cells.length ? 0 : cur + 1), 350);
      });
      cells.forEach((c, i) => {
        c.addEventListener("click", () => { clearTimeout(wfTimer); started = true; setStep(i); });
        c.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); c.click(); } });
      });
    }
  }

  // Afzalliklar slayderi
  clearInterval(sliderTimer);
  const slider = svcRoot.querySelector("[data-slider]");
  if (slider) {
    const slides = slider.querySelectorAll(".svc-slide");
    let idx = 0;
    const go = (n) => {
      idx = (n + slides.length) % slides.length;
      slides.forEach((s, i) => s.classList.toggle("is-active", i === idx));
      const bar = slider.querySelector(".svc-slider-bar span");
      bar.style.animation = "none"; bar.offsetHeight; bar.style.animation = "";
    };
    svcRoot.querySelectorAll("[data-slide]").forEach((b) => b.addEventListener("click", () => { go(idx + Number(b.dataset.slide)); restart(); }));
    const restart = () => { clearInterval(sliderTimer); if (!reduceMotion) sliderTimer = setInterval(() => go(idx + 1), 5000); };
    restart();
  }

  // Ipoteka kalkulyatori (annuitet formulasi)
  const calc = svcRoot.querySelector("[data-calc]");
  if (calc) {
    const money = (v) => "$" + Math.round(v).toLocaleString("ru-RU");
    const ui = SERVICE_CONTENT[lang()].ui;
    const priceEl = calc.querySelector('input[name="price"]');
    const fmtNum = (n) => (n ? Math.round(n).toLocaleString("ru-RU") : "");
    const parsePrice = () => Math.min(10000000, Number(priceEl.value.replace(/\D/g, "")) || 0);
    const update = () => {
      const price = parsePrice();
      const v = { price, ...Object.fromEntries([...calc.querySelectorAll('input[type="range"]')].map((i) => [i.name, Number(i.value)])) };
      const downSum = price * v.down / 100;
      const loan = price - downSum;
      const r = v.rate / 100 / 12;
      const n = v.years * 12;
      const monthly = r ? (loan * r) / (1 - Math.pow(1 + r, -n)) : loan / n;
      const total = monthly * n + downSum;
      const over = Math.max(0, monthly * n - loan);
      const set = (sel, txt) => { calc.querySelector(sel).textContent = txt; };
      set('[data-out="down"]', `${v.down}% · ${money(downSum)}`);
      set('[data-out="years"]', `${v.years} ${ui.calcYearsUnit}`);
      set('[data-out="rate"]', `${v.rate}%`);
      const ok = price > 0;
      set('[data-res="monthly"]', ok ? money(monthly) : "—");
      set('[data-res="downv"]', ok ? money(downSum) : "—");
      set('[data-res="loan"]', ok ? money(loan) : "—");
      set('[data-res="over"]', ok ? money(over) : "—");
      set('[data-res="total"]', ok ? money(total) : "—");
      const part = (x) => (ok && total ? `${(x / total) * 100}%` : "0%");
      calc.querySelector(".s-down").style.flexBasis = part(downSum);
      calc.querySelector(".s-loan").style.flexBasis = part(loan);
      calc.querySelector(".s-int").style.flexBasis = part(over);
      calc.querySelectorAll('input[type="range"]').forEach((i) => i.style.setProperty("--fill", `${((i.value - i.min) / (i.max - i.min)) * 100}%`));
      calc.querySelectorAll("[data-preset]").forEach((b) => b.classList.toggle("is-on", Number(b.dataset.preset) === price));
    };
    priceEl.addEventListener("input", () => { priceEl.value = fmtNum(parsePrice()); update(); });
    priceEl.addEventListener("focus", () => priceEl.select());
    calc.addEventListener("click", (e) => {
      const b = e.target.closest("[data-preset]");
      if (b) { priceEl.value = fmtNum(Number(b.dataset.preset)); update(); }
    });
    calc.addEventListener("input", (e) => { if (e.target !== priceEl) update(); });
    update();
  }

  // Reklama tariflari: Telegram / Instagram / Website almashtirgich
  const sw = svcRoot.querySelector(".ad-tabs");
  if (sw) {
    sw.addEventListener("click", (e) => {
      const b = e.target.closest("[data-platform]");
      if (!b) return;
      sw.querySelectorAll("button").forEach((x) => x.classList.toggle("is-active", x === b));
      const box = svcRoot.querySelector(".ad-panel");
      svcRoot.querySelector(".ad-bannerbox").innerHTML = adBanner(b.dataset.platform);
      svcRoot.querySelector("#ad-actions").innerHTML = adActions(b.dataset.platform);
      box.innerHTML = adPanel(b.dataset.platform, SERVICE_CONTENT[lang()].ui);
      box.querySelector("[data-qty] [data-n].is-on")?.click();
      box.querySelectorAll(".reveal").forEach((el, i) => { el.style.setProperty("--delay", `${i * 0.08}s`); });
      watchReveal(box);
    });
  }

  // Telegram: 1 tadan 10 tagacha eʼlon soni tanlagichi
  const adPanelEl = svcRoot.querySelector(".ad-panel");
  if (adPanelEl) {
    adPanelEl.addEventListener("click", (e) => {
      const b = e.target.closest("[data-qty] [data-n]");
      if (!b) return;
      const card = b.closest("[data-qty]");
      const n = Number(b.dataset.n), price = AD_PRICES.telegram.find(([k]) => k === n)[1];
      const base = AD_PRICES.telegram[0][1] * n, save = Math.round((1 - price / base) * 100);
      card.querySelectorAll("[data-n]").forEach((x) => x.classList.toggle("is-on", x === b));
      card.querySelector("[data-qty-n]").textContent = n;
      card.querySelector("[data-qty-sum]").textContent = fmtSum(price);
      card.querySelector("[data-qty-each]").textContent = fmtSum(Math.round(price / n));
      const sv = card.querySelector("[data-qty-save]");
      sv.hidden = save <= 0;
      sv.textContent = `−${save}% ${AD_PLANS[lang()].tg.qty.save}`;
      card.querySelector("[data-qty-posts]").innerHTML = Array.from({ length: n }, () => icon("m22 3-20 8 7 2 2 7 4-5 5 4z")).join("");
    });
    adPanelEl.querySelector("[data-qty] [data-n].is-on")?.click();
  }
}

/* ---------- Butun sahifani chizish ---------- */
function fitDeckThumbs() {
  document.querySelectorAll(".deck-card-thumb").forEach((el) => {
    el.style.setProperty("--k", el.clientWidth / 1920);
  });
}
window.addEventListener("resize", fitDeckThumbs);



function saleDocumentsBlock() {
 const items=[
  ['Uy egasining shaxsiy hujjati','Pasport yoki ID-kartaning asl nusxasi.'],
  ['Turmush oʻrtogʻining hujjati va roziligi','Umumiy nikoh mulki boʻlsa, er yoki xotinning shaxsiy hujjati va notarial roziligi kerak boʻladi.'],
  ['Oilaviy holatni tasdiqlovchi hujjat','Vaziyatga qarab nikoh, ajrashganlik yoki vafot etganlik guvohnomasi.'],
  ['Mulk huquqining asosi','Oldi-sotdi shartnomasi, tegishli hokim qarori yoki mulk huquqini tasdiqlovchi boshqa hujjat.'],
  ['Kadastr hujjatlari','Uyning kadastr pasporti va davlat reyestridan koʻchirma.'],
  ['Uyda roʻyxatda turgan shaxslar','Roʻyxatda yashovchilar va foydalanish huquqi tekshiriladi. Roʻyxatdan chiqarish shartlari oldindan kelishiladi.'],
  ['Qarzdorlik va taqiqlar','Gaz, elektr, suv, chiqindi va uyga xizmat koʻrsatish toʻlovlari, MIB qarzdorligi, garov va taqiqlar tekshiriladi.'],
  ['Meros bilan bogʻliq hujjatlar','Merosga boʻlgan huquq guvohnomasi va holatga qarab notarius soʻraydigan qoʻshimcha hujjatlar.']
 ];
 const prep=[['Kadastr hujjatlari','Obyektning kadastr pasporti va mavjud hujjatlar.'],['Kredit shartnomasi va toʻlov grafigi','Uy ipotekada boʻlsa, ikkala hujjatning nusxasi.'],['Oldi-sotdi shartnomasi','Uyni sotib olganingizni tasdiqlovchi shartnoma nusxasi.'],['Kadastr koʻchirmasi','Davlat reyestridagi mulk huquqi haqidagi koʻchirma.']];
 const list=(rows)=>rows.map((x,i)=>`<li><span class="sd-number">${String(i+1).padStart(2,'0')}</span><div><h4>${esc(x[0])}</h4><p>${esc(x[1])}</p></div></li>`).join('');
 return `<section class="section container sale-documents" lang="uz" aria-labelledby="sale-documents-title"><div class="section-head"><div><span class="sd-eyebrow">SOTUVGA TAYYORGARLIK</span><h2 class="section-title" id="sale-documents-title">Hujjatlar tayyor — keyingi qadam oson.</h2></div></div><div class="sd-layout"><aside class="sd-panel sd-prep"><div class="sd-folder" aria-hidden="true"><span>UY MARKET</span><svg viewBox="0 0 100 100"><path d="M24 24h36l16 16v43H24zM59 24v18h17M35 54h29M35 64h23"/><path d="m37 76 6 6 14-15"/></svg><b>SOTUV PAPKASI</b></div><span class="sd-step">01 · SOTUVNI BOSHLASH UCHUN</span><h3>Sotuvni boshlash uchun<br>4 ta asosiy hujjat</h3><p class="sd-intro">Mutaxassisimiz obyektni oʻrganishi uchun ushbu hujjatlarni tayyorlab qoʻying.</p><ol class="sd-list">${list(prep)}</ol><p class="sd-prep-note">Ipotekadagi uy boʻlsa, sotish shartlari va bank roziligi alohida aniqlashtiriladi.</p></aside><article class="sd-panel sd-notary"><div class="sd-panel-head"><span class="sd-icon">${icon('M6 3h9l4 4v14H6zM14 3v5h5M9 12h7M9 16h5')}</span><div><span class="sd-step">02 · NOTARIUS UCHUN HUJJATLAR</span><h3>Notarius uchun nimalar kerak?</h3></div><span class="sd-total">8 band</span></div><ol class="sd-list">${list(items)}</ol><div class="sd-note">Notarius koʻp maʼlumotlarni elektron tizim orqali tekshiradi. Hujjatlar roʻyxati mulkning holatiga qarab aniqlashtiriladi. <a href="https://advice.adliya.uz/oz/document/1966" target="_blank" rel="noopener">Rasmiy maʼlumot ↗</a></div></article><article class="sd-panel sd-settlement"><div class="sd-panel-head"><span class="sd-icon">${icon('M3 10 12 4l9 6M4 10h16M6 12v6M12 12v6M18 12v6M3 21h18')}</span><div><span class="sd-step">03 · BANK ORQALI HISOB-KITOB</span><h3>Sotuvni amalga oshirish yoʻli</h3></div><span class="sd-total">Eskrou</span></div><p class="sd-bank-intro">Xaridor → bankdagi eskrou hisobvaragʻi → notarius tasdigʻi → sotuvchining hisobi</p><ol class="sd-bank-steps"><li><span class="sd-number">01</span><h4>Bank hisoblari tayyorlanadi</h4><p>Xaridor eskrou hisobini ochadi. Sotuvchining mavjud yoki yangi bank hisobi belgilanadi.</p></li><li><span class="sd-number">02</span><h4>Kelishilgan summa kiritiladi</h4><p>Kelishilgan summa eskrou hisobiga naqd yoki naqdsiz kiritiladi.</p></li><li><span class="sd-number">03</span><h4>Notarius tasdiqlaydi</h4><p>Notarius mablagʻni elektron tekshirib, shartnomani tasdiqlaydi.</p></li><li><span class="sd-number">04</span><h4>Pul sotuvchiga oʻtkaziladi</h4><p>Tasdiqdan soʻng pul shu bank ish kunida, ish vaqtidan keyin esa keyingi ish kunida oʻtkaziladi.</p></li></ol><div class="sd-bank-fee"><div><span>Bank xizmati uchun taxminiy xarajat</span><strong>~200 000 <small>soʻm</small></strong></div><p>Taxminiy summa. Aniq komissiyani bankdan tekshiring; notarial xarajatlar alohida.</p></div><div class="sd-note">Ipoteka va boʻlib toʻlash shartlari bank hamda notarius bilan aniqlashtiriladi. <a href="https://lex.uz/docs/-8087150" target="_blank" rel="noopener">3790-son nizom ↗</a></div></article></div></section>`;
}

function saleMethodsBlock() {
 const T = {
 uz:{title:"UY MARKET bilan sotuv turlari",sub:"Sizga qulay hamkorlik usulini tanlang.",btn:"Usulni muhokama qilish",items:[
 ["Online yuboring","Telegram orqali sotuv","Uyingizning rasm va videolarini bizga online yuborasiz. UY MARKET eʼlonni Telegram kanaliga joylashtiradi.","Siz: rasm / video","Biz: Telegram eʼloni"],
 ["Tasvirga olish bizdan","Instagram orqali sotuv","Uyingizga borib, videoni oʻzimiz tayyorlaymiz va Instagram sahifamizga joylashtiramiz.","Biz: video tayyorlash","Kanal: Instagram"],
 ["Reklama xarajatlari bizdan","Ustama bilan sotuv","Barcha reklama xarajatlarini oʻzimiz qoplaymiz. Siz bilan kelishilgan narx ustiga ustama qoʻyib sotamiz.","Biz: reklama xarajatlari","Narx: kelishilgan ustama"],
 ["Bevosita xarid","Naqd pulga sotib olamiz","Uyingizni oʻzimiz naqd pulga sotib olamiz. Obyekt va xarid narxini birgalikda kelishamiz.","Xaridor: UY MARKET","Toʻlov: naqd pul"]]},
 ru:{title:"Способы продажи с UY MARKET",sub:"Выберите удобный формат сотрудничества.",btn:"Обсудить формат",items:[
 ["Отправьте онлайн","Продажа через Telegram","Вы отправляете фото и видео дома онлайн. UY MARKET размещает объявление в своём Telegram-канале.","Вы: фото / видео","Мы: публикация"],
 ["Мы снимаем","Продажа через Instagram","Мы приезжаем, готовим видео вашего дома и размещаем его на своей странице в Instagram.","Мы: видеосъёмка","Канал: Instagram"],
 ["Реклама за наш счёт","Продажа с наценкой","Мы покрываем расходы на рекламу и продаём дом с наценкой к согласованной с вами цене.","Мы: расходы на рекламу","Цена: согласованная наценка"],
 ["Прямой выкуп","Покупаем за наличные","Мы сами покупаем ваш дом за наличные. Объект и цену выкупа согласовываем вместе.","Покупатель: UY MARKET","Оплата: наличные"]]},
 en:{title:"Ways to sell with UY MARKET",sub:"Choose the partnership format that suits you.",btn:"Discuss this option",items:[
 ["Send online","Sell through Telegram","Send us photos and videos of your home online. UY MARKET publishes the listing on its Telegram channel.","You: photos / video","We: Telegram listing"],
 ["We film your home","Sell through Instagram","We visit your home, produce the video and publish it on our Instagram page.","We: video production","Channel: Instagram"],
 ["We fund the advertising","Sell with a markup","We cover the advertising costs and sell with a markup on the price agreed with you.","We: advertising costs","Price: agreed markup"],
 ["Direct purchase","We buy for cash","We buy your home ourselves for cash. We agree on the property and purchase price together.","Buyer: UY MARKET","Payment: cash"]]}
 }[lang()];
 const images=["assets/img/services/card-sale-2.webp","assets/ads/instagram-cover-3.jpg","assets/img/hero-complex.jpg","assets/img/statement-keys.webp"];
 const symbols=["M22 2 11 13M22 2l-7 20-4-9-9-4z","M7 3h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM17.5 6.5h.01","M3 11v4h4l10 5V6L7 11H3zM7 15l2 6M21 9v8","M3 6h18v12H3zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"];
 return `<section class="section container sale-methods" aria-labelledby="sale-methods-title"><div class="section-head"><h2 class="section-title" id="sale-methods-title">${esc(T.title)}</h2><p class="section-sub">${esc(T.sub)}</p></div><div class="sale-method-grid">${T.items.map((x,i)=>`<article class="sale-method"><div class="sm-visual"><img src="${images[i]}" alt="" loading="lazy"><span class="sm-number">0${i+1}</span><span class="sm-symbol sm-symbol-${i}">${icon(symbols[i])}</span><span class="sm-label">${esc(x[0])}</span><span class="sm-channel">${esc(["Telegram","Instagram","UY MARKET","UY MARKET"][i])}</span></div><div class="sm-content"><h3>${esc(x[1])}</h3><p>${esc(x[2])}</p><div class="sm-roles"><span><i>01</i>${esc(x[3])}</span><span><i>02</i>${esc(x[4])}</span></div></div></article>`).join("")}</div></section>`;
}


function render(slug) {
  const c = SERVICE_CONTENT[lang()];
  const d = c[slug];
  const ui = c.ui;
  const meta = SERVICE_META[slug];

  document.title = `${d.name} — UY MARKET`;
  renderTabs(slug);
  const partners = document.getElementById("svc-partners");
  if (partners) partners.remove();
  svcRoot.innerHTML = heroBlock(d, ui, meta) + aboutBlock(d, ui, meta) + stepsBlock(d, ui, meta, slug) + duoBlock(d, meta, ui, slug) + EXTRAS[meta.extra](d, ui) + (slug === "sotuv" ? saleMethodsBlock() + saleDocumentsBlock() : "") + faqBlock(d, ui, meta);

  // Hamkorlar qatori hero va "Xizmat haqida" orasiga ko'chiriladi
  if (partners) svcRoot.querySelector(".svc-cover")?.closest("section")?.after(partners);

  watchImages(svcRoot);
  watchReveal(svcRoot);
  fitDeckThumbs();
  watchCounters(svcRoot);
  initInteractive();
  window.dispatchEvent(new Event("scroll"));
}

/* ---------- Xizmatlar orasida o'tish ---------- */
let currentService = currentSlug();
render(currentService);

svcTabs.addEventListener("click", (e) => {
  const a = e.target.closest("[data-svc-link]");
  if (!a) return;
  e.preventDefault();
  const slug = a.dataset.svcLink;
  if (slug === currentService) return;
  pageTransition(SERVICE_CONTENT[lang()][slug].name, () => {
    currentService = slug;
    history.pushState({ slug }, "", `service.html?s=${slug}`);
    render(slug);
    window.scrollTo(0, 0);
  });
});

window.addEventListener("popstate", () => {
  const slug = currentSlug();
  if (slug === currentService) return;
  pageTransition(SERVICE_CONTENT[lang()][slug].name, () => { currentService = slug; render(slug); window.scrollTo(0, 0); });
});

document.addEventListener("langchange", () => render(currentService));

/* ---------- Share the selected channel as a PNG file ---------- */
const AD_SHARE_UI = {
  uz: {loading: "PNG tayyorlanmoqda…", ready: "PNG tayyor. Ulashish tugmasini yana bosing.", fallback: "PNG yuklab olindi. Telegramda chatni tanlang va shu faylni biriktiring.", open: "Telegramni ochish", error: "PNG yuklanmadi. Qayta urinib ko‘ring."},
  ru: {loading: "Подготовка PNG…", ready: "PNG готов. Нажмите «Поделиться» ещё раз.", fallback: "PNG скачан. Выберите чат в Telegram и прикрепите этот файл.", open: "Открыть Telegram", error: "Не удалось загрузить PNG. Повторите попытку."},
  en: {loading: "Preparing PNG…", ready: "PNG is ready. Click Share again.", fallback: "PNG downloaded. Choose a Telegram chat and attach this file.", open: "Open Telegram", error: "PNG could not be loaded. Please try again."}
};
function adShareHint(message, telegramLink = false) {
  const hint = document.getElementById("ad-hint");
  if (!hint) return;
  hint.replaceChildren(document.createTextNode(message));
  if (telegramLink) {
    const a = document.createElement("a");
    a.href = "https://web.telegram.org/k/"; a.target = "_blank"; a.rel = "noopener noreferrer";
    a.textContent = AD_SHARE_UI[lang()].open;
    hint.append(document.createTextNode(" "), a);
  }
  hint.hidden = false;
}
function downloadAdFile(platform, file) {
  const a = document.createElement("a");
  const objectUrl = file ? URL.createObjectURL(file) : null;
  a.href = objectUrl || AD_PNG(platform);
  a.download = `uy-market-reklama-${platform}.png`;
  document.body.appendChild(a); a.click(); a.remove();
  if (objectUrl) setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
}
function telegramFileFallback(platform, file) {
  // Telegram's share URL accepts links/text, not a local PNG attachment.
  // Open Telegram and download the actual PNG; the visitor attaches it to their chosen chat.
  if (navigator.userActivation?.isActive) window.open("https://web.telegram.org/k/", "_blank", "noopener,noreferrer");
  downloadAdFile(platform, file);
  adShareHint(AD_SHARE_UI[lang()].fallback, true);
}
document.addEventListener("click", async e => {
  const button = e.target.closest("[data-ad-share]");
  if (!button || button.disabled) return;
  const platform = button.dataset.adShare;
  let file = adShareFiles.get(platform)?.file;
  if (!file) {
    button.disabled = true;
    button.setAttribute("aria-busy", "true");
    adShareHint(AD_SHARE_UI[lang()].loading);
    try {
      await prepareAdFile(platform);
      adShareHint(AD_SHARE_UI[lang()].ready);
    } catch { adShareHint(AD_SHARE_UI[lang()].error); }
    finally { button.disabled = false; button.removeAttribute("aria-busy"); }
    return;
  }
  if (typeof navigator.share === "function" && typeof navigator.canShare === "function" && navigator.canShare({files: [file]})) {
    try {
      // No fetch/await before this call: native share needs the original click.
      await navigator.share({files: [file], title: "UY MARKET"});
    } catch (error) {
      if (error?.name !== "AbortError") telegramFileFallback(platform, file);
    }
  } else telegramFileFallback(platform, file);
});
