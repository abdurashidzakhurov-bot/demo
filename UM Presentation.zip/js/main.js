/* =========================================================
   UY MARKET — asosiy skriptlar
   ========================================================= */

// Forma qayerga yuborilishini shu yerda sozlang.
// endpoint bo'sh bo'lsa — demo rejim: yuborish taqlid qilinadi.
// Masalan Formspree: "https://formspree.io/f/xxxxxxx" yoki o'z backendingiz URL'i.
// Eslatma: Telegram bot tokenini frontendga yozmang — uni backend orqali yuboring.
const FORM_CONFIG = {
  endpoint: "",
  method: "POST",
};

// Headerdagi "Promo video" tugmasi ochadigan YouTube video havolasi.
// Istalgan ko'rinish bo'ladi: https://youtu.be/ID, https://www.youtube.com/watch?v=ID yoki /shorts/ID
const PROMO_VIDEO_URL = "https://youtu.be/a_ETtLqQ9k8";

// Xaritadagi obyektlar. x/y — xaritadagi joylashuv (foizda).
// Haqiqiy obyektlar bilan almashtiring; matnlar i18n.js dagi kalitlardan olinadi.
const LISTINGS = [
  { x: 34, y: 42, type: "flat", rooms: 3, img: "portfolio/p1.webp", name: "map.l1", loc: "map.loc1", price: "$58 000", tag: "map.verified" },
  { x: 58, y: 30, type: "flat", rooms: 2, img: "portfolio/p3.webp", name: "map.l2", loc: "map.loc2", price: "$41 500", tag: "map.new" },
  { x: 20, y: 70, type: "house", rooms: 5, img: "services/card-sale-2.webp", name: "map.l3", loc: "map.loc3", price: "$96 000", tag: "map.verified" },
  { x: 74, y: 64, type: "commercial", rooms: 0, img: "../presentation/p10-facade.jpg", name: "map.l4", loc: "map.loc4", price: "$1 200", perMonth: true, tag: "map.rent" },
  { x: 47, y: 76, type: "flat", rooms: 1, img: "portfolio/p5.webp", name: "map.l5", loc: "map.loc5", price: "$450", perMonth: true, tag: "map.furnished" },
  { x: 85, y: 24, type: "house", rooms: 4, img: "services/hero-sale-2.webp", name: "map.l6", loc: "map.loc6", price: "$120 000", tag: "map.verified" },
];
const MAP_DOTS = [[12, 22], [28, 18], [66, 48], [90, 82], [40, 58], [8, 88]];

document.documentElement.classList.add("js");

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ---------- Loader: 0 dan 100% gacha foiz ---------- */
const LOADER_MS = reduceMotion ? 600 : 3000;

const loaderDone = new Promise((resolve) => {
  const loader = document.getElementById("loader");
  if (!loader) { document.documentElement.classList.remove("is-loading"); resolve(); return; }

  const countEl = document.getElementById("loader-count");
  const start = performance.now();
  let finished = false;

  const paint = (p) => {
    countEl.textContent = Math.round((1 - Math.pow(1 - p, 2)) * 100);
  };

  // Tugash vaqti setTimeout bilan: rAF fondagi tablarda to'xtab qoladi, sahifa esa qotib qolmasligi kerak
  const finish = () => {
    if (finished) return;
    finished = true;
    paint(1);
    loader.classList.add("is-done");
    document.documentElement.classList.remove("is-loading");
    resolve();
    setTimeout(() => loader.remove(), 1000);
  };
  setTimeout(finish, LOADER_MS);

  // setInterval fondagi tabda ham ishlaydi (rAF esa to'xtab qoladi)
  const timer = setInterval(() => {
    if (finished) { clearInterval(timer); return; }
    paint(Math.min((performance.now() - start) / LOADER_MS, 1));
  }, 30);
});

/* ---------- Rasm yuklanmasa placeholder ko'rinadi ---------- */
function watchImages(root = document) {
  root.querySelectorAll(".ph img").forEach((img) => {
    const markBroken = () => img.classList.add("is-broken");
    if (img.complete && img.naturalWidth === 0 && img.getAttribute("src")) markBroken();
    else img.addEventListener("error", markBroken);
  });
}
watchImages();

/* ---------- Header: pastga scrollda yashirinadi, yuqoriga scrollda chiqadi ---------- */
const header = document.getElementById("header");
let lastY = window.scrollY;

function onScroll() {
  const y = window.scrollY;
  header.classList.toggle("is-scrolled", y > 16);
  header.classList.toggle("is-hidden", y > 400 && y > lastY);
  lastY = y;
}
onScroll();
window.addEventListener("scroll", onScroll, { passive: true });

/* ---------- Fullscreen menyu ---------- */
const menu = document.getElementById("menu");
const menuOpenBtn = document.getElementById("menu-open");
const menuVideo = document.getElementById("menu-video");

function openMenu() {
  menu.hidden = false;
  // Video faqat menyu ochiq turganda ijro etiladi; reduced-motion'da poster ko'rinadi
  if (!reduceMotion) menuVideo.play().catch(() => {});
  menu.classList.remove("is-closing");
  menuOpenBtn.setAttribute("aria-expanded", "true");
  document.body.classList.add("no-scroll");
  document.getElementById("menu-close").focus();
}

function closeMenu() {
  if (menu.hidden) return;
  menuVideo.pause();
  menuOpenBtn.setAttribute("aria-expanded", "false");
  document.body.classList.remove("no-scroll");
  if (reduceMotion) { menu.hidden = true; return; }
  menu.classList.add("is-closing");
  setTimeout(() => { menu.hidden = true; menu.classList.remove("is-closing"); }, 340);
}

menuOpenBtn.addEventListener("click", openMenu);
document.getElementById("menu-close").addEventListener("click", closeMenu);
menu.addEventListener("click", (e) => {
  if (e.target === menu || e.target.closest(".menu-links a, [data-open-modal]")) closeMenu();
});

/* ---------- Hero sarlavhasi: so'zlar ketma-ket chiqadi ---------- */
function splitWords() {
  let i = 0;
  document.querySelectorAll("[data-split] > span").forEach((line) => {
    const words = line.textContent.trim().split(/\s+/);
    line.textContent = "";
    words.forEach((w, idx) => {
      const span = document.createElement("span");
      span.className = "word";
      span.style.setProperty("--i", i++);
      span.textContent = idx < words.length - 1 ? w + " " : w;
      line.appendChild(span);
    });
  });
}

/* ---------- Statement: scroll bilan so'zlar bo'yaladi ---------- */
const statement = document.getElementById("statement");
let statementWords = [];

function splitStatement() {
  statementWords = [];
  if (!statement) return;
  statement.querySelectorAll("[data-words]").forEach((part) => {
    const words = part.textContent.trim().split(/\s+/);
    part.textContent = "";
    words.forEach((w, idx) => {
      const span = document.createElement("span");
      span.className = "w";
      span.textContent = w;
      part.appendChild(span);
      if (idx < words.length - 1) part.appendChild(document.createTextNode(" "));
      statementWords.push(span);
    });
  });
  paintStatement();
}

function paintStatement() {
  if (!statement) return;
  const rect = statement.getBoundingClientRect();
  const vh = window.innerHeight;
  // Matn ekranning 85% chizig'idan 35% chizig'igacha ko'tarilganda 0 → 1
  const p = Math.min(Math.max((vh * 0.85 - rect.top) / (rect.height + vh * 0.5), 0), 1);
  const lit = reduceMotion ? statementWords.length : Math.round(p * statementWords.length);
  statementWords.forEach((w, i) => {
    w.classList.toggle("is-on", i < lit);
    w.classList.toggle("is-now", i === lit - 1 && lit < statementWords.length);
  });
}

splitWords();
splitStatement();
document.addEventListener("langchange", () => { splitWords(); splitStatement(); });

/* ---------- Parallaks va statement uchun yagona scroll sikli ---------- */
let ticking = false;

function onFrame() {
  paintStatement();
  if (!reduceMotion) {
    document.querySelectorAll("[data-parallax]").forEach((img) => {
      const r = img.parentElement.getBoundingClientRect();
      if (r.bottom < 0 || r.top > window.innerHeight) return;
      const p = (r.top + r.height / 2 - window.innerHeight / 2) / window.innerHeight;
      img.style.transform = `translateY(${p * -40}px) scale(1.12)`;
    });
  }
  ticking = false;
}
onFrame();
window.addEventListener("scroll", () => {
  if (!ticking) { requestAnimationFrame(onFrame); ticking = true; }
}, { passive: true });

/* ---------- Scroll'da paydo bo'lish ---------- */
// Animatsiya tugagach .reveal olib tashlanadi, aks holda u hover transform'larini bosib ketadi
function revealDone(el) {
  el.classList.add("is-visible");
  setTimeout(() => {
    el.classList.remove("reveal", "is-visible");
    el.style.removeProperty("--delay");
  }, 1200);
}

const revealIo = "IntersectionObserver" in window && !reduceMotion
  ? new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        revealDone(entry.target);
        revealIo.unobserve(entry.target);
      });
    }, { threshold: 0.1, rootMargin: "0px 0px -40px 0px" })
  : null;

// root ichidagi .reveal elementlarni kuzatadi; xizmat sahifasi kontentni qayta chizganda ham chaqiriladi
function watchReveal(root = document) {
  // Bir qatordagi elementlar ketma-ket chiqishi uchun kichik kechikish
  root.querySelectorAll(".services-grid, .team-grid, .branches, .faq, .hero-split, [data-stagger]").forEach((group) => {
    // Yashirin jamoa a'zolari observer'ga tushmaydi, shuning uchun ularda reveal kerak emas
    group.querySelectorAll(".is-extra.reveal").forEach((el) => el.classList.remove("reveal"));
    group.querySelectorAll(".reveal").forEach((el, i) => el.style.setProperty("--delay", `${(i % 4) * 0.08}s`));
  });
  const els = root.querySelectorAll(".reveal");
  if (revealIo) els.forEach((el) => revealIo.observe(el));
  else els.forEach(revealDone);
}

// Loader yopilgach kuzatish boshlanadi, aks holda hero animatsiyasi parda ortida o'tib ketadi
loaderDone.then(() => watchReveal());

/* ---------- Ko'rsatkichlar raqamlari sanaladi ---------- */
function animateCount(el) {
  const target = Number(el.dataset.count);
  const duration = 1600;
  const start = performance.now();
  const tick = (now) => {
    const p = Math.min((now - start) / duration, 1);
    el.textContent = Math.round(target * (1 - Math.pow(1 - p, 4))).toLocaleString("ru-RU");
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

const countIo = "IntersectionObserver" in window && !reduceMotion
  ? new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        animateCount(entry.target);
        countIo.unobserve(entry.target);
      });
    }, { threshold: 0.6 })
  : null;

function watchCounters(root = document) {
  if (countIo) root.querySelectorAll("[data-count]").forEach((el) => countIo.observe(el));
}
watchCounters();

/* ---------- Xizmatlar filtri ---------- */
const serviceCards = document.querySelectorAll(".service");
const servicesCount = document.getElementById("services-count");

document.querySelectorAll(".topic").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".topic").forEach((b) => b.classList.toggle("is-active", b === btn));
    const f = btn.dataset.filter;
    let shown = 0;
    serviceCards.forEach((card) => {
      const match = f === "all" || card.dataset.cat === f;
      card.classList.toggle("is-hidden", !match);
      if (match) {
        shown++;
        card.animate?.([{ opacity: 0, transform: "translateY(12px)" }, { opacity: 1, transform: "none" }], { duration: reduceMotion ? 0 : 500, easing: "cubic-bezier(.16,1,.3,1)" });
      }
    });
    if (servicesCount) servicesCount.textContent = String(shown).padStart(2, "0");
  });
});

/* ---------- Xarita ---------- */
const mapCanvas = document.getElementById("map-canvas");
if (mapCanvas) {
  const pinsEl = document.getElementById("pins");
  const popup = document.getElementById("map-popup");
  const mapCount = document.getElementById("map-count");
  const mapFilter = { type: "all", rooms: 0 };
  let activePin = null;

  MAP_DOTS.forEach(([x, y]) => {
    const dot = document.createElement("span");
    dot.className = "pin-dot";
    dot.style.cssText = `--x:${x}%;--y:${y}%`;
    pinsEl.appendChild(dot);
  });

  const pinEls = LISTINGS.map((item, i) => {
    const pin = document.createElement("button");
    pin.type = "button";
    pin.className = "pin";
    pin.style.cssText = `--x:${item.x}%;--y:${item.y}%;--i:${i}`;
    pin.innerHTML = `<img src="assets/img/${item.img}" alt="">`;
    pin.addEventListener("click", () => showPopup(i));
    pinsEl.appendChild(pin);
    return pin;
  });

  function priceText(item) {
    return item.perMonth ? `${item.price} ${window.t("map.perMonth")}` : item.price;
  }

  function updatePinLabels() {
    pinEls.forEach((pin, i) => pin.setAttribute("aria-label", `${window.t(LISTINGS[i].name)}, ${priceText(LISTINGS[i])}`));
  }

  function showPopup(i) {
    const item = LISTINGS[i];
    activePin = i;
    pinEls.forEach((p, j) => p.classList.toggle("is-active", j === i));

    document.getElementById("popup-img").src = `assets/img/${item.img}`;
    document.getElementById("popup-tag").textContent = window.t(item.tag);
    document.getElementById("popup-title").textContent = window.t(item.name);
    document.getElementById("popup-loc").textContent = window.t(item.loc);
    document.getElementById("popup-price").textContent = priceText(item);

    popup.hidden = false;

    // Popup xarita chetidan chiqib ketmasin: avval pastga, sig'masa tepaga, u ham bo'lmasa ichkariga siqiladi
    const w = mapCanvas.clientWidth;
    const h = mapCanvas.clientHeight;
    const pw = popup.offsetWidth;
    const ph = popup.offsetHeight;
    const gap = 36;
    const x = Math.min(Math.max((item.x / 100) * w, pw / 2 + 12), w - pw / 2 - 12);
    const y = (item.y / 100) * h;
    let top;
    if (y + gap + ph <= h - 12) top = y + gap;
    else if (y - gap - ph >= 12) top = y - gap - ph;
    else top = Math.max(12, h - ph - 12);

    popup.style.left = `${x}px`;
    popup.style.top = `${top}px`;
    popup.style.transform = "translateX(-50%)";
    popup.style.animation = "none";
    popup.offsetHeight; // animatsiyani qayta ishga tushirish
    popup.style.animation = "";
  }

  function hidePopup() {
    popup.hidden = true;
    activePin = null;
    pinEls.forEach((p) => p.classList.remove("is-active"));
  }

  function applyMapFilter() {
    let shown = 0;
    let firstVisible = -1;
    LISTINGS.forEach((item, i) => {
      const typeOk = mapFilter.type === "all" || item.type === mapFilter.type;
      const roomsOk = !mapFilter.rooms || (mapFilter.rooms === 4 ? item.rooms >= 4 : item.rooms === mapFilter.rooms);
      const ok = typeOk && roomsOk;
      pinEls[i].classList.toggle("is-filtered", !ok);
      if (ok) { shown++; if (firstVisible < 0) firstVisible = i; }
    });
    mapCount.textContent = shown ? window.t("map.count").replace("{n}", shown) : window.t("map.empty");
    if (activePin === null || pinEls[activePin].classList.contains("is-filtered")) {
      firstVisible >= 0 ? showPopup(firstVisible) : hidePopup();
    }
  }

  document.querySelectorAll(".type-tile").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".type-tile").forEach((b) => b.classList.toggle("is-active", b === btn));
      mapFilter.type = btn.dataset.type;
      applyMapFilter();
    });
  });
  document.querySelectorAll(".rooms button").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".rooms button").forEach((b) => b.classList.toggle("is-active", b === btn));
      mapFilter.rooms = Number(btn.dataset.rooms);
      applyMapFilter();
    });
  });
  document.getElementById("popup-cta").addEventListener("click", () => {
    const item = LISTINGS[activePin];
    openModal(item?.perMonth ? "rent" : "sale");
  });
  window.addEventListener("resize", () => { if (activePin !== null) showPopup(activePin); });
  document.addEventListener("langchange", () => {
    updatePinLabels();
    applyMapFilter();
    if (activePin !== null) showPopup(activePin);
  });

  updatePinLabels();
  applyMapFilter();
  showPopup(0);
}

/* ---------- Promo video (YouTube) ---------- */
const videoModal = document.getElementById("video-modal");
const videoFrame = document.getElementById("video-frame");
let videoOpener = null;

// youtu.be/ID, youtube.com/watch?v=ID, /shorts/ID, /embed/ID yoki shunchaki ID
function youtubeId(url) {
  const m = String(url).match(/(?:youtu\.be\/|v=|\/shorts\/|\/embed\/)([\w-]{11})/) || String(url).match(/^([\w-]{11})$/);
  return m ? m[1] : "";
}

function openVideo() {
  videoOpener = document.activeElement;
  const id = youtubeId(PROMO_VIDEO_URL);
  videoFrame.innerHTML = id
    ? `<iframe src="https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0&modestbranding=1" title="${window.t("nav.video")}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>`
    : `<div class="video-empty"><strong>${window.t("video.soon")}</strong><span>${window.t("video.soonText")}</span></div>`;
  videoModal.hidden = false;
  document.body.classList.add("no-scroll");
  videoModal.querySelector(".video-close").focus();
}

function closeVideo() {
  if (videoModal.hidden) return;
  videoFrame.innerHTML = ""; // iframe olib tashlanadi — video to'xtaydi
  videoModal.hidden = true;
  if (menu.hidden && modal.hidden) document.body.classList.remove("no-scroll");
  videoOpener?.focus();
}

document.querySelectorAll("[data-open-video]").forEach((el) => {
  el.addEventListener("click", (e) => {
    e.preventDefault();
    closeMenu();
    openVideo();
  });
});
videoModal.querySelectorAll("[data-close-video]").forEach((el) => el.addEventListener("click", closeVideo));

/* ---------- Footer: promo-video kartasi ---------- */
// assets/video/promo.mp4 bo'lsa shu ko'rinadi; topilmasa ofis videosi qo'yiladi va davomiylik yashiriladi
const reelVideo = document.getElementById("reel-video");
if (reelVideo) {
  const reelTime = document.getElementById("reel-time");
  const showTime = () => {
    if (!isFinite(reelVideo.duration)) return;
    const m = Math.floor(reelVideo.duration / 60);
    const sec = String(Math.floor(reelVideo.duration % 60)).padStart(2, "0");
    reelTime.textContent = `—${String(m).padStart(2, "0")}:${sec}`;
  };
  let usingFallback = false;
  reelVideo.addEventListener("error", () => {
    if (usingFallback) return;
    usingFallback = true;
    reelVideo.src = "assets/video/menu.mp4";
    reelTime.textContent = "";
  });
  reelVideo.addEventListener("loadedmetadata", () => { if (!usingFallback) showTime(); });

  // Faqat ko'ringanda ijro etiladi (reduced-motion'da poster ko'rinadi)
  if ("IntersectionObserver" in window && !reduceMotion) {
    new IntersectionObserver(([e]) => { e.isIntersecting ? reelVideo.play().catch(() => {}) : reelVideo.pause(); }, { threshold: 0.3 }).observe(reelVideo);
  }
}

/* ---------- Jamoa: birinchi 8 kishi, qolganlari tugma bilan ochiladi ---------- */
const teamGrid = document.getElementById("team-grid");
if (teamGrid) {
  const teamMore = document.getElementById("team-more");

  function updateTeamMore() {
    const open = teamGrid.classList.contains("is-expanded");
    teamMore.textContent = window.t(open ? "team.less" : "team.all");
    teamMore.setAttribute("aria-expanded", String(open));
  }

  teamMore.addEventListener("click", () => {
    const open = teamGrid.classList.toggle("is-expanded");
    updateTeamMore();
    if (!open) teamGrid.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
  });
  document.addEventListener("langchange", updateTeamMore);
  updateTeamMore();
}

/* ---------- FAQ accordion ---------- */
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".faq-q");
  if (!btn) return;
  const item = btn.closest(".faq-item");
  const open = !item.classList.contains("is-open");
  item.classList.toggle("is-open", open);
  btn.setAttribute("aria-expanded", String(open));
});

/* ---------- Modal ---------- */
const modal = document.getElementById("contact-modal");
const form = document.getElementById("contact-form");
let lastFocused = null;

/* ---------- Maxsus select (sayt uslubidagi ochiladigan ro'yxat) ---------- */
function enhanceSelect(select) {
  const wrap = document.createElement("div");
  wrap.className = "cselect";
  select.after(wrap);
  wrap.append(select);
  select.classList.add("cs-native");
  select.tabIndex = -1;
  select.setAttribute("aria-hidden", "true");

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "cs-btn";
  btn.setAttribute("aria-haspopup", "listbox");
  btn.setAttribute("aria-expanded", "false");
  btn.innerHTML = '<span class="cs-label"></span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
  const list = document.createElement("ul");
  list.className = "cs-list";
  list.setAttribute("role", "listbox");
  list.hidden = true;
  wrap.append(btn, list);
  const labelFor = select.id && document.querySelector(`label[for="${select.id}"]`);
  if (labelFor) labelFor.addEventListener("click", (e) => { e.preventDefault(); btn.focus(); });

  let active = -1;
  const opts = () => [...select.options];

  function render() {
    list.innerHTML = opts().map((o, i) => `<li role="option" data-i="${i}" aria-selected="${o.selected}"${o.selected ? ' class="is-selected"' : ""}><span>${o.textContent}</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></li>`).join("");
    btn.querySelector(".cs-label").textContent = select.selectedOptions[0]?.textContent || "";
  }
  function setActive(i) {
    const items = [...list.children];
    active = Math.max(0, Math.min(items.length - 1, i));
    items.forEach((li, k) => li.classList.toggle("is-active", k === active));
    items[active]?.scrollIntoView({ block: "nearest" });
  }
  function open() {
    render();
    list.hidden = false;
    btn.setAttribute("aria-expanded", "true");
    wrap.classList.add("is-open");
    const r = btn.getBoundingClientRect();
    const below = window.innerHeight - r.bottom, need = Math.min(list.scrollHeight, 280) + 12;
    wrap.classList.toggle("is-up", below < need && r.top > below);
    setActive(select.selectedIndex);
  }
  function close() {
    list.hidden = true;
    btn.setAttribute("aria-expanded", "false");
    wrap.classList.remove("is-open", "is-up");
  }
  function choose(i) {
    select.selectedIndex = i;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    render();
    close();
    btn.focus();
  }

  btn.addEventListener("click", () => (list.hidden ? open() : close()));
  list.addEventListener("click", (e) => { const li = e.target.closest("li"); if (li) choose(+li.dataset.i); });
  list.addEventListener("mousemove", (e) => { const li = e.target.closest("li"); if (li) setActive(+li.dataset.i); });
  btn.addEventListener("keydown", (e) => {
    const isOpen = !list.hidden;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (!isOpen) open(); else setActive(active + (e.key === "ArrowDown" ? 1 : -1));
    } else if (e.key === "Home" && isOpen) { e.preventDefault(); setActive(0); }
    else if (e.key === "End" && isOpen) { e.preventDefault(); setActive(opts().length - 1); }
    else if ((e.key === "Enter" || e.key === " ") && isOpen) { e.preventDefault(); choose(active); }
    else if (e.key === "Escape" && isOpen) { e.preventDefault(); e.stopPropagation(); close(); }
    else if (e.key === "Tab" && isOpen) close();
  });
  document.addEventListener("click", (e) => { if (!wrap.contains(e.target)) close(); });
  document.addEventListener("langchange", render);
  render();
  return { sync: render, close };
}
const serviceSelect = form.service ? enhanceSelect(form.service) : null;

function openModal(service) {
  lastFocused = document.activeElement;
  if (service) form.service.value = service;
  serviceSelect?.sync();
  modal.hidden = false;
  document.body.classList.add("no-scroll");
  setTimeout(() => form.name.focus(), 50);
}

function closeModal() {
  serviceSelect?.close();
  modal.hidden = true;
  if (menu.hidden) document.body.classList.remove("no-scroll");
  lastFocused?.focus();
}

document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-open-modal]");
  if (el) openModal(el.dataset.service);
});
modal.querySelectorAll("[data-close-modal]").forEach((el) => el.addEventListener("click", closeModal));

document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!videoModal.hidden) closeVideo();
  else if (!modal.hidden) closeModal();
  else closeMenu();
});

// Fokus modal ichida aylanib yursin
modal.addEventListener("keydown", (e) => {
  if (e.key !== "Tab") return;
  const focusable = modal.querySelectorAll("button, input, select, textarea, a[href]");
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
});

/* ---------- Telefon maskasi: +998 XX XXX XX XX ---------- */
const phoneInput = form.phone;

function formatPhone(value) {
  let digits = value.replace(/\D/g, "");
  if (digits.startsWith("998")) digits = digits.slice(3);
  digits = digits.slice(0, 9);
  const parts = [digits.slice(0, 2), digits.slice(2, 5), digits.slice(5, 7), digits.slice(7, 9)].filter(Boolean);
  return "+998" + (parts.length ? " " + parts.join(" ") : "");
}

phoneInput.addEventListener("focus", () => { if (!phoneInput.value) phoneInput.value = "+998 "; });
phoneInput.addEventListener("blur", () => { if (phoneInput.value.trim() === "+998") phoneInput.value = ""; });
phoneInput.addEventListener("input", () => { phoneInput.value = formatPhone(phoneInput.value); });

/* ---------- Validatsiya ---------- */
const validators = {
  name: (v) => (!v.trim() ? "required" : v.trim().length < 2 ? "nameShort" : ""),
  phone: (v) => (!v.trim() ? "required" : /^\+998 \d{2} \d{3} \d{2} \d{2}$/.test(v) ? "" : "phone"),
  telegram: (v) => (!v.trim() || /^(?:https?:\/\/)?(?:t\.me\/)?@?[A-Za-z][A-Za-z0-9_]{4,31}$/.test(v.trim()) ? "" : "telegram"),
  message: (v) => (v.length > 1000 ? "messageLong" : ""),
};

function validateField(input) {
  const check = validators[input.name];
  if (!check) return true;
  const errorKey = check(input.value);
  const field = input.closest(".field");
  field.classList.toggle("has-error", Boolean(errorKey));
  field.querySelector(".field-error").textContent = errorKey ? window.t(`form.err.${errorKey}`) : "";
  input.setAttribute("aria-invalid", String(Boolean(errorKey)));
  return !errorKey;
}

Object.keys(validators).forEach((name) => {
  const input = form[name];
  input.addEventListener("blur", () => validateField(input));
  input.addEventListener("input", () => {
    if (input.closest(".field").classList.contains("has-error")) validateField(input);
  });
});

// Til almashganda ko'rinib turgan xato matnlari ham yangilansin
document.addEventListener("langchange", () => {
  form.querySelectorAll(".field.has-error input, .field.has-error textarea").forEach(validateField);
});

/* ---------- Yuborish ---------- */
const statusEl = form.querySelector(".form-status");
const submitBtn = form.querySelector('[type="submit"]');

function setStatus(key, type) {
  statusEl.dataset.key = key;
  statusEl.textContent = key ? window.t(key) : "";
  statusEl.className = "form-status" + (type ? ` is-${type}` : "");
}

document.addEventListener("langchange", () => {
  if (statusEl.dataset.key) statusEl.textContent = window.t(statusEl.dataset.key);
});

async function sendForm(data) {
  if (!FORM_CONFIG.endpoint) {
    await new Promise((r) => setTimeout(r, 1000));
    console.info("[Demo] Forma ma'lumotlari:", data);
    return;
  }
  const res = await fetch(FORM_CONFIG.endpoint, {
    method: FORM_CONFIG.method,
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const fields = Object.keys(validators).map((n) => form[n]);
  const valid = fields.map(validateField).every(Boolean);
  if (!valid) {
    fields.find((f) => f.getAttribute("aria-invalid") === "true")?.focus();
    return;
  }

  const data = Object.fromEntries(new FormData(form));
  data.lang = document.documentElement.lang;
  if (data.telegram && data.telegram.trim()) data.telegram = "@" + data.telegram.trim().replace(/^(https?:\/\/)?(t\.me\/)?@?/, "");

  submitBtn.disabled = true;
  submitBtn.textContent = window.t("form.sending");
  setStatus("", "");

  try {
    await sendForm(data);
    form.reset();
    setStatus("form.success", "success");
  } catch (err) {
    console.error(err);
    setStatus("form.error", "error");
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = window.t("form.submit");
  }
});

/* ---------- Sahifalar o'tishi: o'rtada xizmat nomi (~2 s) ---------- */
const PT_IN = reduceMotion ? 0 : 800;   // parda yopiladi va nom chiqadi
const PT_HOLD = reduceMotion ? 0 : 350; // nom o'rtada turadi
const PT_OUT = reduceMotion ? 0 : 850;  // parda tepaga ko'tariladi

function transitionEl(label) {
  let el = document.getElementById("page-transition");
  if (!el) {
    el = document.createElement("div");
    el.id = "page-transition";
    el.className = "page-transition";
    el.setAttribute("aria-hidden", "true");
    el.innerHTML = '<p class="pt-name"></p><span class="pt-line"></span>';
    document.body.appendChild(el);
  }
  // Har bir harf alohida chiqadi
  el.querySelector(".pt-name").innerHTML = [...label].map((ch, i) =>
    `<span style="--i:${i}">${ch === " " ? "&nbsp;" : ch.replace(/[&<>]/g, "")}</span>`).join("");
  return el;
}

// mid() parda to'liq yopilganda chaqiriladi: kontent almashadi yoki boshqa sahifaga o'tiladi
function pageTransition(label, mid) {
  const el = transitionEl(label);
  el.classList.remove("is-out");
  el.offsetHeight; // animatsiyani qayta boshlash
  el.classList.add("is-in");
  document.body.classList.add("no-scroll");
  setTimeout(() => {
    const leaving = mid() === "leave";
    if (leaving) return; // yangi sahifa pardani o'zi ko'taradi
    setTimeout(() => finishTransition(el), PT_HOLD);
  }, PT_IN);
}

function finishTransition(el) {
  el.classList.add("is-out");
  setTimeout(() => {
    el.classList.remove("is-in", "is-out");
    if (menu.hidden && modal.hidden) document.body.classList.remove("no-scroll");
  }, PT_OUT);
}

// Boshqa sahifadan pardani qabul qilish (bosh sahifa → xizmat sahifasi)
try {
  const handoff = sessionStorage.getItem("um-transition");
  if (handoff) {
    sessionStorage.removeItem("um-transition");
    const el = transitionEl(handoff);
    el.classList.add("is-in", "is-instant");
    el.offsetHeight;
    el.classList.remove("is-instant");
    setTimeout(() => finishTransition(el), PT_HOLD);
  }
} catch { /* sessionStorage yopiq bo'lsa o'tishsiz ochiladi */ }

// Xizmat sahifasiga olib boruvchi havolalar (bosh sahifa kartalari, footer)
document.addEventListener("click", (e) => {
  const a = e.target.closest("[data-svc-link]");
  if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || typeof SERVICE_CONTENT === "undefined") return;
  e.preventDefault();
  const lang = SERVICE_CONTENT[document.documentElement.lang] ? document.documentElement.lang : "uz";
  // data-svc-label="crumb" bo'lsa pardada xizmat nomi o'rniga "Xizmatlar" yoziladi
  const label = a.dataset.svcLabel === "crumb"
    ? SERVICE_CONTENT[lang].ui.crumb
    : SERVICE_CONTENT[lang][a.dataset.svcLink]?.name || a.textContent.trim();
  closeMenu();
  // Shu sahifaning o'zi bo'lsa qayta yuklanmaydi: tepaga silliq chiqamiz
  if (new URL(a.href, location.href).href === location.href) { window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" }); return; }
  pageTransition(label, () => {
    try { history.scrollRestoration = "manual"; } catch { /* eski brauzer */ }
    try { sessionStorage.setItem("um-transition", label); } catch { /* yo'q bo'lsa ham o'tiladi */ }
    location.href = a.href;
    return "leave";
  });
});

/* ---------- Footer yili ---------- */
document.querySelectorAll(".year").forEach((el) => { el.textContent = new Date().getFullYear(); });

/* ---------- Sahifa har doim boshidan ochiladi (anchor bo'lmasa) ---------- */
try { if (!location.hash) { history.scrollRestoration = "manual"; window.scrollTo(0, 0); } } catch { /* ruxsat yo'q */ }

/* Footerdagi "Bosh sahifa" havolasi bosh sahifada bo'lsa tepaga chiqaradi */
document.addEventListener("click", (e) => {
  const a = e.target.closest(".site-footer a[href]");
  if (!a || a.hasAttribute("data-svc-link")) return;
  const u = new URL(a.href, location.href);
  if (u.origin === location.origin && u.pathname === location.pathname && !u.hash && u.search === location.search) {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
  }
});
