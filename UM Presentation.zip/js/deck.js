/* =========================================================
   UY MARKET — quruvchi-investorlar uchun taqdimot (20 sahifa, 1920×1080; UZ/RU/EN/ZH)
   Matn 3 tilda (UZ / RU / EN); sayt qaysi tilda ochilgan bo'lsa shu til ko'rsatiladi.
   window.DECK: { open(), close(), html(i), count } — to'liq ekranli ko'rgich ham shu yerda.
   ========================================================= */
(() => {
  const N = 20;
  const W = 1920, H = 1080;
  const PHONES = ["+998 93 150 90 00", "+998 93 150 80 00"];

  /* ---------- Matnlar ---------- */
  const TEXT = {
    uz: {
      ui: { code: "uz", cardTitle: "Quruvchilar uchun taqdimot", cardText: "Qurilgan uylarni sotish bosqichini UY MARKET’ga ishonib topshirish: jamoa, kanallar, jarayon va shaffof hisob-kitob — 20 sahifada.", cardBtn: "Taqdimotni ko‘rish", title: "UY MARKET · Taqdimot", tag: "Hamkorlik taklifi", footer: "UY MARKET · Andijon", close: "Yopish", pdf: "PDF yuklab olish", prev: "Oldingi sahifa", next: "Keyingi sahifa", page: "Sahifa" },
      s1: { t1: "UY MARKET —", t2: "qurilish kompaniyalari uchun xizmatlarimizning afzalliklari", tag: "Siz bino quring — biz kassani ishga tushiramiz.", meta: "Hamkorlik taklifi · 2026" },
      s2: { t: "Professional jamoa", k: 1, lead: "Koʻchmas mulk bozorini chuqur biladigan, muzokara olib borish va bitimlarni xavfsiz yopishda tajribali mutaxassislar jamoasi. Har bir mijoz bilan individual ishlaymiz va eng samarali natijaga erishamiz." },
      s3: { t: "Uzoq yillik tajriba", k: 2, stats: [["10 yil", "Koʻchmas mulk bozori savdosida — UY MARKET asoschisi Azizbek Kamolov tajribasi"], ["6 yil", "Uy-joy ipotekasi yoʻnalishida bankir sifatidagi tajriba"], ["2020", "yildan buyon UY MARKET koʻchmas mulk agentligi faoliyat yuritmoqda"]], cap1: "Asoschi — Azizbek Kamolov", cap2: "UY MARKET jamoasi" },
      s4: { t: "Tizimli boshqaruv", k: 1, lead: "Loyihaning har bir jarayoni aniq reja va nazorat asosida olib boriladi — marketingdan tortib bitim yopilishigacha barcha bosqichlar tartibli va samarali boshqariladi.", nodes: [["Marketing", "Reklama, kontent va mijozlar oqimi"], ["Qabul va koʻrsatuv", "Xaridorlarni obyektda qabul qilish"], ["Muzokara", "Narx va shartlar boʻyicha kelishuv"], ["Yuridik rasmiylashtirish", "Hujjatlar va notarial bitim"], ["Bitim yopiladi", "Hisobot va topshirish"]] },
      s5: { t: "Real bozor tahlili va monitoring", k: 2, lead: "Bozordagi narxlar hamda obyekt joylashgan lokatsiyadagi talab va taklif oʻrganiladi, raqobatchilar doimiy tahlil qilinadi. Bu esa obyektni toʻgʻri narxlash va eng qulay vaqtda sotish imkonini beradi.", chips: ["Bozordagi narxlar", "Hududdagi talab va taklif", "Raqobatchilar tahlili"] },
      s6: { t: "Sotuv ofislari", k: 1, lead: "Mijozlarni qabul qilish, loyiha taqdimoti va muzokaralar oʻtkazish uchun toʻliq jihozlangan sotuv ofislari — bitimlarni professional darajada olib borish uchun qulay muhit yaratilgan.", offices: [["Andijon shahar ofisi", "Andijon sh., 1-mikrorayon, Oq Laylak toʻyxonasi roʻparasida"], ["Yangi Andijon ofisi", "Yangi Andijon siti, bogʻcha roʻparasida"]] },
      s7: { t: "Mijozlar oqimining yuqoriligi", k: 2, lead: "Bizning keng mijozlar bazamiz va faol marketing strategiyamiz tufayli sizning obyektingizga doimiy ravishda koʻplab xaridorlar keladi, bu esa sotuv tezligini sezilarli oshiradi.", stats: [["1200+", "mijozlar bazamizda"], ["100k+", "reklama kanallari auditoriyasi"]] },
      s8: { t: "Keng auditoriyali reklama platformalari", k: 2, lead: "Obyektlaringizni maksimal darajada xaridorlarga yetkazamiz. Har bir platforma uchun moslashtirilgan kontent va reklama orqali sotuv jarayonini tezlashtiramiz.", tiles: [["Telegram / Instagram", "Uymarket", "100k+", "obunachilar", "plane"], ["Telegram / Instagram", "Andijonda bor", "100k+", "obunachilar", "camera"], ["YouTube", "", "", "faol obunachilar", "play"], ["Website", "", "", "faol foydalanuvchilar", "globe"]] },
      s9: { t: "Ijtimoiy tarmoqdagi yuqori aktivlik", k: 2, lead: "Bizning kanallar va sahifalarda doimiy faoliyat olib boriladi — yangiliklar, eʼlonlar va obyektlaringizni tezroq xaridorlarga yetkazamiz.", rows: [["Telegram", "Tezkor va ishonchli aloqa kanali. Obyektlar eʼlonlari, maxsus takliflar va yangiliklar auditoriyaga bevosita yetkaziladi.", "plane"], ["Instagram", "Vizual jihatdan jozibali kontent orqali auditoriyani jalb qilamiz. Professional fotosuratlar, short video va stories bilan brend imiji mustahkamlanadi va sotuvlar tezlashadi.", "camera"], ["YouTube", "Yuzlab koʻrishlar va prezentatsiya videolari bilan loyihalarni batafsil namoyish qilamiz. Bu xaridorning ishonchini oshiradi va savdoni tezlashtiradi.", "play"], ["Website", "Professional veb-sayt orqali barcha obyektlar katalogi, narxlar, planlar va kontaktlar bir joyda taqdim etiladi. Bu — brend ishonchliligi va konversiya markazi.", "globe"]] },
      s10: { t: "Aholining kompaniyaga nisbatan ishonchi", k: 2, lead: "Bizning professional yondashuvimiz, muvaffaqiyatli bitimlar va ochiq muloqot tufayli mijozlar kompaniyaga toʻliq ishonadi — har bir bitim xavfsiz va shaffof tarzda amalga oshiriladi.", stats: [["96%", "mamnun mijozlar"], ["100%", "yuridik nazorat"], ["1200+", "mijozlar"]] },
      s11: { t: "Hisob-kitobning shaffof va toʻliqligi", k: 2, lead: "Har bir xarajat va daromad aniq koʻrsatiladi, mijozlar oldida yashirin haqiqat yoʻq. Bu esa bitim jarayonini ishonchli va ochiq qiladi.", cards: [["Xarajatlar", "Har bir xarajat aniq koʻrsatiladi"], ["Daromadlar", "Har bir daromad aniq koʻrsatiladi"]], banner: "Yashirin haqiqat yoʻq" },
      s12: { t: "Mijozlarga texnik xizmat koʻrsatish", k: 2, lead: "Biz mijozlarga obyektingizni qulay tarzda taqdim etish uchun barcha zarur vositalarni taqdim etamiz — avtomobil orqali koʻrsatish, professional kataloglar va taqdimot materiallari yordamida har bir bitim samarali va shaxsiy tarzda oʻtkaziladi.", chips: ["Avtomobil orqali koʻrsatish", "Professional kataloglar", "Taqdimot materiallari"] },
      s13: { t: "Banklar va yuridik tashkilotlar bilan yaqin aloqalar", k: 2, lead: "Bizning keng professional tarmogʻimiz tufayli hujjatlarni rasmiylashtirish va moliyaviy jarayonlarni tez va soddalashtirilgan tarzda amalga oshirish mumkin. Bu mijozlar uchun xavfsiz va qulay bitimni taʼminlaydi.", chips: ["Hamkor banklar", "Yuristlar va notarius", "Xavfsiz bitim"], cta: "Hamkorlik uchun bogʻlaning" },
    },

    ru: {
      ui: { code: "ru", cardTitle: "Презентация для застройщиков", cardText: "Передача этапа продаж построенных домов UY MARKET: команда, каналы, процесс и прозрачный учёт — на 20 страницах.", cardBtn: "Смотреть презентацию", title: "UY MARKET · Презентация", tag: "Предложение о сотрудничестве", footer: "UY MARKET · Андижан", close: "Закрыть", pdf: "Скачать PDF", prev: "Предыдущая страница", next: "Следующая страница", page: "Страница" },
      s1: { t1: "UY MARKET —", t2: "преимущества наших услуг для строительных компаний", tag: "Вы строите дом — мы запускаем кассу.", meta: "Предложение о сотрудничестве · 2026" },
      s2: { t: "Профессиональная команда", k: 1, lead: "Команда опытных специалистов, глубоко знающих рынок недвижимости, умеющих вести переговоры и безопасно закрывать сделки. Мы работаем индивидуально с каждым клиентом и добиваемся наиболее эффективного результата." },
      s3: { t: "Многолетний опыт", k: 1, stats: [["10 лет", "на рынке продаж недвижимости — опыт основателя UY MARKET Азизбека Камолова"], ["6 лет", "опыта в ипотечном направлении — работа банкиром"], ["2020", "с этого года работает агентство недвижимости UY MARKET"]], cap1: "Основатель — Азизбек Камолов", cap2: "Команда UY MARKET" },
      s4: { t: "Системное управление", k: 1, lead: "Каждый процесс проекта ведётся по чёткому плану и под контролем — от маркетинга до закрытия сделки все этапы управляются упорядоченно и эффективно.", nodes: [["Маркетинг", "Реклама, контент и поток клиентов"], ["Приём и показ", "Встреча покупателей на объекте"], ["Переговоры", "Согласование цены и условий"], ["Юридическое оформление", "Документы и нотариальная сделка"], ["Закрытие сделки", "Отчёт и передача"]] },
      s5: { t: "Реальный анализ рынка и мониторинг", k: 2, lead: "Изучаются цены на рынке, спрос и предложение в районе расположения объекта, постоянно анализируются конкуренты. Это позволяет правильно оценить объект и продать его в самое удобное время.", chips: ["Цены на рынке", "Спрос и предложение в районе", "Анализ конкурентов"] },
      s6: { t: "Офисы продаж", k: 1, lead: "Полностью оборудованные офисы продаж для приёма клиентов, презентации проектов и переговоров — созданы комфортные условия для профессионального ведения сделок.", offices: [["Офис в г. Андижан", "г. Андижан, 1-й микрорайон, напротив тойхоны «Ок Лайлак»"], ["Офис Янги Андижан", "Янги Андижан Сити, напротив детского сада"]] },
      s7: { t: "Высокий поток клиентов", k: 2, lead: "Благодаря нашей широкой клиентской базе и активной маркетинговой стратегии на ваш объект постоянно приходит множество покупателей, что заметно ускоряет продажи.", stats: [["1200+", "клиентов в нашей базе"], ["100k+", "аудитория рекламных каналов"]] },
      s8: { t: "Рекламные платформы с широкой аудиторией", k: 2, lead: "Мы доносим ваши объекты до максимального числа покупателей. Адаптированный под каждую платформу контент и реклама ускоряют продажи.", tiles: [["Telegram / Instagram", "Uymarket", "100k+", "подписчиков", "plane"], ["Telegram / Instagram", "Andijonda bor", "100k+", "подписчиков", "camera"], ["YouTube", "", "", "активные подписчики", "play"], ["Сайт", "", "", "активные пользователи", "globe"]] },
      s9: { t: "Высокая активность в соцсетях", k: 2, lead: "В наших каналах и на страницах постоянно ведётся работа — новости, объявления и ваши объекты быстрее доходят до покупателей.", rows: [["Telegram", "Быстрый и надёжный канал связи. Объявления об объектах, специальные предложения и новости напрямую доходят до аудитории.", "plane"], ["Instagram", "Привлекаем аудиторию визуально привлекательным контентом. Профессиональные фото, короткие видео и stories укрепляют имидж бренда и ускоряют продажи.", "camera"], ["YouTube", "Подробно показываем проекты в видеообзорах и презентационных роликах. Это повышает доверие покупателей и ускоряет сделки.", "play"], ["Сайт", "Каталог всех объектов, цены, планировки и контакты — в одном месте на профессиональном сайте. Это центр доверия к бренду и конверсии.", "globe"]] },
      s10: { t: "Доверие населения к компании", k: 2, lead: "Благодаря нашему профессиональному подходу, успешным сделкам и открытому общению клиенты полностью доверяют компании — каждая сделка проходит безопасно и прозрачно.", stats: [["96%", "довольных клиентов"], ["100%", "юридический контроль"], ["1200+", "клиентов"]] },
      s11: { t: "Прозрачный и полный учёт", k: 2, lead: "Каждый расход и доход показан чётко — никаких скрытых нюансов перед клиентами. Это делает процесс сделки надёжным и открытым.", cards: [["Расходы", "Каждый расход показан чётко"], ["Доходы", "Каждый доход показан чётко"]], banner: "Никаких скрытых нюансов" },
      s12: { t: "Техническое обслуживание клиентов", k: 2, lead: "Мы предоставляем клиентам всё необходимое для удобной презентации вашего объекта — показ на автомобиле, профессиональные каталоги и презентационные материалы делают каждую сделку эффективной и личной.", chips: ["Показ на автомобиле", "Профессиональные каталоги", "Презентационные материалы"] },
      s13: { t: "Тесные связи с банками и юридическими организациями", k: 2, lead: "Благодаря нашей широкой профессиональной сети оформление документов и финансовые процессы проходят быстро и упрощённо. Это обеспечивает клиентам безопасную и удобную сделку.", chips: ["Банки-партнёры", "Юристы и нотариус", "Безопасная сделка"], cta: "Свяжитесь с нами для сотрудничества" },
    },

    en: {
      ui: { code: "en", cardTitle: "Presentation for builders", cardText: "Hand the sales stage of your finished homes to UY MARKET: team, channels, process and transparent accounting — in 20 pages.", cardBtn: "View presentation", title: "UY MARKET · Presentation", tag: "Partnership proposal", footer: "UY MARKET · Andijan", close: "Close", pdf: "Download PDF", prev: "Previous page", next: "Next page", page: "Page" },
      s1: { t1: "UY MARKET —", t2: "the advantages of our services for construction companies", tag: "You build the house — we start the cash flow.", meta: "Partnership proposal · 2026" },
      s2: { t: "Professional team", k: 1, lead: "A team of experienced specialists who know the real estate market in depth, negotiate well and close deals safely. We work individually with every client and achieve the most effective result." },
      s3: { t: "Years of experience", k: 2, stats: [["10 years", "in the real estate market — the experience of UY MARKET founder Azizbek Kamolov"], ["6 years", "in mortgage lending — working as a banker"], ["2020", "the year UY MARKET real estate agency started operating"]], cap1: "Founder — Azizbek Kamolov", cap2: "The UY MARKET team" },
      s4: { t: "Systematic management", k: 1, lead: "Every process of the project follows a clear plan and control — from marketing to closing the deal, every stage is managed in an orderly and effective way.", nodes: [["Marketing", "Advertising, content and client flow"], ["Reception and viewing", "Welcoming buyers at the property"], ["Negotiation", "Agreeing price and terms"], ["Legal formalisation", "Documents and notarial deal"], ["Deal closed", "Report and handover"]] },
      s5: { t: "Real market analysis and monitoring", k: 2, lead: "We study market prices, local supply and demand around the property and keep analysing competitors. This lets us price the property correctly and sell it at the best moment.", chips: ["Market prices", "Local supply and demand", "Competitor analysis"] },
      s6: { t: "Sales offices", k: 1, lead: "Fully equipped sales offices for receiving clients, presenting projects and negotiating — a comfortable environment for handling deals professionally.", offices: [["Andijan city office", "Andijan, 1st microdistrict, opposite Oq Laylak wedding hall"], ["New Andijan office", "Yangi Andijan City, opposite the kindergarten"]] },
      s7: { t: "A steady flow of clients", k: 2, lead: "Thanks to our broad client base and active marketing strategy, many buyers keep coming to your property, which noticeably speeds up sales.", stats: [["1200+", "clients in our base"], ["100k+", "audience of our ad channels"]] },
      s8: { t: "Advertising platforms with a wide audience", k: 2, lead: "We put your properties in front of as many buyers as possible. Content and ads tailored to every platform speed up the sales process.", tiles: [["Telegram / Instagram", "Uymarket", "100k+", "followers", "plane"], ["Telegram / Instagram", "Andijonda bor", "100k+", "followers", "camera"], ["YouTube", "", "", "active subscribers", "play"], ["Website", "", "", "active users", "globe"]] },
      s9: { t: "High activity on social media", k: 2, lead: "Our channels and pages are active all the time — news, listings and your properties reach buyers faster.", rows: [["Telegram", "A fast, reliable channel. Property listings, special offers and news reach the audience directly.", "plane"], ["Instagram", "We attract the audience with visually appealing content. Professional photos, short videos and stories strengthen the brand and speed up sales.", "camera"], ["YouTube", "We show projects in detail through video tours and presentation films. This builds buyers' trust and speeds up deals.", "play"], ["Website", "A professional website puts the catalogue of all properties, prices, floor plans and contacts in one place. It is the hub of brand trust and conversion.", "globe"]] },
      s10: { t: "Public trust in the company", k: 2, lead: "Thanks to our professional approach, successful deals and open communication, clients fully trust the company — every deal is safe and transparent.", stats: [["96%", "satisfied clients"], ["100%", "legal oversight"], ["1200+", "clients"]] },
      s11: { t: "Transparent and complete accounting", k: 2, lead: "Every expense and every income is shown clearly — nothing is hidden from clients. This makes the deal process reliable and open.", cards: [["Expenses", "Every expense is shown clearly"], ["Income", "Every income is shown clearly"]], banner: "Nothing hidden" },
      s12: { t: "Technical service for clients", k: 2, lead: "We give clients everything needed to present your property conveniently — viewings by car, professional catalogues and presentation materials make every deal effective and personal.", chips: ["Viewings by car", "Professional catalogues", "Presentation materials"] },
      s13: { t: "Close ties with banks and legal organisations", k: 2, lead: "Thanks to our broad professional network, paperwork and financial processes are handled quickly and simply. This gives clients a safe and convenient deal.", chips: ["Partner banks", "Lawyers and notary", "A safe deal"], cta: "Contact us to cooperate" },
    },
  };


  /* ---------- Qo'shimcha 4 sahifa (14–17) va xitoy tili (ZH) ---------- */
  Object.assign(TEXT.uz, {
    s14: { t: "Hamkor loyihalar", k: 1, lead: "Hamkor quruvchilar loyihalarida erishilgan savdo natijalari: aylanma, sotilgan xonadonlar va oylik oʻrtacha koʻrsatkichlar.", cols: ["Loyiha", "Sotilgan", "Aylanma", "Oyiga"], f: { u: "xonadon", mo: "oy", bn: "mlrd soʻm", mn: "mln soʻm", dec: "," } },
    s15: { t: "Hamkorlikdan natija", k: 1, lead: "Quruvchi uchun tayyor sotuv tizimi: siz qurilishga eʼtibor qaratasiz, sotuvni biz yuritamiz.", tiles: [["Tizimli sotuv boʻlimi", "Menejerlar, call-center va CRM — hammasi bir joyda."], ["Sifatli lidlar", "Har bir reklama soʻmi hisoblanadi: faqat haqiqiy xaridorlar sotuv boʻlimiga yetib boradi."], ["Shaffof hisobot", "Har hafta KPI, konversiya va marketing ROI boʻyicha aniq hisobot."], ["Tez aylanma", "Boʻsh kvartiralar tez sotiladi — kapital muzlab qolmaydi, qurilish toʻxtamaydi."]] },
    s16: { t: "Hamkorlik bosqichlari", k: 1, lead: "Shartnomadan sotuv yakunigacha — aniq va oldindan kelishilgan jarayon.", nodes: [["Tanishuv va kelishuv", "Loyiha, narxlar va sotuv rejasi muhokama qilinadi"], ["Shartnoma", "Xizmat shartlari rasmiylashtiriladi"], ["Marketing va sotuv", "Reklama, koʻrsatuvlar va muzokaralar boshlanadi"], ["Hisobot va yakun", "Haftalik hisobot, sotuv yakuni va topshirish"]] },
    s20: { t: "Hamkorlik qilamiz", k: 1, lead: "Loyihangizni muhokama qilish uchun biz bilan bogʻlaning — sotuv rejasini birgalikda tuzamiz." },
  });
  Object.assign(TEXT.ru, {
    s14: { t: "Проекты партнёров", k: 1, lead: "Результаты продаж в проектах партнёров-застройщиков: оборот, проданные квартиры и средние показатели за месяц.", cols: ["Проект", "Продано", "Оборот", "В месяц"], f: { u: "кв.", mo: "мес.", bn: "млрд сум", mn: "млн сум", dec: "," } },
    s15: { t: "Результат сотрудничества", k: 1, lead: "Готовая система продаж для застройщика: вы занимаетесь строительством, продажи ведём мы.", tiles: [["Системный отдел продаж", "Менеджеры, колл-центр и CRM — всё в одном месте."], ["Качественные лиды", "Каждый сум рекламы на счету: в отдел продаж попадают только реальные покупатели."], ["Прозрачная отчётность", "Каждую неделю — точный отчёт по KPI, конверсии и маркетинговому ROI."], ["Быстрая оборачиваемость", "Свободные квартиры продаются быстро — капитал не замораживается, стройка не останавливается."]] },
    s16: { t: "Этапы сотрудничества", k: 1, lead: "От договора до завершения продаж — чёткий и заранее согласованный процесс.", nodes: [["Знакомство и согласование", "Обсуждаются проект, цены и план продаж"], ["Договор", "Оформляются условия услуги"], ["Маркетинг и продажи", "Запускаются реклама, показы и переговоры"], ["Отчёт и завершение", "Еженедельный отчёт, завершение продаж и передача"]] },
    s20: { t: "Будем сотрудничать", k: 1, lead: "Свяжитесь с нами, чтобы обсудить ваш проект — вместе составим план продаж." },
  });
  Object.assign(TEXT.en, {
    s14: { t: "Partner projects", k: 1, lead: "Sales results achieved in the projects of partner developers: turnover, apartments sold and monthly averages.", cols: ["Project", "Sold", "Turnover", "Per month"], f: { u: "apts", mo: "mo", bn: "bn UZS", mn: "mn UZS", dec: "." } },
    s15: { t: "What you gain", k: 1, lead: "A ready-made sales system for developers: you focus on construction, we run the sales.", tiles: [["Systematic sales department", "Managers, call centre and CRM — all in one place."], ["Quality leads", "Every advertising sum counts: only real buyers reach the sales department."], ["Transparent reporting", "A precise weekly report on KPIs, conversion and marketing ROI."], ["Fast turnover", "Vacant apartments sell quickly — capital is not frozen and construction does not stop."]] },
    s16: { t: "Stages of cooperation", k: 1, lead: "From the contract to the end of sales — a clear, pre-agreed process.", nodes: [["Introduction and agreement", "The project, prices and sales plan are discussed"], ["Contract", "Service terms are formalised"], ["Marketing and sales", "Advertising, viewings and negotiations begin"], ["Report and completion", "Weekly report, end of sales and handover"]] },
    s20: { t: "Let’s work together", k: 1, lead: "Contact us to discuss your project — we will build the sales plan together." },
  });
  TEXT.zh = {
    ui: { code: "zh", cardTitle: "面向开发商的演示文稿", cardText: "将已建成住宅的销售阶段委托给 UY MARKET：团队、渠道、流程与透明账目——共 20 页。", cardBtn: "查看演示文稿", title: "UY MARKET · 演示文稿", tag: "合作提案", footer: "UY MARKET · 安集延", close: "关闭", pdf: "下载 PDF", prev: "上一页", next: "下一页", page: "页" },
    s1: { t1: "UY MARKET —", t2: "为建筑企业提供的服务优势", tag: "您来建房，我们来启动销售。", meta: "合作提案 · 2026" },
    s2: { t: "专业|团队", k: 1, lead: "团队成员深谙房地产市场，擅长谈判并能安全促成交易。我们为每位客户提供个性化服务，力求取得最佳成果。" },
    s3: { t: "多年|经验", k: 1, stats: [["10 年", "房地产销售市场经验——UY MARKET 创始人 Azizbek Kamolov"], ["6 年", "担任银行职员，从事住房抵押贷款业务的经验"], ["2020", "年起，UY MARKET 房地产中介开始运营"]], cap1: "创始人 — Azizbek Kamolov", cap2: "UY MARKET 团队" },
    s4: { t: "系统化|管理", k: 1, lead: "项目的每个环节都按明确的计划和监督进行——从营销到成交，各阶段均有序高效。", nodes: [["市场营销", "广告、内容与客流"], ["接待与看房", "在项目现场接待买家"], ["商务谈判", "商定价格与条件"], ["法律手续", "文件与公证交易"], ["成交完成", "报告与交付"]] },
    s5: { t: "真实的市场|分析与监测", k: 1, lead: "我们研究市场价格以及项目所在区域的供需情况，并持续分析竞争对手，从而为房源合理定价，并在最佳时机售出。", chips: ["市场价格", "区域供需情况", "竞争对手分析"] },
    s6: { t: "销售|中心", k: 1, lead: "配备齐全的销售中心，用于接待客户、项目展示和商务谈判——为专业处理交易营造舒适环境。", offices: [["安集延市办公室", "安集延市第 1 小区，Oq Laylak 婚礼大厅对面"], ["新安集延办公室", "新安集延城（Yangi Andijan City），幼儿园对面"]] },
    s7: { t: "稳定的|客流量", k: 1, lead: "凭借庞大的客户数据库和积极的营销策略，大量买家会持续来到您的项目，显著提升销售速度。", stats: [["1200+", "客户数据库"], ["100k+", "广告渠道受众"]] },
    s8: { t: "覆盖广泛受众的|广告平台", k: 1, lead: "我们将您的房源推送给尽可能多的买家。针对每个平台定制的内容和广告，加快销售进程。", tiles: [["Telegram / Instagram", "Uymarket", "100k+", "关注者", "plane"], ["Telegram / Instagram", "Andijonda bor", "100k+", "关注者", "camera"], ["YouTube", "", "", "活跃订阅者", "play"], ["网站", "", "", "活跃用户", "globe"]] },
    s9: { t: "社交媒体|高度活跃", k: 1, lead: "我们的频道和页面持续更新——新闻、公告和您的房源能更快触达买家。", rows: [["Telegram", "快速可靠的沟通渠道。房源公告、专属优惠和新闻直接送达受众。", "plane"], ["Instagram", "以视觉吸引力强的内容吸引受众。专业照片、短视频和 Stories 强化品牌形象并加快销售。", "camera"], ["YouTube", "通过视频导览和宣传片详细展示项目，增强买家信任，加速成交。", "play"], ["网站", "专业网站将全部房源目录、价格、户型图和联系方式集中呈现，是品牌信任与转化的核心。", "globe"]] },
    s10: { t: "居民对公司的|信任", k: 1, lead: "凭借专业的服务方式、成功的交易和开放的沟通，客户完全信任公司——每笔交易都安全透明。", stats: [["96%", "满意客户"], ["100%", "法律监督"], ["1200+", "客户"]] },
    s11: { t: "透明|完整的账目", k: 1, lead: "每一笔支出和收入都清晰列明，对客户没有任何隐瞒，让交易过程可靠而公开。", cards: [["支出", "每一笔支出都清晰列明"], ["收入", "每一笔收入都清晰列明"]], banner: "毫无隐瞒" },
    s12: { t: "客户|技术服务", k: 1, lead: "我们为客户提供便捷展示您房源所需的一切——驾车看房、专业画册和展示资料，让每笔交易高效且贴心。", chips: ["驾车看房", "专业画册", "展示资料"] },
    s13: { t: "与银行及法律机构的|紧密合作", k: 1, lead: "依托我们广泛的专业网络，文件办理和金融流程快速而简便，为客户带来安全、便捷的交易。", chips: ["合作银行", "律师与公证员", "安全交易"] },
    s14: { t: "合作|项目", k: 1, lead: "合作开发商项目的销售成果：营业额、已售户数和月均指标。", cols: ["项目", "已售", "营业额", "月均"], f: { u: "套", mo: "个月", bn: "亿苏姆", mn: "百万苏姆", dec: ".", zh: true } },
    s15: { t: "合作带来的|成果", k: 1, lead: "为开发商量身打造的销售体系：您专注建设，销售交给我们。", tiles: [["系统化销售部门", "销售经理、呼叫中心和 CRM——一站式提供。"], ["优质客户线索", "每一分广告费都有价值：只有真正的买家才会进入销售部门。"], ["透明的报告", "每周提供关于 KPI、转化率和营销 ROI 的详细报告。"], ["快速周转", "空置房源快速售出——资金不被冻结，施工不会停工。"]] },
    s16: { t: "合作|流程", k: 1, lead: "从签约到销售完成——清晰且事先约定的流程。", nodes: [["了解与洽谈", "讨论项目、价格和销售计划"], ["签订合同", "正式确定服务条款"], ["营销与销售", "启动广告、看房和谈判"], ["报告与收尾", "每周报告、销售完成与交付"]] },
    s20: { t: "期待与您|合作", k: 1, lead: "请联系我们讨论您的项目——我们将共同制定销售计划。" },
  };

  /* ---------- 17–19: quruvchilar savollari va rieltor bilan ishlash afzalliklari ---------- */
  Object.assign(TEXT.uz, {
    s17: { t: "Quruvchilar savollari", k: 1, lead: "Hamkorlikni boshlashdan oldin quruvchilar eng koʻp soʻraydigan savollarga javoblar.", qa: [["Qaysi bosqichdagi loyihalar bilan ishlaysiz?", "Qurilish boshlanishidan tortib topshirilgan binolargacha — har bir bosqich uchun alohida strategiya tuzamiz."], ["Sotuvni qancha vaqtda boshlaysiz?", "Audit va strategiyadan soʻng odatda 2–3 hafta ichida reklama va sotuv ishga tushadi."], ["Hamkorlik qanday hisoblanadi?", "Sotilgan kvartiralardan kelishilgan foiz asosida — natija boʻlmasa, xarajat ham boʻlmaydi."], ["Oʻz sotuv boʻlimimiz bor, siz kerakmisiz?", "Biz mavjud jamoangizni kuchaytiramiz: lid oqimi, skriptlar, CRM va nazorat tizimini quramiz."]] },
    s18: { t: "Savollar va javoblar", k: 1, lead: "Narx, xaridorlar bilan ishlash, hujjatlar va natijani nazorat qilish boʻyicha savollar.", off: 4, qa: [["Natijani qanday kuzatamiz?", "Har haftalik hisobot va CRM ga toʻgʻridan-toʻgʻri kirish orqali."], ["Kvartira narxini kim belgilaydi?", "Narx bozor tahlili asosida birgalikda belgilanadi, yakuniy qaror quruvchida qoladi."], ["Xaridorlar bilan kim ishlaydi?", "Qabul, koʻrsatuv va muzokaralarni bizning sotuv menejerlarimiz olib boradi — siz qurilishga eʼtibor qaratasiz."], ["Hujjatlar va bitimlar xavfsizmi?", "Har bir hujjat va bitim yuridik tekshiruvdan oʻtadi; rasmiylashtirish yuristlar, notarius va banklar bilan birgalikda amalga oshiriladi."]] },
    s19: { t: "Rieltor bilan ishlash afzalliklari", k: 2, lead: "Mustaqil sotuvdan farqli oʻlaroq: tayyor jamoa, mijozlar bazasi va nazorat tizimi bir joyda.", tiles: [["Tayyor sotuv jamoasi", "Menejerlar, call-center va CRM — oʻz boʻlimingizni qurishga vaqt va xarajat kerak emas."], ["Doimiy mijozlar oqimi", "1200+ mijozlar bazasi va 100k+ auditoriyali reklama kanallari."], ["Real bozorni bilish", "Narx, talab va raqobatchilar tahlili asosida toʻgʻri narx va vaqt."], ["Yuridik xavfsizlik", "Hujjatlar va bitimlar yuristlar, notarius va banklar bilan birgalikda rasmiylashtiriladi."], ["Shaffof nazorat", "KPI, konversiya va marketing ROI boʻyicha haftalik hisobot; hisob-kitob ochiq."], ["Qurilishga eʼtibor", "Sotuvni biz yuritamiz, siz qurilish va sifatga eʼtibor qaratasiz. Kapital tezroq aylanadi."]] },
  });
  Object.assign(TEXT.ru, {
    s17: { t: "Вопросы застройщиков", k: 1, lead: "Ответы на вопросы, которые застройщики чаще всего задают перед началом сотрудничества.", qa: [["С проектами какой стадии вы работаете?", "От начала строительства до сданных домов — для каждого этапа составляем отдельную стратегию."], ["Как быстро вы начинаете продажи?", "После аудита и стратегии обычно через 2–3 недели запускаются реклама и продажи."], ["Как рассчитывается сотрудничество?", "По согласованному проценту от проданных квартир — нет результата, нет и расходов."], ["У нас есть свой отдел продаж, нужны ли вы?", "Мы усиливаем вашу команду: выстраиваем поток лидов, скрипты, CRM и систему контроля."]] },
    s18: { t: "Вопросы и ответы", k: 1, lead: "Вопросы о цене, работе с покупателями, документах и контроле результата.", off: 4, qa: [["Как мы отслеживаем результат?", "Через еженедельный отчёт и прямой доступ к CRM."], ["Кто устанавливает цену квартир?", "Цена определяется совместно на основе анализа рынка, окончательное решение остаётся за застройщиком."], ["Кто работает с покупателями?", "Приём, показы и переговоры ведут наши менеджеры по продажам — вы занимаетесь строительством."], ["Документы и сделки безопасны?", "Каждый документ и сделка проходят юридическую проверку; оформление идёт вместе с юристами, нотариусом и банками."]] },
    s19: { t: "Преимущества работы с риелтором", k: 2, lead: "В отличие от самостоятельных продаж: готовая команда, клиентская база и система контроля в одном месте.", tiles: [["Готовая команда продаж", "Менеджеры, колл-центр и CRM — не нужно тратить время и средства на создание своего отдела."], ["Постоянный поток клиентов", "Клиентская база 1200+ и рекламные каналы с аудиторией 100k+."], ["Знание реального рынка", "Правильная цена и время продажи на основе анализа цен, спроса и конкурентов."], ["Юридическая безопасность", "Документы и сделки оформляются вместе с юристами, нотариусом и банками."], ["Прозрачный контроль", "Еженедельный отчёт по KPI, конверсии и маркетинговому ROI; учёт открыт."], ["Фокус на строительстве", "Продажи ведём мы, вы занимаетесь стройкой и качеством. Капитал оборачивается быстрее."]] },
  });
  Object.assign(TEXT.en, {
    s17: { t: "Builders’ questions", k: 1, lead: "Answers to the questions builders ask most often before starting to work together.", qa: [["Which project stages do you work with?", "From the start of construction to completed buildings — we build a separate strategy for each stage."], ["How soon do you start selling?", "After the audit and strategy, advertising and sales usually start within 2–3 weeks."], ["How is the cooperation priced?", "As an agreed percentage of the apartments sold — no result, no cost."], ["We have our own sales team — do we need you?", "We strengthen your existing team: we build the lead flow, scripts, CRM and control system."]] },
    s18: { t: "Questions and answers", k: 1, lead: "Questions about price, working with buyers, documents and tracking results.", off: 4, qa: [["How do we track the results?", "Through a weekly report and direct access to the CRM."], ["Who sets the apartment prices?", "Prices are set jointly based on market analysis; the final decision stays with the builder."], ["Who works with buyers?", "Our sales managers handle reception, viewings and negotiations — you focus on construction."], ["Are documents and deals safe?", "Every document and deal goes through legal review; paperwork is handled with lawyers, a notary and banks."]] },
    s19: { t: "Advantages of working with a realtor", k: 2, lead: "Unlike selling on your own: a ready team, client base and control system in one place.", tiles: [["Ready sales team", "Managers, call centre and CRM — no need to spend time and money building your own department."], ["A steady flow of clients", "A base of 1200+ clients and ad channels with a 100k+ audience."], ["Real market knowledge", "The right price and timing based on analysis of prices, demand and competitors."], ["Legal safety", "Documents and deals are handled with lawyers, a notary and banks."], ["Transparent control", "A weekly report on KPIs, conversion and marketing ROI; the accounting is open."], ["Focus on construction", "We run the sales, you focus on building and quality. Capital turns over faster."]] },
  });
  Object.assign(TEXT.zh, {
    s17: { t: "开发商|常见问题", k: 1, lead: "开发商在开始合作前最常提出的问题解答。", qa: [["你们负责哪个阶段的项目？", "从开工到已交付的楼盘——我们为每个阶段制定单独的策略。"], ["多久可以启动销售？", "完成审计并制定策略后，通常 2–3 周内启动广告和销售。"], ["合作如何计费？", "按已售房源的约定比例收取——没有成果，就没有费用。"], ["我们有自己的销售部门，还需要你们吗？", "我们会强化您现有的团队：搭建线索流、话术、CRM 和监控体系。"]] },
    s18: { t: "问题与|解答", k: 1, lead: "关于价格、客户接待、文件及成果跟踪的问题。", off: 4, qa: [["如何跟踪成果？", "通过每周报告和对 CRM 的直接访问。"], ["谁来确定房价？", "价格基于市场分析共同确定，最终决定权在开发商。"], ["谁负责接待买家？", "接待、看房和谈判由我们的销售经理负责——您专注于建设。"], ["文件和交易安全吗？", "每份文件和每笔交易都经过法律审核；手续由律师、公证员和银行共同办理。"]] },
    s19: { t: "与房产公司合作的|优势", k: 1, lead: "相比自行销售：现成的团队、客户数据库和监控体系，一站式提供。", tiles: [["现成的销售团队", "销售经理、呼叫中心和 CRM——无需耗费时间和成本自建部门。"], ["源源不断的客流", "1200+ 客户数据库和 100k+ 受众的广告渠道。"], ["了解真实市场", "基于价格、供需和竞争对手分析，把握合理的价格和时机。"], ["法律安全", "文件和交易由律师、公证员和银行共同办理。"], ["透明的监控", "每周提供 KPI、转化率和营销 ROI 报告；账目公开。"], ["专注建设", "销售由我们负责，您专注建设与质量，资金周转更快。"]] },
  });
  const LANGS = [["uz", "UZ"], ["ru", "RU"], ["en", "EN"], ["zh", "中文"]];

  /* ---------- Yordamchilar ---------- */
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const pad = (n) => String(n).padStart(2, "0");
  const ICON = {
    check: "M5 12.5l4.5 4.5L19 7.5",
    plane: "m22 3-20 8 7 2 2 7 4-5 5 4z",
    camera: "M3 8h4l2-3h6l2 3h4v12H3zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
    play: "M8 5.5v13l11-6.5z",
    globe: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",
    phone: "M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2",
    pin: "M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21zM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z",
  };
  const ic = (name) => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICON[name]}"/></svg>`;

  // Sarlavhaning oxirgi k ta so'zi brend ko'k rangida
  const title = (text, k, cls = "") => {
    if (text.includes("|")) {
      const [h, t] = text.split("|");
      return `<h1 class="sl-title ${cls}">${esc(h)}<span class="acc">${esc(t)}</span></h1>`;
    }
    const w = text.trim().split(/\s+/);
    const kk = Math.min(k, w.length - 1) || 0;
    const head = w.slice(0, w.length - kk).join(" ");
    const tail = w.slice(w.length - kk).join(" ");
    const long = text.length > 34 ? " is-long" : "";
    return `<h1 class="sl-title${long} ${cls}">${esc(head)}${tail ? ` <span class="acc">${esc(tail)}</span>` : ""}</h1>`;
  };
  const photo = (file, pos = "50% 50%") => `<div class="sl-scene is-photo"><img src="assets/presentation/${file}" alt="" style="object-position:${pos}"></div>`;
  const scene = (name) => `<div class="sl-scene">${window.SCENES[name]()}</div>`;
  const lead = (t) => `<p class="sl-lead">${esc(t)}</p>`;
  const stat = ([n, l], cls = "") => `<div class="sl-stat ${cls}"><b>${esc(n)}</b><span>${esc(l)}</span></div>`;
  const chipList = (arr) => `<ul class="sl-chips">${arr.map((c) => `<li>${ic("check")}<span>${esc(c)}</span></li>`).join("")}</ul>`;

  const frame = (T, n, cls, inner) => `
    <section class="sl ${cls}" lang="${T.ui.code}">
      <div class="sl-head"><span class="sl-logo"><img src="assets/img/logo.png" alt=""><b>UY MARKET</b></span><span class="sl-tag">${esc(T.ui.tag)}</span></div>
      <div class="sl-body">${inner}</div>
      <div class="sl-foot"><span>${esc(T.ui.footer)}</span><span class="sl-pg">${pad(n)} / ${N}</span></div>
    </section>`;

  const PORTRAITS = [3, 5, 7, 11, 2, 10, 8, 9, 12];

  /* ---------- 13 ta sahifa ---------- */
  const SLIDES = [
    // 01 — muqova
    (T) => `
    <section class="sl sl-cover" lang="${T.ui.code}">
      <div class="cv-grid" aria-hidden="true"></div>
      <div class="sl-head"><span class="sl-logo is-light"><img src="assets/img/logo.png" alt=""><b>UY MARKET</b></span><span class="sl-tag">${esc(T.s1.meta)}</span></div>
      <div class="cv-main">
        <h1 class="cv-title"><span>${esc(T.s1.t1)}</span> ${esc(T.s1.t2)}</h1>
        <p class="cv-tag">${esc(T.s1.tag)}</p>
      </div>
      <div class="cv-photo"><img src="assets/img/building.jpg" alt=""></div>
      <div class="sl-foot is-light"><span>${esc(T.ui.footer)}</span><span class="sl-pg">01 / ${N}</span></div>
    </section>`,

    // 02 — jamoa
    (T) => frame(T, 2, "s-team", `
      ${title(T.s2.t, T.s2.k)}${lead(T.s2.lead)}
      <div class="sl-photo wide"><img src="assets/presentation/team-group.jpg" alt=""></div>
      <div class="sl-portraits">${PORTRAITS.map((i) => `<div class="sl-photo"><img src="assets/img/team/team-${i}.webp" alt=""></div>`).join("")}</div>`),

    // 03 — tajriba
    (T) => frame(T, 3, "s-exp", `
      ${title(T.s3.t, T.s3.k)}
      <div class="sl-stats3">${T.s3.stats.map(([n, l]) => `<div class="sl-stat"><b>${esc(n)}</b><span>${esc(l)}</span></div>`).join("")}</div>
      <figure class="sl-photo cap"><img src="assets/presentation/founder.jpg" alt=""><figcaption>${esc(T.s3.cap1)}</figcaption></figure>
      <figure class="sl-photo cap"><img src="assets/presentation/founders-group.jpg" alt=""><figcaption>${esc(T.s3.cap2)}</figcaption></figure>`),

    // 04 — tizimli boshqaruv
    (T) => frame(T, 4, "s-system", `
      ${title(T.s4.t, T.s4.k)}${lead(T.s4.lead)}
      <ol class="sl-flow">${T.s4.nodes.map(([a, b], i) => `<li><span class="n">${pad(i + 1)}</span><div><h3>${esc(a)}</h3><p>${esc(b)}</p></div></li>`).join("")}</ol>`),

    // 05 — bozor tahlili
    (T) => frame(T, 5, "s-market", `
      ${title(T.s5.t, T.s5.k)}${lead(T.s5.lead)}${photo("p05-team.jpg", "50% 40%")}${chipList(T.s5.chips)}`),

    // 06 — ofislar
    (T) => frame(T, 6, "s-offices", `
      ${title(T.s6.t, T.s6.k)}${lead(T.s6.lead)}
      <div class="sl-offices">${T.s6.offices.map(([n, a], i) => `
        <figure class="sl-office"><div class="sl-photo tall"><img src="assets/presentation/office-${i + 1}.jpg" alt=""></div>
          <figcaption><h3>${esc(n)}</h3><p>${ic("pin")}<span>${esc(a)}</span></p><p>${ic("phone")}<span>${PHONES[i]}</span></p></figcaption></figure>`).join("")}</div>`),

    // 07 — mijozlar oqimi
    (T) => frame(T, 7, "s-flow", `
      ${title(T.s7.t, T.s7.k)}${lead(T.s7.lead)}${photo("p07-model.jpg")}
      <div class="sl-stats2">${T.s7.stats.map((s, i) => stat(s, i ? "is-brand" : "")).join("")}</div>`),

    // 08 — reklama platformalari
    (T) => frame(T, 8, "s-platforms", `
      ${title(T.s8.t, T.s8.k)}${lead(T.s8.lead)}
      <div class="sl-tiles">${T.s8.tiles.map(([p, sub, num, cap, icon], i) => `
        <div class="sl-tile ${i === 0 ? "is-brand" : ""}"><span class="ti">${ic(icon)}</span><h3>${esc(p)}</h3>${sub ? `<p class="sub">${esc(sub)}</p>` : ""}${num ? `<b>${esc(num)}</b>` : ""}<p class="cap">${esc(cap)}</p></div>`).join("")}</div>`),

    // 09 — ijtimoiy tarmoq
    (T) => frame(T, 9, "s-social", `
      ${title(T.s9.t, T.s9.k)}${lead(T.s9.lead)}
      <div class="sl-rows">${T.s9.rows.map(([a, b, icon]) => `<div class="sl-row"><span class="ti">${ic(icon)}</span><div><h3>${esc(a)}</h3><p>${esc(b)}</p></div></div>`).join("")}</div>`),

    // 10 — ishonch
    (T) => frame(T, 10, "s-trust", `
      ${title(T.s10.t, T.s10.k)}${lead(T.s10.lead)}${photo("p10-facade.jpg", "50% 30%")}
      <div class="sl-stats3 sm">${T.s10.stats.map((s) => stat(s)).join("")}</div>`),

    // 11 — shaffoflik
    (T) => frame(T, 11, "s-clear", `
      ${title(T.s11.t, T.s11.k)}${lead(T.s11.lead)}${photo("p11-partners.jpg")}
      <div class="sl-stats2">${T.s11.cards.map(([a, b]) => `<div class="sl-note">${ic("check")}<h3>${esc(a)}</h3><p>${esc(b)}</p></div>`).join("")}</div>
      <div class="sl-banner">${esc(T.s11.banner)}</div>`),

    // 12 — texnik xizmat
    (T) => frame(T, 12, "s-service", `
      ${title(T.s12.t, T.s12.k)}${lead(T.s12.lead)}${photo("p12-office.jpg")}${chipList(T.s12.chips)}`),

    // 13 — banklar va yuridik
    (T) => frame(T, 13, "s-bank", `
      ${title(T.s13.t, T.s13.k)}${lead(T.s13.lead)}${photo("p13-bank.jpg", "50% 60%")}${chipList(T.s13.chips)}`),

    // 14 — hamkor loyihalar (portfolio)
    (T) => {
      const f = T.s14.f;
      const num = (n, d = 1) => (Math.round(n * 10 ** d) / 10 ** d).toString().replace(".", f.dec);
      const money = (mln) => (f.zh ? (mln >= 1000 ? `${num(mln / 100)} ${f.bn}` : `${num(mln, 0)} ${f.mn}`) : mln >= 1000 ? `${num(mln / 1000)} ${f.bn}` : `${num(mln, 0)} ${f.mn}`);
      const list = typeof PORTFOLIO !== "undefined" ? PORTFOLIO : [];
      return frame(T, 14, "s-proj", `
        ${title(T.s14.t, T.s14.k)}${lead(T.s14.lead)}
        <div class="sl-proj">
          <div class="pj-head">${T.s14.cols.map((c) => `<span>${esc(c)}</span>`).join("")}</div>
          ${list.map((p) => `<div class="pj-row"><b>${esc(p.name)}</b><span>${p.units} ${f.u} / ${p.months} ${f.mo}</span><em>${money(p.units * p.price)}</em><span>${num(p.units / p.months)} ${f.u}</span></div>`).join("")}
        </div>`);
    },

    // 15 — hamkorlikdan natija
    (T) => frame(T, 15, "s-results", `
      ${title(T.s15.t, T.s15.k)}${lead(T.s15.lead)}
      <div class="sl-tiles">${T.s15.tiles.map(([a, b], i) => `<div class="sl-tile ${i === 0 ? "is-brand" : ""}"><span class="ti">${ic("check")}</span><h3>${esc(a)}</h3><p class="cap">${esc(b)}</p></div>`).join("")}</div>`),

    // 16 — hamkorlik bosqichlari
    (T) => frame(T, 16, "s-system s-steps", `
      ${title(T.s16.t, T.s16.k)}${lead(T.s16.lead)}
      <ol class="sl-flow">${T.s16.nodes.map(([a, b], i) => `<li><span class="n">${pad(i + 1)}</span><div><h3>${esc(a)}</h3><p>${esc(b)}</p></div></li>`).join("")}</ol>`),

    // 17–18 — quruvchilar savollari
    (T) => frame(T, 17, "s-qa", `
      ${title(T.s17.t, T.s17.k)}${lead(T.s17.lead)}
      <div class="sl-rows">${T.s17.qa.map(([q, a], i) => `<div class="sl-row"><span class="ti">${pad(i + 1)}</span><div><h3>${esc(q)}</h3><p>${esc(a)}</p></div></div>`).join("")}</div>`),
    (T) => frame(T, 18, "s-qa", `
      ${title(T.s18.t, T.s18.k)}${lead(T.s18.lead)}
      <div class="sl-rows">${T.s18.qa.map(([q, a], i) => `<div class="sl-row"><span class="ti">${pad(i + 1 + T.s18.off)}</span><div><h3>${esc(q)}</h3><p>${esc(a)}</p></div></div>`).join("")}</div>`),

    // 19 — rieltor bilan ishlash afzalliklari
    (T) => frame(T, 19, "s-adv", `
      ${title(T.s19.t, T.s19.k)}${lead(T.s19.lead)}
      <div class="sl-tiles">${T.s19.tiles.map(([a, b], i) => `<div class="sl-tile ${i === 0 ? "is-brand" : ""}"><span class="ti">${ic("check")}</span><h3>${esc(a)}</h3><p class="cap">${esc(b)}</p></div>`).join("")}</div>`),

    // 20 — aloqa
    (T) => frame(T, 20, "s-contact", `
      ${title(T.s20.t, T.s20.k)}${lead(T.s20.lead)}
      <div class="sl-contact">
        ${T.s6.offices.map(([n, a], i) => `<div class="ct-card"><h3>${esc(n)}</h3><p>${ic("pin")}<span>${esc(a)}</span></p><p>${ic("phone")}<span>${PHONES[i]}</span></p></div>`).join("")}
        <div class="sl-banner">${esc(T.s1.tag)}</div>
      </div>`),
  ];

  /* ---------- Til ---------- */
  const lang = () => { const l = document.documentElement.lang; return TEXT[l] ? l : "uz"; };
  const html = (i, l = lang()) => SLIDES[i](TEXT[l]);
  let dl = ""; // ko'rgichda qo'lda tanlangan til (faqat taqdimot uchun)
  const L = () => dl || lang();
  const pdfHref = (l = lang()) => `assets/presentation/uy-market-${l}.pdf`;

  /* ---------- To'liq ekranli ko'rgich ---------- */
  let root = null, stage = null, slidesEl = null, countEl = null, pdfEl = null, titleEl = null;
  let cur = 0;
  let touchX = null;

  const fit = () => {
    if (!root || root.hidden) return;
    const r = stage.getBoundingClientRect();
    const s = Math.min(r.width / W, r.height / H);
    slidesEl.style.setProperty("--k", s);
    slidesEl.style.width = `${W * s}px`;
    slidesEl.style.height = `${H * s}px`;
  };

  const paint = () => {
    const l = L(), T = TEXT[l];
    slidesEl.innerHTML = SLIDES.map((fn, i) => `<div class="deck-slide${i === cur ? " is-active" : ""}" data-i="${i}" aria-hidden="${i !== cur}"><div class="deck-slide-in">${fn(T)}</div></div>`).join("");
    titleEl.textContent = T.ui.title;
    pdfEl.href = pdfHref(l);
    pdfEl.querySelector("span").textContent = T.ui.pdf;
    root.querySelector(".deck-close span").textContent = T.ui.close;
    root.querySelector(".deck-prev").setAttribute("aria-label", T.ui.prev);
    root.querySelector(".deck-next").setAttribute("aria-label", T.ui.next);
    root.querySelectorAll(".deck-lang button").forEach((b) => {
      const on = b.dataset.l === l;
      b.classList.toggle("is-on", on);
      b.setAttribute("aria-pressed", String(on));
    });
    update();
    fit();
  };

  const update = () => {
    slidesEl.querySelectorAll(".deck-slide").forEach((el, i) => {
      el.classList.toggle("is-active", i === cur);
      el.classList.toggle("is-before", i < cur);
      el.setAttribute("aria-hidden", String(i !== cur));
    });
    countEl.textContent = `${pad(cur + 1)} / ${N}`;
    root.querySelector(".deck-prev").disabled = cur === 0;
    root.querySelector(".deck-next").disabled = cur === N - 1;
    root.querySelector(".deck-bar-fill").style.transform = `scaleX(${(cur + 1) / N})`;
  };

  const go = (n) => { cur = Math.max(0, Math.min(N - 1, n)); update(); };

  const build = () => {
    root = document.createElement("div");
    root.className = "deck";
    root.hidden = true;
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    root.innerHTML = `
      <div class="deck-top">
        <span class="deck-title"></span>
        <div class="deck-lang" role="group" aria-label="Language">${LANGS.map(([c, n]) => `<button type="button" data-l="${c}">${n}</button>`).join("")}</div>
        <div class="deck-actions">
          <a class="deck-btn" download><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11M7 11l5 5 5-5M5 20h14"/></svg><span></span></a>
          <button class="deck-btn deck-close" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg><span></span></button>
        </div>
      </div>
      <div class="deck-stage"><div class="deck-slides"></div></div>
      <div class="deck-nav">
        <button class="deck-arrow deck-prev" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button>
        <div class="deck-mid"><span class="deck-count"></span><div class="deck-bar"><i class="deck-bar-fill"></i></div></div>
        <button class="deck-arrow deck-next" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>
      </div>`;
    document.body.appendChild(root);
    stage = root.querySelector(".deck-stage");
    slidesEl = root.querySelector(".deck-slides");
    countEl = root.querySelector(".deck-count");
    pdfEl = root.querySelector("a.deck-btn");
    titleEl = root.querySelector(".deck-title");

    root.querySelector(".deck-prev").addEventListener("click", () => go(cur - 1));
    root.querySelector(".deck-next").addEventListener("click", () => go(cur + 1));
    root.querySelector(".deck-close").addEventListener("click", close);
    root.querySelector(".deck-lang").addEventListener("click", (e) => {
      const b = e.target.closest("button[data-l]");
      if (b) { dl = b.dataset.l; paint(); }
    });
    stage.addEventListener("touchstart", (e) => { touchX = e.touches[0].clientX; }, { passive: true });
    stage.addEventListener("touchend", (e) => {
      if (touchX === null) return;
      const dx = e.changedTouches[0].clientX - touchX; touchX = null;
      if (Math.abs(dx) > 50) go(cur + (dx < 0 ? 1 : -1));
    }, { passive: true });
    window.addEventListener("resize", fit);
    root.addEventListener("mousemove", poke);
    root.addEventListener("touchstart", poke, { passive: true });
    document.addEventListener("fullscreenchange", () => {
      fit();
      if (!document.fullscreenElement && root && !root.hidden && root.dataset.fs === "1") close();
    });
  };

  const onKey = (e) => {
    if (!root || root.hidden) return;
    if (e.key === "Escape") { e.stopImmediatePropagation(); close(); }
    else if (e.key === "ArrowRight" || e.key === "ArrowDown" || e.key === "PageDown") { e.preventDefault(); go(cur + 1); }
    else if (e.key === "ArrowLeft" || e.key === "ArrowUp" || e.key === "PageUp") { e.preventDefault(); go(cur - 1); }
    else if (e.key === "Home") go(0);
    else if (e.key === "End") go(N - 1);
  };

  // Boshqaruv elementlari harakatsizlikda yashirinadi
  let idle = 0;
  function poke() {
    if (!root) return;
    root.classList.remove("is-idle");
    clearTimeout(idle);
    idle = setTimeout(() => root.classList.add("is-idle"), 2600);
  }
  let opener = null;
  const open = (start = 0) => {
    if (!root) build();
    opener = document.activeElement;
    cur = start;
    dl = "";
    root.hidden = false;
    document.body.classList.add("no-scroll");
    try { root.requestFullscreen?.().catch(() => {}); } catch (e) {}
    poke();
    paint();
    root.dataset.fs = "1";
    requestAnimationFrame(() => { fit(); root.classList.add("is-open"); root.querySelector(".deck-close").focus(); });
  };

  function close() {
    if (!root || root.hidden) return;
    root.classList.remove("is-open");
    root.dataset.fs = "";
    root.hidden = true;
    document.body.classList.remove("no-scroll");
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) {}
    opener?.focus?.();
  }

  document.addEventListener("keydown", onKey, true);
  document.addEventListener("langchange", () => { dl = ""; if (root && !root.hidden) paint(); });
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-open-deck]");
    if (b) { e.preventDefault(); open(0); }
  });

  window.DECK = { open, close, html, count: N, lang, pdfHref, W, H, texts: TEXT };
})();
