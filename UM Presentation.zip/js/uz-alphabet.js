/* User-selected Uzbek spelling. Presentation language can differ from site language. */
(() => {
  const convert = value => value.split(/((?:https?:\/\/|www\.|@)[^\s]+|[\w.+-]+@[\w.-]+\.[a-z]+)/gi).map((part, i) => i % 2 ? part : part
    .replace(/([gGoO])['‘’ʻʼ`]/g, (_, c) => ({g:'ğ',G:'Ğ',o:'ö',O:'Ö'}[c]))
    .replace(/sh/gi, s => s[0] === 'S' ? 'Ş' : 'ş')
    .replace(/ch/gi, s => s[0] === 'C' ? 'Ç' : 'ç')).join('');
  window.uzAlphabet = convert;
  const saved = new WeakMap();
  const attrs = ['placeholder', 'aria-label', 'alt', 'title'];
  const skip = el => el.closest('script,style,code,pre,textarea,[translate="no"],.brand-word,.sl-logo,.sl-tag');
  const isUz = el => (el.closest('[lang]')?.getAttribute('lang') || document.documentElement.lang || 'uz').split('-')[0] === 'uz';
  function update(node, key, value, uz, write) {
    let record = saved.get(node);
    if (!record) saved.set(node, record = {});
    const prev = record[key];
    const original = prev && value === prev.output ? prev.original : value;
    const output = uz ? convert(original) : original;
    record[key] = {original, output};
    if (value !== output) write(output);
  }
  function refresh() {
    observer.disconnect();
    const walker = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const el = node.parentElement;
      if (!el || skip(el) || !node.nodeValue.trim()) continue;
      update(node, 'text', node.nodeValue, isUz(el), value => { node.nodeValue = value; });
    }
    document.querySelectorAll('[placeholder],[aria-label],[alt],[title]').forEach(el => {
      if (skip(el)) return;
      attrs.forEach(key => {
        if (el.hasAttribute(key)) update(el, key, el.getAttribute(key), isUz(el), value => el.setAttribute(key, value));
      });
    });
    observer.observe(document.documentElement, {subtree:true, childList:true, characterData:true, attributes:true, attributeFilter:['lang', ...attrs]});
  }
  const observer = new MutationObserver(refresh);
  refresh();
})();
