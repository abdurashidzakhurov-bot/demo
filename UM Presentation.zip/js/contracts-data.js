window.UM_CONTRACTS = {
  "categories": [
    [
      "ijara",
      "Ijara shartnomasi",
      "Kalit, muddat va toʻlov"
    ],
    [
      "sotuv",
      "Sotuv shartnomasi",
      "Mulk, narx va hamkorlik"
    ],
    [
      "reklama",
      "Reklama shartnomasi",
      "Kontent va joylashtirish"
    ],
    [
      "novostroyka",
      "Novostroyka shartnomasi",
      "Quruvchi bilan hamkorlik"
    ],
    [
      "ipoteka",
      "Ipoteka shartnomasi",
      "Maslahat va garov loyihasi"
    ],
    [
      "baholash",
      "Baholash shartnomasi",
      "Qiymat va hisobot"
    ]
  ],
  "fields": {
    "number": [
      "Hujjat raqami",
      "UM–____"
    ],
    "city": [
      "Tuzilgan joy",
      "Andijon shahri"
    ],
    "date": [
      "Tuzilgan sana",
      "YYYY-MM-DD",
      "date"
    ],
    "a": [
      "Birinchi taraf · F.I.Sh. / yuridik nomi",
      "Toʻliq nom"
    ],
    "a_id": [
      "Birinchi taraf · ID yoki STIR",
      "Hujjat / STIR"
    ],
    "a_rep": [
      "Birinchi taraf · vakil va vakolat asosi",
      "F.I.Sh., ustav / ishonchnoma"
    ],
    "a_address": [
      "Birinchi taraf · manzil",
      "Yuridik / yashash manzili"
    ],
    "a_phone": [
      "Birinchi taraf · aloqa",
      "Telefon"
    ],
    "a_bank": [
      "Birinchi taraf · bank rekvizitlari",
      "Hisobvaraq, bank, MFO"
    ],
    "b": [
      "Ikkinchi taraf · F.I.Sh. / yuridik nomi",
      "Toʻliq nom"
    ],
    "b_id": [
      "Ikkinchi taraf · ID yoki STIR",
      "Hujjat / STIR"
    ],
    "b_rep": [
      "Ikkinchi taraf · vakil va vakolat asosi",
      "F.I.Sh., ustav / ishonchnoma"
    ],
    "b_address": [
      "Ikkinchi taraf · manzil",
      "Yuridik / yashash manzili"
    ],
    "b_phone": [
      "Ikkinchi taraf · aloqa",
      "Telefon"
    ],
    "b_bank": [
      "Ikkinchi taraf · bank rekvizitlari",
      "Hisobvaraq, bank, MFO"
    ],
    "object": [
      "Obyekt manzili va tavsifi",
      "Manzil, tur, xonalar va holat"
    ],
    "cadastre": [
      "Kadastr raqami",
      "Kadastr hujjatidagi raqam"
    ],
    "area": [
      "Maydon (m²)",
      "Umumiy / foydalaniladigan maydon"
    ],
    "ownership": [
      "Mulk huquqi asosi",
      "Reyestr koʻchirmasi, sana va raqam"
    ],
    "rights": [
      "Uchinchi shaxslar huquqlari / cheklovlar",
      "Mavjud holatni aniq yozing"
    ],
    "start": [
      "Boshlanish sanasi",
      "YYYY-MM-DD",
      "date"
    ],
    "end": [
      "Tugash sanasi",
      "YYYY-MM-DD",
      "date"
    ],
    "amount": [
      "Shartnoma summasi (soʻm)",
      "Raqam va soʻz bilan"
    ],
    "payment": [
      "Toʻlov tartibi va sanalari",
      "Bosqichlar, usul va muddat"
    ],
    "handover": [
      "Topshirish muddati / tartibi",
      "Kelishilgan sana va shartlar"
    ],
    "notice": [
      "Bekor qilish va ogohlantirish tartibi",
      "Muddat, kanal va hisob-kitob"
    ],
    "extra": [
      "Qoʻshimcha kelishuvlar",
      "Faqat taraflar kelishgan shartlar",
      "textarea"
    ],
    "deposit": [
      "Taʼminot puli va qaytarish tartibi",
      "Summa, asos va muddat"
    ],
    "utilities": [
      "Kommunal toʻlovlar taqsimoti",
      "Qaysi taraf qaysi toʻlovni qoplaydi"
    ],
    "occupants": [
      "Birga yashovchi shaxslar",
      "F.I.Sh. va yashash asosi"
    ],
    "inventory": [
      "Jihozlar / kalitlar / koʻrsatkichlar",
      "Roʻyxat, soni va holati",
      "textarea"
    ],
    "defects": [
      "Kamchiliklar va eʼtirozlar",
      "Mavjud holatni qayd eting",
      "textarea"
    ],
    "service": [
      "Xizmat doirasi",
      "Aniq ishlar va cheklovlar",
      "textarea"
    ],
    "fee": [
      "Xizmat haqi va hisoblash asosi",
      "Qatʼiy summa / foiz, toʻlov sharti"
    ],
    "certificate": [
      "Mutaxassis sertifikati",
      "F.I.Sh., raqam, sana, amal muddati"
    ],
    "insurance": [
      "Javobgarlik sugʻurta polisi",
      "Sugʻurtalovchi, polis va amal muddati"
    ],
    "price": [
      "Obyektning kelishilgan narxi (soʻm)",
      "Raqam va soʻz bilan"
    ],
    "channel": [
      "Platforma va sahifa",
      "Telegram / Instagram / Website, havola"
    ],
    "quantity": [
      "Materiallar soni va formati",
      "Soni, davomiyligi, oʻlchami"
    ],
    "brief": [
      "Texnik topshiriq",
      "Mazmun, ssenariy, manzil, talablar",
      "textarea"
    ],
    "approval": [
      "Tasdiqlash va tuzatish tartibi",
      "Masʼul, muddat, tuzatishlar soni"
    ],
    "schedule": [
      "Joylashtirish jadvali",
      "Sana, vaqt, havola va saqlanish muddati",
      "textarea"
    ],
    "adbudget": [
      "Target budjeti va hisoboti",
      "Xizmat haqidan alohida summa / kiritilmagan"
    ],
    "usage": [
      "Kontentdan foydalanish huquqi",
      "Hudud, muddat, formatlar, huquq turi"
    ],
    "project": [
      "Majmua va quruvchi maʼlumoti",
      "Nomi, manzili va rekvizitlar"
    ],
    "permits": [
      "Loyiha va ruxsat hujjatlari",
      "Hujjatlar roʻyxati, sana, reyestr"
    ],
    "report": [
      "Hisobot va qabul qilish tartibi",
      "Davriylik, shakl, topshirish usuli"
    ],
    "bank": [
      "Bank va eskrou rekvizitlari",
      "Bank nomi, hisobvaraq, kelishuv"
    ],
    "unit": [
      "Kvartira / blok / qavat",
      "Loyihadagi identifikator, maydon va chizma"
    ],
    "completion": [
      "Qurilish yakuni va topshirish",
      "Sana, ruxsat va sifat mezonlari"
    ],
    "refund": [
      "Qaytarish va javobgarlik shartlari",
      "Asoslar, muddat, hisoblash tartibi"
    ],
    "loan": [
      "Kredit maʼlumotlari",
      "Bank, kredit shartnomasi raqami va sanasi"
    ],
    "debt": [
      "Taʼminlanayotgan majburiyat",
      "Asosiy qarz, foiz, muddat va jadval"
    ],
    "valuation": [
      "Garov qiymati / baholash asosi",
      "Qiymat, sana, hisobot raqami"
    ],
    "registry": [
      "Roʻyxatdan oʻtkazuvchi organ",
      "Organ va mulk huquqi yozuvi"
    ],
    "purpose": [
      "Baholash maqsadi",
      "Masalan: bitim yoki bank uchun"
    ],
    "value_type": [
      "Aniqlanadigan qiymat turi",
      "Bozor qiymati / boshqa turi"
    ],
    "value_date": [
      "Baholash sanasi",
      "YYYY-MM-DD",
      "date"
    ],
    "assumptions": [
      "Cheklov va farazlar",
      "Obyekt va foydalanish boʻyicha farazlar",
      "textarea"
    ]
  },
  "sources": {
    "civil": {
      "title": "Fuqarolik kodeksi · II qism",
      "url": "https://lex.uz/docs/-180552"
    },
    "realtor": {
      "title": "Rieltorlik faoliyati · OʻRQ–269, 20–21-moddalar",
      "url": "https://lex.uz/docs/1714039?otherlang=4"
    },
    "rent": {
      "title": "Adliya · Uy-joy ijarasini rasmiylashtirish",
      "url": "https://advice.adliya.uz/oz/document/1374"
    },
    "ads": {
      "title": "Reklama toʻgʻrisida · OʻRQ–776",
      "url": "https://lex.uz/docs/-6052631"
    },
    "escrow": {
      "title": "Ulushli qurilish · PF–11",
      "url": "https://lex.uz/docs/7353734"
    },
    "mortgage": {
      "title": "Ipoteka toʻgʻrisida · OʻRQ–58, 10–13-moddalar",
      "url": "https://lex.uz/docs/-1063359"
    },
    "valuation": {
      "title": "Baholash faoliyati · 811–I, 13-modda",
      "url": "https://lex.uz/docs/-24703"
    }
  },
  "templates": [
    {
      "id": "ijara-uy",
      "category": "ijara",
      "title": "Uy-joy ijara shartnomasi",
      "description": "Uy yoki kvartirani yashash uchun ijaraga berish.",
      "roles": [
        "Ijaraga beruvchi",
        "Ijaraga oluvchi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "cadastre",
        "area",
        "ownership",
        "rights",
        "start",
        "end",
        "amount",
        "payment",
        "deposit",
        "utilities",
        "occupants",
        "handover",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Ijara obyekti",
          "Ijaraga beruvchi {{ownership}} asosida tegishli boʻlgan {{object}} obyektini yashash uchun vaqtincha foydalanishga beradi. Kadastr: {{cadastre}}. Maydon: {{area}} m². Maʼlum cheklov va boshqa shaxslar huquqlari: {{rights}}."
        ],
        [
          "Muddat va yashovchilar",
          "Ijara {{start}} dan {{end}} gacha davom etadi. Uyda yashaydigan shaxslar: {{occupants}}. Uy-joy ijarasi muddati qonunda belgilangan eng koʻp muddatdan oshmasligi kerak. Topshirish: {{handover}}."
        ],
        [
          "Ijara haqi va xarajatlar",
          "Bir oylik ijara haqi: {{amount}} soʻm. Toʻlov: {{payment}}. Kommunal xarajatlar: {{utilities}}. Taʼminot puli, undan ushlab qolishning hujjatlashtirilgan asoslari va qaytarish: {{deposit}}."
        ],
        [
          "Foydalanish va qaytarish",
          "Uy va jihozlar alohida topshirish dalolatnomasi bilan beriladi. Ijarachi kelishilgan maqsadda foydalanadi, zararni xabar qiladi va mulkni asraydi. Mulkdor foydalanishga xalal bermaydi. Obyektni koʻrish vaqti oldindan kelishiladi; shartnoma tugaganda kalit va mulk holati dalolatnoma bilan qaytariladi."
        ],
        [
          "Rasmiylashtirish",
          "Taraflar uy-joy ijarasini davlat soliq organida hisobga qoʻyish uchun zarur maʼlumotlarni taqdim etadi. Hisobga qoʻyish va bekor qilish tegishli elektron davlat xizmati orqali amalga oshiriladi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "civil",
        "rent"
      ],
      "note": "Uy-joy ijarasi yozma tuziladi va soliq organida hisobga qoʻyiladi. Ushbu blankada toʻldirilmagan bandlar imzolashdan oldin kelishilishi kerak.",
      "status": "Namuna"
    },
    {
      "id": "ijara-dalolatnoma",
      "category": "ijara",
      "title": "Topshirish-qabul qilish dalolatnomasi",
      "description": "Kalitlar, jihozlar va uy holatini qayd etish.",
      "roles": [
        "Topshiruvchi",
        "Qabul qiluvchi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "cadastre",
        "inventory",
        "defects",
        "handover",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Obyektni topshirish",
          "Taraflar {{object}}, kadastr {{cadastre}} obyektini {{date}} kuni topshirish-qabul qilish holatini qayd etadi. Asosiy ijara shartnomasi raqami va sanasi: {{handover}}."
        ],
        [
          "Mulk va hisoblagichlar",
          "Kalitlar, jihozlar, hujjatlar hamda elektr, gaz va suv hisoblagichlari koʻrsatkichlari: {{inventory}}. Roʻyxat taraflar tomonidan solishtirib tekshiriladi."
        ],
        [
          "Holat va eʼtirozlar",
          "Aniqlangan kamchiliklar, fotoilovalar va eʼtirozlar: {{defects}}. Bu roʻyxat keyingi zarar yoki xarajatlarni aniqlashda hisobga olinadi; yashirin nuqsonlarga oid qonuniy huquqlarni bekor qilmaydi."
        ],
        [
          "Tasdiq",
          "Mazkur dalolatnoma mulkka egalik huquqini oʻtkazmaydi va ijara shartnomasi oʻrnini bosmaydi. Taraflar roʻyxat va holatni tekshirgandan keyin imzolaydi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "civil",
        "rent"
      ],
      "note": "Asosiy ijara shartnomasiga ilova. Boshlangʻich va yakuniy topshirish uchun ishlatiladi.",
      "status": "Namuna"
    },
    {
      "id": "sotuv-xizmati",
      "category": "sotuv",
      "title": "Sotuv boʻyicha rieltorlik xizmati",
      "description": "Mulkdor bilan agentlik xizmatlari doirasini belgilash.",
      "roles": [
        "Buyurtmachi",
        "Rieltorlik xizmati ijrochisi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "cadastre",
        "ownership",
        "rights",
        "service",
        "start",
        "end",
        "price",
        "fee",
        "payment",
        "certificate",
        "insurance",
        "report",
        "refund",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Xizmat va obyekt",
          "Buyurtmachi {{object}}, kadastr {{cadastre}} boʻyicha quyidagi xizmatlarni buyuradi: {{service}}. Mulk huquqi asosi: {{ownership}}. Maʼlum cheklovlar: {{rights}}."
        ],
        [
          "Muddat va narx",
          "Xizmat davri: {{start}} — {{end}}. Obyektning boshlangʻich kelishilgan narxi: {{price}} soʻm. Narxni oʻzgartirish hamda uchinchi shaxsga vakolat berish alohida kelishiladi. Mazkur hujjat ijrochiga mulkni mijoz nomidan sotish vakolatini avtomatik bermaydi."
        ],
        [
          "Haq va hisob-kitob",
          "Xizmat haqi va uni vujudga keltiradigan natija: {{fee}}. Toʻlov: {{payment}}. Hisobot hamda bajarilgan xizmatni qabul qilish: {{report}}. Bajarilmagan xizmatlar uchun mablagʻ qaytarish: {{refund}}."
        ],
        [
          "Taraflarning vazifalari",
          "Buyurtmachi haqiqiy hujjatlar va obyektga kelishilgan kirishni taʼminlaydi. Ijrochi eʼlon va muzokaralarni kelishilgan doirada olib boradi, bajarilgan ishlar haqida axborot beradi va mijoz maʼlumotlarini faqat xizmat doirasida ishlatadi. Xaridor topilishi kafolatlangan deb hisoblanmaydi."
        ],
        [
          "Kasbiy maʼlumotlar va bitim",
          "Masʼul rieltor sertifikati: {{certificate}}. Javobgarlik sugʻurtasi: {{insurance}}. Uy-joy oldi-sotdisi alohida shartnoma bilan notariusda rasmiylashtiriladi; mulk huquqining oʻtishi tegishli roʻyxatdan oʻtkaziladi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "realtor",
        "civil"
      ],
      "note": "Agentlikning haqiqiy yuridik nomi, STIR, vakolat, sertifikat va sugʻurta maʼlumotlarini kiriting. Logo bu maʼlumotlarning oʻrnini bosmaydi.",
      "status": "Namuna"
    },
    {
      "id": "sotuv-bitim",
      "category": "sotuv",
      "title": "Uy-joy oldi-sotdi loyihasi",
      "description": "Notariusga tayyorlash uchun bitim shartlari blankasi.",
      "roles": [
        "Sotuvchi",
        "Xaridor"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "cadastre",
        "area",
        "ownership",
        "rights",
        "price",
        "payment",
        "handover",
        "occupants",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Bitim predmeti",
          "Sotuvchi {{object}} obyektini xaridorga oʻtkazishni, xaridor esa kelishilgan haqni toʻlashni nazarda tutadi. Kadastr: {{cadastre}}; maydon: {{area}} m². Sotuvchining huquq asosi: {{ownership}}."
        ],
        [
          "Narx va toʻlov",
          "Bitim bahosi: {{price}} soʻm. Toʻlov manbasi, usuli va bosqichlari: {{payment}}. Toʻlov bajarilganini tasdiqlovchi hujjat saqlanadi. Hisob-kitob tartibi bitim kunidagi qonunchilik va notarius tekshiruvi asosida aniqlashtiriladi."
        ],
        [
          "Huquqlar va foydalanuvchilar",
          "Uchinchi shaxslar huquqlari, garov, taqiq va boshqa yuklamalar: {{rights}}. Sotuvdan keyin foydalanish huquqini saqlaydigan shaxslar va huquq asoslari: {{occupants}}. Mulkdorlar va zarur roziliklar notariusda tekshiriladi."
        ],
        [
          "Topshirish",
          "Mulkni boʻshatish, kalit va hujjatlarni berish, qarzdorlik hamda holatni qayd etish: {{handover}}. Taraflar alohida topshirish dalolatnomasini rasmiylashtiradi."
        ],
        [
          "Notarial rasmiylashtirish",
          "Bu blank bitim loyihasidir. Uy, kvartira yoki uning qismini sotish shartnomasi notarial tasdiqlanadi va davlat roʻyxatidan oʻtkaziladi. Bu sahifani chop etish yoki toʻldirish mulk huquqini oʻtkazmaydi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "civil"
      ],
      "note": "Notarius tekshiruvi, zarur roziliklar va davlat roʻyxati talab etiladi. Bu loyiha notarial shartnoma emas.",
      "status": "Notarius uchun loyiha"
    },
    {
      "id": "reklama-kontent",
      "category": "reklama",
      "title": "Kontent tayyorlash shartnomasi",
      "description": "Tasvirga olish, montaj va materiallarni topshirish.",
      "roles": [
        "Buyurtmachi",
        "Kontent ijrochisi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "brief",
        "quantity",
        "start",
        "end",
        "amount",
        "payment",
        "approval",
        "usage",
        "handover",
        "refund",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Topshiriq",
          "Ijrochi {{object}} boʻyicha {{quantity}} formatidagi materiallarni tayyorlaydi. Kelishilgan texnik topshiriq: {{brief}}. Ish davri: {{start}} — {{end}}."
        ],
        [
          "Tasvirga olish va montaj",
          "Buyurtmachi obyektga kirish va suratga olinadigan shaxslarning roziligini taʼminlaydi. Ijrochi kelishilgan tasvirga olish va montajni bajaradi. Musiqa, tasvir va boshqa materiallardan foydalanish huquqi ish boshlashdan oldin tekshiriladi."
        ],
        [
          "Tasdiqlash va topshirish",
          "Eskiz, matn yoki dastlabki montajni koʻrish, javob muddati va tuzatishlar: {{approval}}. Yakuniy fayllar: {{handover}}. Buyurtmachining eʼtirozlari yozma qayd etiladi."
        ],
        [
          "Haq va foydalanish huquqi",
          "Xizmat summasi: {{amount}} soʻm; toʻlov: {{payment}}. Yakuniy materiallardan foydalanish doirasi va huquq turi: {{usage}}. Kelishilmagan xom fayllar yoki foydalanish huquqlari avtomatik topshirilgan deb hisoblanmaydi."
        ],
        [
          "Bekor qilish va qaytarish",
          "Ish toʻxtatilganda bajarilgan bosqichlar hujjatlashtiriladi. Qaytariladigan mablagʻ va xarajatlar: {{refund}}. Kontent tayyorlashning oʻzi sotuv natijasi yoki koʻrishlar soniga kafolat emas."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "ads"
      ],
      "note": "Tasvirga olish va tarqatishga rozilik, materiallardan foydalanish huquqi hamda texnik topshiriqni ilova qiling.",
      "status": "Namuna"
    },
    {
      "id": "reklama-joylash",
      "category": "reklama",
      "title": "Reklama joylashtirish shartnomasi",
      "description": "Telegram, Instagram yoki saytda eʼlon chiqarish.",
      "roles": [
        "Reklama beruvchi",
        "Reklama tarqatuvchi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "channel",
        "quantity",
        "brief",
        "schedule",
        "approval",
        "amount",
        "payment",
        "adbudget",
        "report",
        "refund",
        "start",
        "end",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Reklama buyurtmasi",
          "Platforma va sahifa: {{channel}}. Materiallar soni va turi: {{quantity}}. Mazmun va maʼlumotlar: {{brief}}. Davr: {{start}} — {{end}}."
        ],
        [
          "Jadval va tasdiqlash",
          "Eʼlon sanasi, vaqti, saqlanish muddati va havola: {{schedule}}. Nashrdan oldingi tasdiq: {{approval}}. Reklama beruvchi narxlar, obyekt va ruxsat hujjatlarining haqiqiyligini tasdiqlaydi. Chalgʻituvchi yoki qonunga zid material joylashtirilmaydi."
        ],
        [
          "Haq va Target",
          "Joylashtirish haqi: {{amount}} soʻm; toʻlov: {{payment}}. Target reklama budjeti, uni kim toʻlashi va hisoboti: {{adbudget}}. Alohida kelishilmagan reklama budjeti xizmat haqiga kiritilgan deb olinmaydi."
        ],
        [
          "Hisobot va natija",
          "Nashr havolalari, skrinshot va statistikani topshirish: {{report}}. Koʻrish, murojaat yoki savdo boʻyicha prognozlar kafolat emas; kelishilgan xizmat nashr va tasdiqlangan ishlar bilan baholanadi."
        ],
        [
          "Nashr bajarilmaganda",
          "Platforma cheklovi yoki texnik nosozlik yuz bersa, taraflar yangi sanani yoxud bajarilmagan qism uchun hisob-kitobni kelishadi: {{refund}}. Reklamaga oid material va tasdiqlar qonunchilikdagi muddat davomida saqlanadi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "ads"
      ],
      "note": "Platforma, aniq nashrlar soni, sana va Target budjetini alohida belgilang.",
      "status": "Namuna"
    },
    {
      "id": "novostroyka-hamkorlik",
      "category": "novostroyka",
      "title": "Quruvchi bilan sotuv hamkorligi",
      "description": "Majmua marketingi va sotuv xizmatlari.",
      "roles": [
        "Quruvchi / buyurtmachi",
        "Xizmat ijrochisi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "project",
        "permits",
        "service",
        "start",
        "end",
        "fee",
        "payment",
        "report",
        "certificate",
        "insurance",
        "refund",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Loyiha va xizmatlar",
          "Majmua: {{project}}. Loyiha, yer va qurilish hujjatlari: {{permits}}. Ijrochining marketing, mijozlar bilan ishlash va sotuv xizmatlari: {{service}}."
        ],
        [
          "Hamkorlik chegaralari",
          "Xizmatlar {{start}} — {{end}} davrida koʻrsatiladi. Quruvchi obyekt, narxlar va muddatlar toʻgʻrisida ishonchli maʼlumot beradi. Ijrochi faqat kelishilgan maʼlumotlarni reklama qiladi. Xizmat shartnomasi ijrochiga ulushdor pulini qabul qilish huquqini bermaydi."
        ],
        [
          "Xizmat haqi",
          "Haqning hisoblash asosi va uni vujudga keltiradigan natija: {{fee}}. Toʻlov: {{payment}}. Hisobot va xizmatni qabul qilish: {{report}}. Qaytarish tartibi: {{refund}}."
        ],
        [
          "Xaridor mablagʻlari",
          "Qurilayotgan obyekt uchun ulushdor mablagʻlarini jalb qilish tegishli eskrou va rasmiylashtirish tartibiga boʻysunadi. Xaridor bilan alohida bitim hujjatlari tuziladi. Ushbu hamkorlik blankasi ulushli qurilish shartnomasini almashtirmaydi."
        ],
        [
          "Masʼullar va hujjatlar",
          "Rieltorlik xizmati bajarilsa, masʼul sertifikati: {{certificate}}; sugʻurta polisi: {{insurance}}. Xizmat vakolatlari, narx matritsasi va tasdiqlangan reklama materiallari ilova qilinadi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "realtor",
        "escrow",
        "ads"
      ],
      "note": "Quruvchi bilan xizmat hamkorligi. Ulushdor mablagʻlarini agentlik kartasiga jalb qilish uchun moʻljallanmagan.",
      "status": "Namuna"
    },
    {
      "id": "novostroyka-ulush",
      "category": "novostroyka",
      "title": "Ulushli qurilish bitimi loyihasi",
      "description": "Bank va notarius uchun muhim shartlar loyihasi.",
      "roles": [
        "Quruvchi",
        "Ulushdor"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "project",
        "unit",
        "permits",
        "area",
        "price",
        "payment",
        "bank",
        "completion",
        "handover",
        "refund",
        "rights",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Qurilish va xonadon",
          "Majmua va quruvchi: {{project}}. Xonadon identifikatori, qavat, blok va chizma: {{unit}}. Loyihadagi maydon: {{area}} m². Qurilish va loyiha hujjatlari: {{permits}}."
        ],
        [
          "Baho va eskrou",
          "Kelishilgan narx: {{price}} soʻm. Toʻlov jadvali: {{payment}}. Bank va eskrou hisobvaragʻi: {{bank}}. Ulushdor mablagʻlari amaldagi eskrou tartibiga muvofiq jalb qilinadi; oddiy shaxsiy kartaga toʻlov ushbu shartning oʻrnini bosmaydi."
        ],
        [
          "Muddat va sifat",
          "Qurilish yakuni, foydalanish ruxsati, pardoz va sifat mezonlari: {{completion}}. Xonadonni topshirish, oʻlchovdagi farq va nuqsonlar dalolatnomasi tartibi: {{handover}}."
        ],
        [
          "Huquqlar va javobgarlik",
          "Loyihaga oid yuklamalar va uchinchi shaxslar huquqlari: {{rights}}. Kechikish, loyihaning bajarilmasligi, bekor qilish va qaytarish: {{refund}}. Bankning eskrou shartlari bilan moslik alohida tekshiriladi."
        ],
        [
          "Yakuniy rasmiylashtirish",
          "Bu loyiha quruvchi, bank va notarius bilan kelishishga xizmat qiladi. Majburiy rasmiylashtirish va roʻyxatdan oʻtkazish tugamaguncha ushbu sahifa bank yoki notarius hujjati oʻrnini bosmaydi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "escrow",
        "civil"
      ],
      "note": "Ulushli qurilish uchun bank, eskrou, quruvchi ruxsatlari va notarial/roʻyxat talablari alohida tekshiriladi.",
      "status": "Bank / notarius uchun loyiha"
    },
    {
      "id": "ipoteka-xizmat",
      "category": "ipoteka",
      "title": "Ipoteka boʻyicha maslahat xizmati",
      "description": "Hujjat tayyorlash va bankka murojaat qilishda yordam.",
      "roles": [
        "Buyurtmachi",
        "Maslahat xizmati ijrochisi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "service",
        "start",
        "end",
        "amount",
        "payment",
        "report",
        "refund",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Xizmat predmeti",
          "{{object}} uchun maslahat va hujjat tayyorlash doirasi: {{service}}. Ijrochi mijoz topshirigʻi doirasida xizmat qiladi; bank nomidan kredit ajratish majburiyatini olmaydi."
        ],
        [
          "Muddat va hamkorlik",
          "Xizmat davri: {{start}} — {{end}}. Buyurtmachi bank talab qilgan haqiqiy maʼlumotlarni beradi. Bank bilan aloqa va hujjat topshirish vakolati zarur boʻlsa alohida rasmiylashtiriladi."
        ],
        [
          "Haq va natija",
          "Xizmat haqi: {{amount}} soʻm. Toʻlov: {{payment}}. Bajarilgan ishlar va topshirilgan hujjatlar: {{report}}. Bank rad javobida yoki bajarilmagan xizmatda hisob-kitob: {{refund}}."
        ],
        [
          "Bank qarori",
          "Kredit summasi, foizi, toʻlov jadvali va taʼminotini bank belgilaydi. Kredit yoki subsidiya ajratilishi ushbu shartnoma bilan kafolatlanmaydi. Kredit va ipoteka hujjatlari bankda alohida rasmiylashtiriladi."
        ],
        [
          "Maʼlumotlar",
          "Shaxsga doir hujjatlar xizmatni bajarish uchun zarur hajmda va buyurtmachining qonuniy roziligi asosida olinadi; ularni bankka topshirish doirasi kelishiladi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "civil",
        "mortgage"
      ],
      "note": "Bu bank krediti yoki garov shartnomasi emas, maslahat xizmati namunasidir.",
      "status": "Namuna"
    },
    {
      "id": "ipoteka-garov",
      "category": "ipoteka",
      "title": "Ipoteka (garov) loyihasi",
      "description": "Bankda rasmiylashtirish uchun garov shartlari.",
      "roles": [
        "Ipotekaga qoʻyuvchi",
        "Ipotekaga oluvchi"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "cadastre",
        "area",
        "ownership",
        "registry",
        "rights",
        "loan",
        "debt",
        "valuation",
        "insurance",
        "handover",
        "refund",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Garov obyekti",
          "Garov predmeti: {{object}}, kadastr {{cadastre}}, maydon {{area}} m². Huquq asosi: {{ownership}}. Roʻyxatdan oʻtkazuvchi organ va yozuv: {{registry}}. Obyektning kimda qolishi: {{handover}}."
        ],
        [
          "Taʼminlanayotgan majburiyat",
          "Kredit yoki boshqa asosiy shartnoma: {{loan}}. Qarzdorlik mazmuni, miqdori, foizi, bajarish muddati va jadvali: {{debt}}."
        ],
        [
          "Qiymat, yuklamalar va sugʻurta",
          "Garov qiymati va baholash asosi: {{valuation}}. Boshqa shaxslarning huquqlari va cheklovlar: {{rights}}. Sugʻurta shartlari: {{insurance}}. Zarur mulkdor roziliklari va vakolatlar tekshiriladi."
        ],
        [
          "Foydalanish va buzilish oqibatlari",
          "Mulk asraladi, jiddiy zarar va huquqiy yuklamalar haqida kreditor xabardor qilinadi. Majburiyat buzilganda undiruv qonunda ruxsat etilgan tartibda amalga oshiriladi. Taraflarning kelishilgan hisob-kitobi: {{refund}}."
        ],
        [
          "Bank va davlat roʻyxati",
          "Loyiha bankning kredit hujjatlari bilan moslashtiriladi. Qonunda talab qilingan notarial tasdiq va davlat roʻyxati bajariladi. Oddiy blankni toʻldirish ipotekani davlat roʻyxatidan oʻtkazmaydi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "mortgage"
      ],
      "note": "Bank / notarius bilan yakunlanadigan loyiha. UY MARKET logosi uni bank tomonidan tasdiqlangan hujjatga aylantirmaydi.",
      "status": "Bank / notarius uchun loyiha"
    },
    {
      "id": "baholash-xizmat",
      "category": "baholash",
      "title": "Koʻchmas mulkni baholash shartnomasi",
      "description": "Vakolatli baholovchi bilan hisobot tayyorlash.",
      "roles": [
        "Buyurtmachi",
        "Baholovchi tashkilot"
      ],
      "fields": [
        "number",
        "city",
        "date",
        "a",
        "a_id",
        "a_rep",
        "a_address",
        "a_phone",
        "a_bank",
        "b",
        "b_id",
        "b_rep",
        "b_address",
        "b_phone",
        "b_bank",
        "object",
        "cadastre",
        "ownership",
        "purpose",
        "value_type",
        "value_date",
        "start",
        "end",
        "amount",
        "payment",
        "certificate",
        "insurance",
        "assumptions",
        "report",
        "refund",
        "notice",
        "extra"
      ],
      "sections": [
        [
          "Obyekt va maqsad",
          "Baholash obyekti: {{object}}, kadastr {{cadastre}}. Huquq asosi: {{ownership}}. Baholash maqsadi: {{purpose}}. Aniqlanadigan qiymat turi: {{value_type}}. Baholash sanasi: {{value_date}}."
        ],
        [
          "Ish hajmi va muddat",
          "Ish {{start}} — {{end}} oraligʻida bajariladi. Buyurtmachi hujjatlar va obyektga kirishni taʼminlaydi. Farazlar, cheklovlar va natijadan foydalanish doirasi: {{assumptions}}."
        ],
        [
          "Malaka va mustaqillik",
          "Baholovchi malaka sertifikati: {{certificate}}. Tashkilotning javobgarlik sugʻurtasi: {{insurance}}. Ijrochi manfaatlar toʻqnashuvini oshkor qiladi va baholashni mustaqil amalga oshiradi."
        ],
        [
          "Haq va hisobot",
          "Ish haqi: {{amount}} soʻm; toʻlov: {{payment}}. Haq aniqlangan qiymatning baland-pastligiga bogʻlanmaydi. Hisobot va uni topshirish shakli: {{report}}. Bajarilmagan qism hisob-kitobi: {{refund}}."
        ],
        [
          "Natija",
          "Natija amaldagi baholash standartlariga mos yozma hisobot bilan beriladi. Mijoz xohlagan qiymatni chiqarish majburiyati olinmaydi. Agentlikning oddiy bozor maslahati rasmiy baholash hisobotini almashtirmaydi."
        ],
        [
          "Oʻzgartirish, javobgarlik va nizolar",
          "Kelishuvga oʻzgartirishlar taraflar imzolagan yozma qoʻshimcha bilan kiritiladi. Majburiyat buzilganda aybdor taraf qonunchilik va shartnoma doirasida javob beradi. Nizo avval muzokara, hal boʻlmasa vakolatli sud orqali koʻriladi. Bekor qilish va yakuniy hisob-kitob: {{notice}}."
        ],
        [
          "Qoʻshimcha shartlar va nusxalar",
          "Taraflar kelishgan qoʻshimcha shartlar: {{extra}}. Imzolangan ilovalar hujjatning bir qismi hisoblanadi. Har bir tarafga bir nusxa beriladi."
        ]
      ],
      "sources": [
        "valuation"
      ],
      "note": "Ijrochi sifatida vakolatli baholovchi tashkilotning haqiqiy rekvizitlari kiritiladi. Sertifikat va sugʻurta maʼlumotlari zarur.",
      "status": "Namuna"
    }
  ]
};
