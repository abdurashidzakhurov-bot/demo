/* Contract library and local-only document preparation. No personal data is persisted. */
(() => {
 'use strict';
 const D=window.UM_CONTRACTS, $=s=>document.querySelector(s);
 if(!D) return;
 let activeField="";
 const signatures={};
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const icons={ijara:'M3 11 12 3l9 8M5 10v11h14V10M10 21v-7h4v7',sotuv:'M3 10V4h6l12 12-9 7zM6 7h.01',reklama:'M3 10v5h4l11 5V5L7 10H3zM7 15l2 7',novostroyka:'M4 21V3h12v18M16 10h5v11M8 7h4M8 11h4M8 15h4',ipoteka:'M3 6h18v14H3zM3 10h18M7 16h4',baholash:'M4 21V3M4 21h17M8 16l4-5 4 2 5-7'};
 const ico=cat=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[cat]}"/></svg>`;
 const category=id=>D.categories.find(c=>c[0]===id);
 const fieldLabel=k=>D.fields[k]?.[0]||k;
 function value(k,values){const v=values[k]?.trim();return `<span data-doc-field="${esc(k)}" class="${v?"doc-value":"doc-blank"}${activeField===k?" is-editing":""}">${v?esc(v):"["+esc(fieldLabel(k))+"]"}</span>`;}
 function text(t,values){return esc(t).replace(/\{\{(\w+)\}\}/g,(_,k)=>value(k,values));}
 function paper(doc,values={}) {
  return `<article class="contract-paper" lang="uz" translate="no"><header class="paper-brand"><div><img src="assets/img/logo.png" alt="UY MARKET"><span><b>UY MARKET</b><small>Koʻchmas mulk agentligi</small></span></div><span class="paper-status">${esc(doc.status)}</span></header><h1>${esc(doc.title)}</h1><div class="paper-meta"><span>№ ${value('number',values)}</span><span>${value('city',values)} · ${value('date',values)}</span></div><p class="paper-intro">${value('a',values)} (${esc(doc.roles[0])}) hamda ${value('b',values)} (${esc(doc.roles[1])}) quyidagilarni kelishadi. Vakillar va vakolatlar quyidagi rekvizitlarda qayd etiladi.</p>${doc.sections.map(([title,body],i)=>`<section class="paper-clause"><h2>${i+1}. ${esc(title)}</h2><p>${text(body,values)}</p></section>`).join('')}<section class="paper-clause"><h2>${doc.sections.length+1}. Taraflarning rekvizitlari va imzolari</h2><div class="paper-parties">${['a','b'].map((k,i)=>`<div><h3>${esc(doc.roles[i])}</h3><p>${value(k,values)}</p><p>ID / STIR: ${value(k+'_id',values)}</p><p>Vakil va asos: ${value(k+'_rep',values)}</p><p>Manzil: ${value(k+'_address',values)}</p><p>Aloqa: ${value(k+'_phone',values)}</p><p>Bank: ${value(k+'_bank',values)}</p><div class="paper-sign">${signatures[k]?`<img class="paper-signature-img" src="${signatures[k]}" alt="${esc(doc.roles[i])} imzo tasviri">`:`<span>Imzo __________________</span>`}<button class="paper-sign-button" type="button" data-sign="${k}">${signatures[k]?"Imzoni oʻzgartirish":"Imzo qoʻyish"}</button></div></div>`).join('')}</div></section><aside class="paper-guidance"><b>Rasmiylashtirish eslatmasi</b><p>${esc(doc.note)}</p><p>Namuna · huquqiy manbalar 01.11.2026 holatiga koʻrib chiqilgan. Imzolashdan oldin vakolatli mutaxassis bilan tekshiring.</p>${doc.sources.map(k=>`<a href="${D.sources[k].url}" target="_blank" rel="noopener">${esc(D.sources[k].title)} ↗</a>`).join('')}</aside></article>`;
 }
 const grid=$('#contract-grid'), dialog=$('#contract-dialog');
 if(grid){
  let active='all',opener=null,oldOverflow='';
  const filters=$('#contract-filters');
  filters.innerHTML=[['all','Barchasi'],...D.categories].map(([id,title])=>`<button type="button" data-category="${id}" aria-pressed="${id==='all'}">${esc(title)}</button>`).join('');
  function render(){
   const docs=D.templates.filter(d=>active==='all'||d.category===active);
   grid.innerHTML=docs.map((d,i)=>`<button class="contract-card" type="button" data-contract="${d.id}" data-contract-category="${d.category}" aria-label="${esc(d.title)} — blankani koʻrish"><span class="cc-top"><span>${ico(d.category)}${esc(category(d.category)[1].replace(' shartnomasi',''))}</span><span class="cc-index">${String(i+1).padStart(2,'0')}</span></span><span class="cc-paper" aria-hidden="true"><span class="cc-brand"><img src="assets/img/logo.png" alt="">UY MARKET</span><strong>${esc(d.title)}</strong><span class="cc-mini-meta">№ ____ &nbsp; · &nbsp; Sana ____</span><i></i><i></i><i></i><span class="cc-signs"><i></i><i></i></span><span class="cc-seal">UM</span></span><span class="cc-label">${esc(d.status)}</span><h3>${esc(d.title)}</h3><p>${esc(d.description)}</p><span class="cc-action">Blankani koʻrish <span aria-hidden="true">↗</span></span></button>`).join('');
   $('#contract-count').textContent=`${docs.length} ta blanka`;
   $('#contract-empty').hidden=docs.length>0;
  }
  filters.addEventListener('click',e=>{const b=e.target.closest('[data-category]');if(!b)return;active=b.dataset.category;filters.querySelectorAll('button').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));render();});
  grid.addEventListener('click',e=>{const b=e.target.closest('[data-contract]');if(!b)return;const d=D.templates.find(x=>x.id===b.dataset.contract);opener=b;$('#contract-dialog-title').textContent=d.title;$('#contract-preview').innerHTML=paper(d);$('#contract-prepare').href=`contract-editor.html?template=${encodeURIComponent(d.id)}`;oldOverflow=document.body.style.overflow;dialog.showModal();document.body.style.overflow='hidden';dialog.querySelector('.contract-dialog-scroll').scrollTop=0;});
  dialog.querySelector('.contract-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
  dialog.addEventListener('close',()=>{document.body.style.overflow=oldOverflow;opener?.focus();});
  $('#contract-sources').innerHTML=Object.values(D.sources).map(s=>`<a href="${s.url}" target="_blank" rel="noopener">${esc(s.title)} ↗</a>`).join('');
  render(); document.title='Shartnomalar — UY MARKET';
  document.addEventListener('langchange',()=>{document.title='Shartnomalar — UY MARKET';});
 }
 const form=$('#contract-fields');
 if(form){
  const id=new URLSearchParams(location.search).get('template');
  const doc=D.templates.find(d=>d.id===id);
  if(!doc){$('#editor-title').textContent='Blanka tanlanmagan';$('#editor-note').textContent='Shartnomalar sahifasidan kerakli hujjatni tanlang.';$('#contract-print').hidden=true;form.hidden=true;return;}
  $('#editor-title').textContent=doc.title;$('#editor-note').textContent=doc.note;
  document.title=doc.title+' — UY MARKET';
  document.addEventListener('langchange',()=>{document.title=doc.title+' — UY MARKET';});
  const values={};
  const groups=[['Hujjat haqida',doc.fields.filter(k=>['number','city','date'].includes(k))],[doc.roles[0],doc.fields.filter(k=>k==='a'||k.startsWith('a_'))],[doc.roles[1],doc.fields.filter(k=>k==='b'||k.startsWith('b_'))],['Obyekt va kelishuv shartlari',doc.fields.filter(k=>!['number','city','date','a','b'].includes(k)&&!k.startsWith('a_')&&!k.startsWith('b_'))]];
  form.innerHTML='<div class="cf-heading"><h2>Maʼlumotlarni kiriting</h2><p>Boʻsh joylar hujjatda belgilangan holda qoladi.</p><button class="cf-locate" type="button" hidden>Hujjatdagi joyni koʻrish ↗</button></div>'+groups.map(([title,keys])=>`<fieldset><legend>${esc(title)}</legend>${keys.map(k=>{const [label,ph,type]=D.fields[k];return `<label for="cf-${k}">${esc(label)}${type==='textarea'?`<textarea id="cf-${k}" name="${k}" rows="3" maxlength="5000" placeholder="${esc(ph)}"></textarea>`:`<input id="cf-${k}" name="${k}" type="${type==='date'?'date':'text'}" maxlength="1000" placeholder="${esc(ph)}">`}</label>`;}).join('')}</fieldset>`).join('');
  const panel=$('.editor-document'),workspace=$('.editor-layout');
  function fitPanes(){const top=Math.max(105,workspace.getBoundingClientRect().top);workspace.style.setProperty('--pane-height',Math.max(260,innerHeight-top-20)+'px');}
  window.addEventListener('resize',fitPanes);window.addEventListener('scroll',fitPanes,{passive:true});fitPanes();
  const focusBanner=document.createElement('div');focusBanner.className='editor-focus-banner';focusBanner.innerHTML='<span>Toʻldirilayotgan joy</span><b id="editor-active-field">Maydonni tanlang</b>';panel.prepend(focusBanner);
  function revealActive(){
   if(!activeField)return;
   const target=panel.querySelector(`[data-doc-field="${activeField}"]`);
   if(!target)return;
   if(panel.scrollHeight>panel.clientHeight){
    const p=panel.getBoundingClientRect(),t=target.getBoundingClientRect();
    panel.scrollTop+=t.top-p.top-Math.max(90,panel.clientHeight*.38);
   }
  }
  function update(){ $('#editor-paper').innerHTML=paper(doc,values);const n=doc.fields.filter(k=>values[k]?.trim()).length;$('#editor-progress').textContent=`${n} / ${doc.fields.length} maydon toʻldirilgan`; $('#editor-active-field').textContent=activeField?fieldLabel(activeField):'Maydonni tanlang'; revealActive(); }

  const sigSection=document.createElement('fieldset');sigSection.className='cf-signatures';sigSection.innerHTML='<legend>Taraflarning imzolari</legend>'+doc.roles.map((role,i)=>`<button class="cf-sign-button" type="button" data-sign="${i?'b':'a'}"><span>${esc(role)}</span><b>Imzo qoʻyish ↗</b></button>`).join('');form.append(sigSection);

  form.querySelectorAll('fieldset').forEach((section,i)=>{
   const legend=section.querySelector('legend'),title=legend.textContent;
   const body=document.createElement('div');body.className='cf-group-body';body.id='cf-group-'+i;
   Array.from(section.children).filter(e=>e!==legend).forEach(e=>body.append(e));
   legend.innerHTML=`<button type="button" class="cf-group-toggle" aria-expanded="true" aria-controls="${body.id}"><span>${esc(title)}</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button>`;
   section.append(body);
  });
  form.addEventListener('click',e=>{
   const toggle=e.target.closest('.cf-group-toggle');if(!toggle)return;
   const open=toggle.getAttribute('aria-expanded')==='true';toggle.setAttribute('aria-expanded',String(!open));
   document.getElementById(toggle.getAttribute('aria-controls')).hidden=open;
  });

  const sigDialog=document.createElement('dialog');sigDialog.className='signature-dialog';sigDialog.setAttribute('aria-labelledby','signature-title');sigDialog.innerHTML=`<div class="sig-header"><div><span>UY MARKET · Imzo tasviri</span><h2 id="signature-title">Imzo qoʻyish</h2></div><button type="button" data-sig-close aria-label="Yopish">×</button></div><div class="sig-tools" role="group" aria-label="Chizish vositalari"><button type="button" data-sig-tool="pen" aria-pressed="true">✎ Qalam</button><button type="button" data-sig-tool="eraser" aria-pressed="false">Oʻchirgʻich</button><button type="button" data-sig-clear>Tozalash</button></div><div class="signature-pad"><canvas width="1200" height="600" aria-label="Imzo chizish maydoni"></canvas><span aria-hidden="true">Shu yerga imzo chizing</span></div><p class="sig-info">Sichqoncha yoki barmoq bilan chizing. Bu imzo tasviri, E-IMZO bilan tasdiqlash emas.</p><p class="sig-status" role="status" aria-live="polite"></p><div class="sig-footer"><button type="button" class="btn btn-outline btn-sm" data-sig-remove><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/></svg>Imzoni oʻchirish</button><button type="button" class="btn btn-primary btn-sm" data-sig-save>Saqlash</button></div>`;document.body.append(sigDialog);
  const canvas=sigDialog.querySelector('canvas'),ctx=canvas.getContext('2d');let signingParty='a',tool='pen',drawing=false,last=null,sigOpener=null,previousOverflow='';
  function updatePadHint(){sigDialog.querySelector('.signature-pad>span').hidden=hasInk();}
  function hasInk(){const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;for(let i=3;i<pixels.length;i+=4)if(pixels[i]>8)return true;return false;}
  function setTool(t){tool=t;sigDialog.querySelectorAll('[data-sig-tool]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.sigTool===t)));canvas.style.cursor=t==='pen'?'crosshair':'cell';}
  function openSignature(party,opener){signingParty=party;sigOpener=opener;$('#signature-title').textContent=doc.roles[party==='a'?0:1]+' · imzo';ctx.globalCompositeOperation='source-over';ctx.clearRect(0,0,canvas.width,canvas.height);sigDialog.querySelector('.sig-status').textContent='';setTool('pen');if(signatures[party]){const img=new Image();img.onload=()=>{ctx.drawImage(img,0,0);updatePadHint();};img.src=signatures[party];}previousOverflow=document.body.style.overflow;sigDialog.showModal();document.body.style.overflow='hidden';updatePadHint();}
  function point(e){const b=canvas.getBoundingClientRect();return {x:(e.clientX-b.left)*canvas.width/b.width,y:(e.clientY-b.top)*canvas.height/b.height};}
  function stroke(a,b){ctx.globalCompositeOperation=tool==='eraser'?'destination-out':'source-over';ctx.strokeStyle='#143f82';ctx.fillStyle='#143f82';ctx.lineWidth=tool==='eraser'?45:4.5;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}
  canvas.addEventListener('pointerdown',e=>{if(e.button!==0&&e.pointerType==='mouse')return;e.preventDefault();drawing=true;last=point(e);canvas.setPointerCapture(e.pointerId);stroke(last,{x:last.x+.1,y:last.y+.1});sigDialog.querySelector('.signature-pad>span').hidden=true;});
  canvas.addEventListener('pointermove',e=>{if(!drawing)return;const next=point(e);stroke(last,next);last=next;});
  const stop=e=>{drawing=false;last=null;if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);updatePadHint();};canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',stop);
  sigDialog.querySelectorAll('[data-sig-tool]').forEach(b=>b.addEventListener('click',()=>setTool(b.dataset.sigTool)));
  sigDialog.querySelector('[data-sig-clear]').addEventListener('click',()=>{ctx.clearRect(0,0,canvas.width,canvas.height);updatePadHint();sigDialog.querySelector('.sig-status').textContent='Maydon tozalandi.';});
  sigDialog.querySelector('[data-sig-save]').addEventListener('click',()=>{if(!hasInk()){sigDialog.querySelector('.sig-status').textContent='Avval imzo chizing yoki oynani yoping.';return;}signatures[signingParty]=canvas.toDataURL('image/png');update();sigDialog.close();});
  sigDialog.querySelector('[data-sig-remove]').addEventListener('click',()=>{delete signatures[signingParty];ctx.clearRect(0,0,canvas.width,canvas.height);update();sigDialog.close();});
  sigDialog.querySelector('[data-sig-close]').addEventListener('click',()=>sigDialog.close());
  sigDialog.addEventListener('close',()=>{drawing=false;document.body.style.overflow=previousOverflow;if(sigOpener?.isConnected)sigOpener.focus({preventScroll:true});});
  form.addEventListener('click',e=>{const b=e.target.closest('[data-sign]');if(b)openSignature(b.dataset.sign,b);});
  panel.addEventListener('click',e=>{const b=e.target.closest('[data-sign]');if(b)openSignature(b.dataset.sign,b);});

  form.addEventListener('submit',e=>e.preventDefault());
  form.addEventListener('focusin',e=>{
   if(!doc.fields.includes(e.target.name))return;
   activeField=e.target.name;
   form.querySelectorAll('.is-active-field').forEach(x=>x.classList.remove('is-active-field'));
   e.target.closest('label').classList.add('is-active-field');
   form.querySelector('.cf-locate').hidden=false;
   update();
  });
  form.querySelector('.cf-locate').addEventListener('click',()=>{
   const target=panel.querySelector(`[data-doc-field="${activeField}"]`);
   if(target){panel.scrollIntoView({block:'start',behavior:'auto'});revealActive();}
  });

  form.addEventListener('input',e=>{if(!doc.fields.includes(e.target.name))return;values[e.target.name]=e.target.value;update();});
  $('#contract-print').addEventListener('click',()=>{update();window.print();});
  update();
 }
})();
