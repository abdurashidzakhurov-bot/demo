/* Branded bank details. Numbers supplied by the company for this Site. */
(() => {
  const cards = {
    humo: { number: '9860060108883293', label: 'HUMO', colors: ['#24b8e4','#128ac2','#12618e'] },
    uzcard: { number: '5614682814394617', label: 'UZCARD', colors: ['#2569df','#174bb5','#112e78'] }
  };
  const copy = {
    uz: {title:'Bank kartasi', download:'Yuklab olish', share:'Ulashish', close:'Yopish', loading:'Karta tayyorlanmoqda…', error:'Karta tayyorlanmadi. Qayta urinib ko‘ring.', hint:'PNG yuklab olindi. Telegramda chatni tanlab, faylni biriktiring.', open:'Telegramni ochish', agency:'KO‘CHMAS MULK AGENTLIGI'},
    ru: {title:'Банковская карта', download:'Скачать', share:'Поделиться', close:'Закрыть', loading:'Подготовка карты…', error:'Не удалось подготовить карту. Повторите попытку.', hint:'PNG скачан. Выберите чат в Telegram и прикрепите файл.', open:'Открыть Telegram', agency:'АГЕНТСТВО НЕДВИЖИМОСТИ'},
    en: {title:'Bank card', download:'Download', share:'Share', close:'Close', loading:'Preparing card…', error:'Could not prepare the card. Please try again.', hint:'PNG downloaded. Choose a Telegram chat and attach the file.', open:'Open Telegram', agency:'REAL ESTATE AGENCY'}
  };
  const language = () => copy[document.documentElement.lang] ? document.documentElement.lang : 'uz';
  const text = () => copy[language()];
  const svg = path => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"/></svg>`;
  const dialog = document.createElement('dialog');
  dialog.className = 'payment-dialog';
  dialog.setAttribute('aria-labelledby', 'payment-title');
  dialog.innerHTML = `<div class="payment-head"><h2 id="payment-title"></h2><button class="payment-close" type="button">${svg('M6 6l12 12M18 6 6 18')}</button></div>
    <div class="payment-toolbar"><div class="payment-types" role="group" aria-label="Card type"><button type="button" data-card-type="humo">HUMO</button><button type="button" data-card-type="uzcard">UZCARD</button></div>
    <div class="payment-actions"><button type="button" data-card-download>${svg('M12 3v12M7 10l5 5 5-5M4 20h16')}<span></span></button><button type="button" data-card-share>${svg('M22 2 11 13M22 2l-7 20-4-9-9-4z')}<span></span></button></div></div>
    <div class="payment-stage"><canvas width="1800" height="1125" role="img"></canvas></div><p class="payment-status" role="status" aria-live="polite"></p>`;
  document.body.appendChild(dialog);
  const canvas = dialog.querySelector('canvas'), ctx = canvas.getContext('2d');
  const downloadButton = dialog.querySelector('[data-card-download]'), shareButton = dialog.querySelector('[data-card-share]');
  const status = dialog.querySelector('.payment-status');
  const logo = new Image(); logo.src = new URL('assets/img/logo.png', document.baseURI).href;
  const logoReady = new Promise(resolve => { logo.onload = resolve; logo.onerror = resolve; if (logo.complete) resolve(); });
  let type = 'humo', file = null, revision = 0, opener = null, oldOverflow = '';
  function round(x,y,w,h,r,fill) { ctx.beginPath(); ctx.roundRect(x,y,w,h,r); ctx.fillStyle=fill; ctx.fill(); }
  function draw() {
    const card = cards[type];
    ctx.clearRect(0,0,1800,1125); ctx.save();
    ctx.beginPath(); ctx.roundRect(0,0,1800,1125,85); ctx.clip();
    const bg=ctx.createLinearGradient(0,0,1800,1125);bg.addColorStop(0,card.colors[0]);bg.addColorStop(.48,card.colors[1]);bg.addColorStop(1,card.colors[2]);ctx.fillStyle=bg;ctx.fillRect(0,0,1800,1125);
    const light=ctx.createRadialGradient(1180,110,0,1180,110,1050);light.addColorStop(0,'rgba(119,218,255,.38)');light.addColorStop(1,'rgba(119,218,255,0)');ctx.fillStyle=light;ctx.fillRect(0,0,1800,1125);
    ctx.strokeStyle='rgba(255,255,255,.12)';ctx.lineWidth=2;
    for(let i=0;i<6;i++){ctx.beginPath();ctx.arc(1740,1120,520+i*95,Math.PI,Math.PI*1.6);ctx.stroke();}
    if(logo.naturalWidth){ctx.save();ctx.filter='brightness(0) invert(1)';ctx.drawImage(logo,110,100,118,118*logo.naturalHeight/logo.naturalWidth);ctx.restore();}
    ctx.fillStyle='#fff';ctx.font='600 62px Helvetica Neue, Arial, sans-serif';ctx.fillText('UY MARKET',255,176);
    ctx.font='600 66px Helvetica Neue, Arial, sans-serif';ctx.textAlign='right';ctx.fillText(card.label,1680,176);ctx.textAlign='left';
    const metal=ctx.createLinearGradient(120,430,320,570);metal.addColorStop(0,'#ffefb6');metal.addColorStop(.5,'#dac087');metal.addColorStop(1,'#b79458');round(120,430,208,158,24,metal);
    ctx.strokeStyle='rgba(105,78,32,.65)';ctx.lineWidth=3;ctx.strokeRect(187,430,73,158);ctx.beginPath();ctx.moveTo(120,482);ctx.lineTo(187,482);ctx.moveTo(120,535);ctx.lineTo(187,535);ctx.moveTo(260,482);ctx.lineTo(328,482);ctx.moveTo(260,535);ctx.lineTo(328,535);ctx.stroke();
    ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=9;ctx.lineCap='round';for(let i=0;i<3;i++){ctx.beginPath();ctx.arc(370,510,32+i*25,-.7,.7);ctx.stroke();}
    ctx.font='500 120px ui-monospace, Menlo, monospace';ctx.fillStyle='#fff';ctx.fillText(card.number.match(/.{4}/g).join(' '),115,775);
    ctx.fillStyle='#fff';ctx.font='500 46px Helvetica Neue, Arial, sans-serif';ctx.fillText('A.Kamolov',120,890);
    const agency=language()==='uz' && window.uzAlphabet ? window.uzAlphabet(text().agency) : text().agency;
    ctx.fillStyle='rgba(255,255,255,.72)';ctx.font='500 29px Helvetica Neue, Arial, sans-serif';ctx.fillText(agency,120,1010);
    ctx.textAlign='right';ctx.font='500 32px Helvetica Neue, Arial, sans-serif';ctx.fillText(card.label,1680,1010);ctx.restore();
    ctx.strokeStyle='rgba(255,255,255,.3)';ctx.lineWidth=3;ctx.beginPath();ctx.roundRect(2,2,1796,1121,84);ctx.stroke();
    canvas.setAttribute('aria-label',`UY MARKET · ${card.label} · A.Kamolov`);
  }
  async function paint() {
    const token=++revision; file=null; downloadButton.disabled=true;shareButton.disabled=true;
    dialog.querySelector('#payment-title').textContent=text().title;
    dialog.querySelector('.payment-close').setAttribute('aria-label',text().close);
    downloadButton.querySelector('span').textContent=text().download;shareButton.querySelector('span').textContent=text().share;
    dialog.querySelectorAll('[data-card-type]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.cardType===type)));
    status.textContent=text().loading;
    await logoReady;if(token!==revision)return;draw();
    canvas.toBlob(blob=>{if(token!==revision)return;if(!blob){status.textContent=text().error;return;}file=new File([blob],`uy-market-${type}.png`,{type:'image/png'});downloadButton.disabled=false;shareButton.disabled=false;status.textContent='';},'image/png');
  }
  function download(){if(!file)return;const url=URL.createObjectURL(file),a=document.createElement('a');a.href=url;a.download=file.name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
  function fallback(){if(navigator.userActivation?.isActive)window.open('https://web.telegram.org/k/','_blank','noopener,noreferrer');download();status.textContent=text().hint;const a=document.createElement('a');a.href='https://web.telegram.org/k/';a.target='_blank';a.rel='noopener noreferrer';a.textContent=text().open;status.append(document.createTextNode(' '),a);}
  function close(){dialog.close();}
  document.addEventListener('click',e=>{const b=e.target.closest('[data-open-payment]');if(!b)return;opener=b;oldOverflow=document.body.style.overflow;document.body.style.overflow='hidden';dialog.showModal();paint();});
  dialog.querySelector('.payment-close').addEventListener('click',close);
  dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close();}});
  dialog.addEventListener('close',()=>{document.body.style.overflow=oldOverflow;opener?.focus();});
  dialog.querySelectorAll('[data-card-type]').forEach(b=>b.addEventListener('click',()=>{type=b.dataset.cardType;paint();}));
  downloadButton.addEventListener('click',download);
  shareButton.addEventListener('click',async()=>{if(!file)return;if(navigator.share&&navigator.canShare?.({files:[file]})){try{await navigator.share({files:[file],title:'UY MARKET'});}catch(e){if(e?.name!=='AbortError')fallback();}}else fallback();});
  document.addEventListener('langchange',()=>{if(dialog.open)paint();});
})();
