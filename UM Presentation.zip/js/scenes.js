/* =========================================================
   UY MARKET — izometrik 3D illyustratsiyalar (SVG)
   Har bir xizmat va uning matn mazmuniga moslangan 12 ta sahna.
   window.SCENES[nom]() → <svg> satri. Rasm fayllari kerak emas.
   ========================================================= */
(() => {
  const S = 21;          // 1 birlik = 21 px
  const CX = 300;        // sahna markazi
  const CY = 108;        // koordinata boshi (0,0,0) ning ekrandagi Y'si

  // Izometrik proyeksiya: x o'ngga-pastga, y chapga-pastga, z yuqoriga
  const P = (x, y, z = 0) => [CX + (x - y) * 0.866 * S, CY + (x + y) * 0.5 * S - z * S];
  const f = (n) => Math.round(n * 10) / 10;
  const pts = (a) => a.map((p) => `${f(p[0])},${f(p[1])}`).join(" ");
  const poly = (a, fill, extra = "") => `<polygon points="${pts(a)}" fill="${fill}" ${extra}/>`;
  const EDGE = 'stroke="rgba(255,255,255,.6)" stroke-width=".7" stroke-linejoin="round"';

  // Ranglar: [yuqori (eng yorug'), chap, o'ng (eng quyuq)]
  const C = {
    white: ["#FFFFFF", "#E8EFFA", "#CCDAEF"],
    blue: ["#74ABF6", "#3A78DC", "#2358B0"],
    navy: ["#4F6AA0", "#2B4070", "#1B2B4F"],
    gold: ["#FFE49A", "#F6C244", "#DB9B16"],
    red: ["#FF9A9D", "#E5484D", "#B7302F"],
    green: ["#9BE5B3", "#45BD78", "#2C915A"],
    gray: ["#F6F8FB", "#DCE3EE", "#BFC9DA"],
    dark: ["#707B96", "#47526D", "#2F384E"],
    plate: ["#EEF5FF", "#CFE0F6", "#AFC8EA"],
  };

  const DEFS = `<defs>
    <radialGradient id="g-green" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#B5F0C6"/><stop offset="1" stop-color="#2E9C60"/></radialGradient>
    <linearGradient id="g-gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFE9A6"/><stop offset="1" stop-color="#E5A21B"/></linearGradient>
    <linearGradient id="g-shield" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7FD8FF"/><stop offset="1" stop-color="#215FC1"/></linearGradient>
    <linearGradient id="g-blue" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5FA2F5"/><stop offset="1" stop-color="#2358B0"/></linearGradient>
    <filter id="bl" x="-30%" y="-60%" width="160%" height="220%"><feGaussianBlur stdDeviation="9"/></filter>
    <filter id="sh" x="-30%" y="-30%" width="170%" height="180%"><feDropShadow dx="0" dy="6" stdDeviation="5" flood-color="#173F94" flood-opacity=".28"/></filter>
  </defs>`;

  /* ---------- Asosiy shakllar ---------- */
  const box = (x, y, z, w, d, h, c) =>
    poly([P(x, y, z + h), P(x + w, y, z + h), P(x + w, y + d, z + h), P(x, y + d, z + h)], c[0], EDGE) +
    poly([P(x, y + d, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x, y + d, z + h)], c[1], EDGE) +
    poly([P(x + w, y, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x + w, y, z + h)], c[2], EDGE);

  // Ikki yonbag'irli tom (qirrasi y o'qi bo'ylab)
  const roof = (x, y, z, w, d, h, c, wall) => {
    const m = x + w / 2;
    return (
      poly([P(x + w, y, z), P(x + w, y + d, z), P(m, y + d, z + h), P(m, y, z + h)], c[2], EDGE) +
      poly([P(x, y + d, z), P(x + w, y + d, z), P(m, y + d, z + h)], wall[1], EDGE)
    );
  };

  const qL = (x0, x1, z0, z1, y, fill, extra = "") => poly([P(x0, y, z0), P(x1, y, z0), P(x1, y, z1), P(x0, y, z1)], fill, extra);
  const qR = (y0, y1, z0, z1, x, fill, extra = "") => poly([P(x, y0, z0), P(x, y1, z0), P(x, y1, z1), P(x, y0, z1)], fill, extra);

  const wins = (x, y, z, w, d, h, cols, rows, lit) => {
    let s = "";
    const gw = (w - 0.6) / cols, gd = (d - 0.6) / cols, gh = (h - 0.8) / rows;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const z0 = z + 0.45 + r * gh, z1 = z0 + gh * 0.55;
        const x0 = x + 0.3 + c * gw;
        s += qL(x0, x0 + gw * 0.62, z0, z1, y + d + 0.001, lit(c, r) ? "#FFE9A8" : "#9DB9E3");
        const y0 = y + 0.3 + c * gd;
        s += qR(y0, y0 + gd * 0.62, z0, z1, x + w + 0.001, lit(c, r) ? "#F2CE6A" : "#7F9BC9");
      }
    }
    return s;
  };

  const house = (x, y, z, w, d, h, rh, wall = C.white, rc = C.blue) =>
    box(x, y, z, w, d, h, wall) +
    roof(x, y, z + h, w, d, rh, rc, wall) +
    qL(x + w * 0.55, x + w * 0.55 + 0.75, z, z + 1.3, y + d + 0.001, "#7FA5D8") +
    qL(x + 0.45, x + 1.25, z + 0.8, z + 1.6, y + d + 0.001, "#BFE0FF") +
    qR(y + d * 0.3, y + d * 0.3 + 0.8, z + 0.8, z + 1.6, x + w + 0.001, "#BFE0FF");

  const coin = (x, y, z, r = 0.75, h = 0.28, c = C.gold) => {
    const [cx, cy] = P(x, y, z + h);
    const rx = r * S * 1.12, ry = r * S * 0.62, hh = h * S;
    return (
      `<path d="M${f(cx - rx)} ${f(cy)}v${f(hh)}a${f(rx)} ${f(ry)} 0 0 0 ${f(2 * rx)} 0v${f(-hh)}z" fill="${c[1]}" ${EDGE}/>` +
      `<ellipse cx="${f(cx)}" cy="${f(cy)}" rx="${f(rx)}" ry="${f(ry)}" fill="${c[0]}" ${EDGE}/>` +
      `<ellipse cx="${f(cx)}" cy="${f(cy)}" rx="${f(rx * 0.55)}" ry="${f(ry * 0.55)}" fill="none" stroke="${c[2]}" stroke-width="1" opacity=".5"/>`
    );
  };
  const coins = (x, y, z, n, r, c) => Array.from({ length: n }, (_, i) => coin(x, y, z + i * 0.28, r, 0.28, c)).join("");

  const tree = (x, y, z = 0.5, h = 1.2) => {
    const [cx, cy] = P(x, y, z);
    return (
      `<ellipse cx="${f(cx)}" cy="${f(cy + 2)}" rx="12" ry="5" fill="rgba(20,50,90,.18)"/>` +
      `<rect x="${f(cx - 2)}" y="${f(cy - h * S * 0.55)}" width="4" height="${f(h * S * 0.55)}" fill="#8A6A4A"/>` +
      `<circle cx="${f(cx)}" cy="${f(cy - h * S * 0.9)}" r="${f(0.66 * S)}" fill="url(#g-green)"/>`
    );
  };

  const pawn = (x, y, z, c, sc = 1) => {
    const [cx, cy] = P(x, y, z);
    const h = 36 * sc, w = 11.5 * sc;
    return (
      `<ellipse cx="${f(cx)}" cy="${f(cy + 2)}" rx="${f(w * 1.15)}" ry="${f(w * 0.45)}" fill="rgba(20,50,90,.22)"/>` +
      `<path d="M${f(cx - w)} ${f(cy)}Q${f(cx - w * 0.9)} ${f(cy - h * 0.55)} ${f(cx)} ${f(cy - h * 0.62)}Q${f(cx + w * 0.9)} ${f(cy - h * 0.55)} ${f(cx + w)} ${f(cy)}z" fill="${c[1]}"/>` +
      `<path d="M${f(cx)} ${f(cy - h * 0.62)}Q${f(cx + w * 0.9)} ${f(cy - h * 0.55)} ${f(cx + w)} ${f(cy)}L${f(cx)} ${f(cy)}z" fill="${c[2]}"/>` +
      `<circle cx="${f(cx)}" cy="${f(cy - h * 0.8)}" r="${f(8 * sc)}" fill="${c[0]}" stroke="rgba(255,255,255,.7)" stroke-width="1"/>` +
      `<circle cx="${f(cx - 2.6 * sc)}" cy="${f(cy - h * 0.8 - 2.6 * sc)}" r="${f(2 * sc)}" fill="#fff" opacity=".6"/>`
    );
  };

  /* ---------- Ekran tekisligidagi buyumlar ---------- */
  const star = (cx, cy, sc = 1) => `<path transform="translate(${cx} ${cy}) scale(${sc})" d="M0-9 2-2 9 0 2 2 0 9-2 2-9 0-2-2z" fill="#fff" stroke="#F6C244" stroke-width="1"/>`;

  const keyShape = (cx, cy, sc = 1, rot = -28) =>
    `<g transform="translate(${cx} ${cy}) rotate(${rot}) scale(${sc})" filter="url(#sh)">` +
    `<circle cx="-26" cy="0" r="17" fill="url(#g-gold)" stroke="#fff" stroke-opacity=".7" stroke-width="1.5"/>` +
    `<circle cx="-26" cy="0" r="6" fill="#FFF3CC"/>` +
    `<rect x="-10" y="-5" width="54" height="10" rx="4" fill="url(#g-gold)" stroke="#fff" stroke-opacity=".7" stroke-width="1.2"/>` +
    `<rect x="28" y="4" width="8" height="14" rx="2" fill="#E8A91E"/><rect x="40" y="4" width="7" height="10" rx="2" fill="#E8A91E"/></g>`;

  const lens = (cx, cy, sc = 1) =>
    `<g transform="translate(${cx} ${cy}) scale(${sc})" filter="url(#sh)">` +
    `<path d="m19 19 26 26" stroke="#DB9B16" stroke-width="11" stroke-linecap="round"/>` +
    `<circle r="26" fill="rgba(255,255,255,.4)" stroke="url(#g-gold)" stroke-width="8"/>` +
    `<path d="M-13-12a19 19 0 0 1 14-9" stroke="#fff" stroke-width="3.4" fill="none" stroke-linecap="round" opacity=".9"/></g>`;

  const shield = (cx, cy, sc = 1) =>
    `<g transform="translate(${cx} ${cy}) scale(${sc})" filter="url(#sh)">` +
    `<path d="M0 -52 L40 -38 V-12 C40 12 22 28 0 38 C-22 28 -40 12 -40 -12 V-38 Z" fill="url(#g-shield)" stroke="rgba(255,255,255,.7)" stroke-width="1.6"/>` +
    `<path d="M0 -52 L40 -38 V-12 C40 12 22 28 0 38 Z" fill="rgba(10,40,120,.2)"/>` +
    `<path d="m-16 -2 11 11 22 -24" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/></g>`;

  const bubble = (cx, cy, inner, sc = 1) =>
    `<g transform="translate(${cx} ${cy}) scale(${sc})" filter="url(#sh)">` +
    `<path d="M-26 -18h52a8 8 0 0 1 8 8v18a8 8 0 0 1-8 8H-6l-10 12v-12h-10a8 8 0 0 1-8-8v-18a8 8 0 0 1 8-8z" fill="#fff" stroke="rgba(33,95,193,.16)" stroke-width="1.2"/>${inner}</g>`;
  const heart = '<path d="M0 8C-14-2-12-12-5-12-2-12 0-10 0-8 0-10 2-12 5-12 12-12 14-2 0 8z" fill="#FF5A6A"/>';
  const tick = '<path d="m-9 -1 6 6 12 -13" fill="none" stroke="#12B76A" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round"/>';
  const dots = '<circle cx="-12" cy="-1" r="3.4" fill="#2F6FD6"/><circle cx="0" cy="-1" r="3.4" fill="#2F6FD6"/><circle cx="12" cy="-1" r="3.4" fill="#2F6FD6"/>';

  const percent = (cx, cy, sc = 1) =>
    `<g transform="translate(${cx} ${cy}) scale(${sc})" filter="url(#sh)"><circle r="26" fill="url(#g-shield)" stroke="#fff" stroke-opacity=".8" stroke-width="2"/>` +
    `<text y="9" text-anchor="middle" font-family="Helvetica Neue, Helvetica, Arial, sans-serif" font-size="27" font-weight="700" fill="#fff">%</text></g>`;

  const arrow = (cx, cy, up = true, col = "#2BB5E8") => {
    const d = up ? "M0 40 38 14 58 26 102 -14" : "M0 -14 38 12 58 0 102 40";
    const head = up ? "M86 -16 106 -18 102 4" : "M86 40 106 44 100 22";
    return `<g transform="translate(${cx} ${cy})" fill="none" stroke="${col}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" filter="url(#sh)"><path d="${d}"/><path d="${head}"/></g>`;
  };

  const fl = (inner, d = 0) => `<g class="fl" style="--d:${d}s">${inner}</g>`;

  /* ---------- Sahna asosi ---------- */
  const base = () =>
    `<ellipse cx="${CX}" cy="${f(CY + 3.5 * S + 24)}" rx="225" ry="64" fill="#173F94" opacity=".17" filter="url(#bl)"/>` +
    box(0, 0, 0, 7, 7, 0.5, C.plate);
  const wrap = (inner) => `<svg class="scene" viewBox="0 0 600 292" preserveAspectRatio="xMidYMid meet" role="img" aria-hidden="true" focusable="false">${DEFS}${base()}${inner}</svg>`;

  const sign = (x, y, c, glyph) => {
    const [gx, gy] = P(x + 0.75, y + 0.3, 2.2 + 0.52);
    const mark = glyph === "check"
      ? '<path d="M-8 0 -2 6 9-7" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>'
      : '<rect x="-9" y="-5" width="18" height="2.8" rx="1.4" fill="#fff" opacity=".92"/><rect x="-9" y="0" width="12" height="2.8" rx="1.4" fill="#fff" opacity=".92"/>';
    return box(x + 0.65, y + 0.12, 0.5, 0.2, 0.2, 1.7, C.gray) + box(x, y, 2.2, 1.5, 0.3, 1.05, c) +
      `<g transform="translate(${f(gx)} ${f(gy)}) skewY(30)">${mark}</g>`;
  };

  const lit3 = (c, r) => (c + r) % 3 === 0;
  const lit0 = () => false;

  /* =============== O'NG KARTALAR (afzalliklar) =============== */
  const rentKey = () => wrap(
    house(1.4, 1.2, 0.5, 3.6, 3.4, 2.6, 1.7) + tree(0.8, 5.5) + sign(5.1, 5.1, C.blue, "lines") + tree(6.2, 1.4) +
    fl(keyShape(CX + 6, 38, 1.15) + star(380, 28, 0.9) + star(222, 60, 0.7), 0)
  );

  const soldHouse = () => wrap(
    house(1.0, 1.0, 0.5, 3.8, 3.8, 2.8, 1.9, C.white, C.navy) + coins(5.6, 1.8, 0.5, 4, 0.8) + coins(5.9, 3.2, 0.5, 2, 0.8) +
    sign(4.9, 5.2, C.red, "check") + tree(0.6, 5.4) +
    fl(bubble(CX + 4, 40, tick, 1.15), 0.4)
  );

  const towers = () => wrap(
    box(0.7, 0.7, 0.5, 2.2, 2.2, 4.6, C.white) + box(0.9, 0.9, 5.1, 1.8, 1.8, 0.45, C.blue) + wins(0.7, 0.7, 0.5, 2.2, 2.2, 4.6, 2, 4, lit3) +
    box(3.6, 0.6, 0.5, 2.4, 2.4, 3.6, C.gray) + box(3.8, 0.8, 4.1, 2, 2, 0.4, C.blue) + wins(3.6, 0.6, 0.5, 2.4, 2.4, 3.6, 2, 3, (c, r) => (c * 2 + r) % 3 !== 1) +
    box(0.9, 3.8, 0.5, 2.6, 2.4, 2.6, C.white) + box(1.1, 4, 3.1, 2.2, 2, 0.36, C.blue) + wins(0.9, 3.8, 0.5, 2.6, 2.4, 2.6, 2, 2, (c, r) => (c + r) % 2 === 0) +
    tree(5.6, 4.9) + tree(4.3, 5.9) + tree(6.2, 5.8) +
    fl(arrow(404, 52, true), 0.2)
  );

  const mortgage = () => wrap(
    house(0.8, 0.8, 0.5, 3.2, 3.2, 2.3, 1.6) + coins(5.0, 3.0, 0.5, 5, 0.8) + coins(4.3, 5.2, 0.5, 2, 0.8) + coins(5.8, 4.9, 0.5, 3, 0.8) + tree(0.8, 5.4) +
    fl(percent(CX + 82, 52, 1.15), 0.3) + fl(star(250, 40, 0.8), 0.9)
  );

  const appraisal = () => wrap(
    house(1.0, 1.0, 0.5, 3.3, 3.3, 2.4, 1.6) +
    box(4.0, 4.7, 0.5, 0.8, 0.8, 1.2, C.blue) + box(5.0, 4.7, 0.5, 0.8, 0.8, 2.2, C.blue) + box(6.0, 4.7, 0.5, 0.8, 0.8, 3.4, C.gold) +
    tree(0.7, 5.5) +
    fl(lens(CX - 96, 128, 1.15), 0.1) + fl(arrow(396, 54, true, "#12B76A"), 0.6)
  );

  const phoneAds = () => {
    const x = 2.4, y = 2.2, w = 2.6, d = 0.5, h = 5.4, ey = y + d + 0.001;
    return wrap(
      box(x, y, 0.5, w, d, h, C.dark) +
      qL(x + 0.18, x + w - 0.18, 0.85, 0.5 + h - 0.3, ey, "#F7FAFF") +
      qL(x + 0.18, x + w - 0.18, 0.5 + h - 1.2, 0.5 + h - 0.3, ey, "#2F6FD6") +
      qL(x + 0.4, x + w - 0.4, 0.5 + h - 3.4, 0.5 + h - 1.5, ey, "#B7D3F7") +
      qL(x + 0.4, x + w - 1.1, 1.9, 2.15, ey, "#C9D6EA") + qL(x + 0.4, x + w - 0.6, 1.4, 1.65, ey, "#C9D6EA") +
      box(4.6, 4.6, 0.5, 0.75, 0.75, 1.1, C.blue) + box(5.5, 4.6, 0.5, 0.75, 0.75, 2.0, C.blue) + box(6.3, 4.6, 0.5, 0.75, 0.75, 3.0, C.gold) +
      tree(0.8, 5.3) +
      fl(bubble(168, 82, heart, 1.15), 0) + fl(bubble(466, 70, dots, 1.1), 0.7) + fl(bubble(500, 160, tick, 0.9), 1.3)
    );
  };

  /* =============== CHAP KARTALAR (kimlar uchun / muammo) =============== */
  const rentTypes = () => wrap(
    house(0.3, 3.0, 0.5, 2.1, 2.1, 1.5, 1.1) +
    box(4.0, 0.4, 0.5, 1.9, 1.9, 3.6, C.white) + box(4.15, 0.55, 4.1, 1.6, 1.6, 0.35, C.blue) + wins(4.0, 0.4, 0.5, 1.9, 1.9, 3.6, 2, 3, lit3) +
    box(4.4, 4.2, 0.5, 2.2, 2.0, 1.5, C.white) + box(4.3, 4.1, 2.0, 2.4, 2.2, 0.25, C.red) + qL(4.7, 6.3, 0.5, 1.6, 6.201, "#9CC4F2") +
    tree(1.2, 6.0) + tree(2.4, 0.9) +
    fl(keyShape(205, 66, 0.85, -25) + star(330, 34, 0.8), 0.2)
  );

  const shieldScene = () => wrap(
    house(0.8, 1.6, 0.5, 2.8, 2.6, 1.9, 1.4) + coins(5.2, 4.8, 0.5, 3, 0.8) + tree(5.9, 1.3) +
    fl(shield(CX + 70, 108, 1.3), 0.2) + fl(star(210, 50, 0.8), 0.9) + fl(star(470, 70, 0.6), 0.5)
  );

  const towersDown = () => wrap(
    box(1.0, 1.0, 0.5, 2.4, 2.4, 4.6, C.gray) + box(1.2, 1.2, 5.1, 2, 2, 0.4, C.dark) + wins(1.0, 1.0, 0.5, 2.4, 2.4, 4.6, 2, 4, lit0) +
    box(4.1, 4.5, 0.5, 0.8, 0.8, 2.8, C.red) + box(5.1, 4.5, 0.5, 0.8, 0.8, 1.8, C.red) + box(6.0, 4.5, 0.5, 0.8, 0.8, 0.9, C.red) +
    sign(0.6, 4.6, C.gray, "lines") +
    fl(arrow(366, 40, false, "#E5484D"), 0.3)
  );

  const family = () => wrap(
    house(0.9, 0.8, 0.5, 3.4, 3.2, 2.4, 1.6) + tree(6.0, 1.6) +
    pawn(4.2, 5.0, 0.5, C.blue, 1.55) + pawn(5.3, 5.2, 0.5, C.green, 1.45) + pawn(4.8, 6.0, 0.5, C.gold, 1.05) +
    fl(bubble(CX + 76, 74, heart, 1.05), 0.2)
  );

  const docsStack = () => {
    let out = "";
    const cols = [C.gray, C.white, C.gray, C.white];
    for (let i = 0; i < 4; i++) {
      const x = 1.5 + i * 0.25, y = 1.4 + i * 0.25, z = 0.5 + i * 0.42;
      out += box(x, y, z, 3.3, 2.5, 0.42, i === 3 ? C.blue : cols[i]);
      out += qL(x + 0.35, x + 2.2, z + 0.15, z + 0.27, y + 2.5 + 0.001, i === 3 ? "#FFFFFF" : "#8FB6EE");
    }
    return wrap(
      out + tree(6.0, 2.2) + coins(5.0, 5.4, 0.5, 3, 0.8) +
      fl(lens(CX + 112, 176, 1.05), 0.2) +
      `<g transform="translate(${CX - 6} 84)" filter="url(#sh)"><circle r="19" fill="url(#g-gold)" stroke="#fff" stroke-opacity=".8" stroke-width="2"/><path d="m-8 0 6 6 11-12" fill="none" stroke="#fff" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round"/></g>`
    );
  };

  const people = () => wrap(
    pawn(1.5, 5.5, 0.5, C.blue, 1.5) + pawn(2.7, 4.3, 0.5, C.gold, 1.5) + pawn(3.9, 3.1, 0.5, C.green, 1.5) + pawn(5.1, 1.9, 0.5, C.red, 1.5) +
    tree(0.7, 0.9) + tree(6.1, 6.1) +
    fl(bubble(227, 112, tick, 0.95), 0) + fl(bubble(315, 100, heart, 1), 0.6) + fl(bubble(380, 74, dots, 0.95), 1.1)
  );

  /* =============== Taqdimot uchun qo'shimcha sahnalar =============== */
  // Avtomobil bilan obyektni ko'rsatish
  const carShow = () => wrap(
    house(0.7, 0.7, 0.5, 2.8, 2.6, 2.0, 1.4) + tree(5.8, 1.0) +
    box(0, 4.6, 0.5, 7, 1.8, 0.12, C.dark) + box(0.4, 5.45, 0.62, 1.2, 0.12, 0.02, C.gold) + box(2.6, 5.45, 0.62, 1.2, 0.12, 0.02, C.gold) + box(4.8, 5.45, 0.62, 1.2, 0.12, 0.02, C.gold) +
    box(2.2, 4.95, 0.62, 2.9, 1.1, 0.7, C.blue) + box(2.9, 5.0, 1.32, 1.5, 1.0, 0.6, C.white) +
    coin(2.9, 6.05, 0.62, 0.34, 0.14, C.dark) + coin(4.7, 6.05, 0.62, 0.34, 0.14, C.dark) +
    sign(5.3, 2.7, C.blue, "lines") +
    fl(keyShape(CX + 84, 54, 0.9, -25) + star(210, 52, 0.8), 0.2)
  );

  // Bank va yuridik hamkorlik
  const bankLegal = () => {
    let cols = "";
    for (let i = 0; i < 4; i++) cols += box(1.2 + i * 1.05, 1.5, 1.0, 0.45, 0.45, 2.3, C.white);
    return wrap(
      box(0.8, 1.1, 0.5, 4.8, 1.8, 0.5, C.gray) + box(1.0, 1.3, 1.0 - 0.0, 4.4, 1.4, 0.0001, C.gray) + cols +
      box(0.9, 1.2, 3.3, 4.6, 1.6, 0.35, C.white) + roof(0.9, 1.2, 3.65, 4.6, 1.6, 1.0, C.blue, C.white) +
      coins(5.6, 4.6, 0.5, 4, 0.8) + coins(4.5, 5.3, 0.5, 2, 0.8) + tree(0.7, 5.3) +
      fl(shield(CX + 95, 96, 1.1), 0.3) + fl(star(212, 54, 0.8), 0.8)
    );
  };

  window.SCENES = {
    rentKey, soldHouse, towers, mortgage, appraisal, phoneAds,
    rentTypes, shield: shieldScene, towersDown, family, docsStack, people, carShow, bankLegal,
  };
})();
