/* =========================================================
   Jamoa kartochkalari: "+" bosilganda rasm o'girilib xodim ma'lumoti chiqadi.
   DIQQAT: ism, telefon, staj va loyiha soni namunaviy (tasodifiy) — haqiqiy ma'lumot bilan almashtiring.
   ========================================================= */
(() => {
  const grid = document.getElementById("team-grid");
  if (!grid) return;

  // [rasm, ism uz/en, ism ru, lavozim [uz, ru, en], telefon, telegram, staj (yil), loyihalar]
  const ROLES = {
    head: ["Rahbar", "Руководитель", "Director"],
    sales: ["Sotuv menejeri", "Менеджер по продажам", "Sales manager"],
    agent: ["Koʻchmas mulk mutaxassisi", "Специалист по недвижимости", "Real estate specialist"],
    senior: ["Yetakchi mutaxassis", "Ведущий специалист", "Senior specialist"],
    lawyer: ["Yurist", "Юрист", "Lawyer"],
    mortgage: ["Ipoteka mutaxassisi", "Ипотечный специалист", "Mortgage specialist"],
    appraiser: ["Baholovchi", "Оценщик", "Appraiser"],
    marketer: ["Marketolog", "Маркетолог", "Marketing manager"],
  };
  const M = [
    [2, "Bobur Yusupov", "Бобур Юсупов", "senior", "+998 90 312 45 08", "bobur_yusupov", 7, 96],
    [3, "Sardor Rahimov", "Сардор Рахимов", "sales", "+998 91 204 77 35", "sardor_rahimov", 5, 71],
    [5, "Otabek Tursunov", "Отабек Турсунов", "agent", "+998 97 718 30 92", "otabek_tursunov", 6, 83],
    [8, "Aziz Mamatov", "Азиз Маматов", "agent", "+998 88 233 90 51", "aziz_mamatov", 8, 109],
    [9, "Javohir Nazarov", "Жавохир Назаров", "lawyer", "+998 90 641 18 73", "javohir_nazarov", 6, 88],
    [10, "Sevara Qodirova", "Севара Кодирова", "agent", "+998 95 129 64 02", "sevara_qodirova", 2, 24],
    [12, "Rustam Abdullayev", "Рустам Абдуллаев", "senior", "+998 93 408 56 70", "rustam_abdullayev", 9, 127],
    [13, "Sherzod Qosimov", "Шерзод Косимов", "agent", "+998 97 362 09 85", "sherzod_qosimov", 4, 52],
    [14, "Umid Sodiqov", "Умид Содиков", "appraiser", "+998 99 915 47 36", "umid_sodiqov", 7, 93],
    [15, "Behruz Toshpulatov", "Бехруз Тошпулатов", "agent", "+998 88 576 21 94", "behruz_toshpulatov", 2, 19],
    [16, "Akmal Hasanov", "Акмал Хасанов", "sales", "+998 90 284 63 18", "akmal_hasanov", 5, 68],
    [17, "Islom Normatov", "Ислом Норматов", "agent", "+998 94 730 85 42", "islom_normatov", 3, 33],
  ];
  const L = {
    uz: { phone: "Telefon", tg: "Telegram", exp: "Ish staji", proj: "Yakunlangan loyiha", yr: "yil", back: "Yopish", open: "Maʼlumot" },
    ru: { phone: "Телефон", tg: "Telegram", exp: "Стаж", proj: "Проектов", yr: "лет", back: "Закрыть", open: "Информация" },
    en: { phone: "Phone", tg: "Telegram", exp: "Experience", proj: "Projects done", yr: "yrs", back: "Close", open: "Info" },
  };
  const idx = { uz: 0, ru: 1, en: 2 };
  const lang = () => (L[document.documentElement.lang] ? document.documentElement.lang : "uz");
  const yr = (n, l) => (l === "ru" ? (n % 10 === 1 && n !== 11 ? "год" : n % 10 >= 2 && n % 10 <= 4 && (n < 10 || n > 20) ? "года" : "лет") : l === "en" ? (n === 1 ? "yr" : "yrs") : "yil");

  grid.innerHTML = M.map(([img, nameL, nameR, role, phone, tg, exp, proj], i) => `
    <article class="member reveal${i >= 8 ? " is-extra" : ""}" data-i="${i}" data-photo="${img}">
      <h3 class="member-name"></h3>
      <div class="member-photo ph">
        <div class="member-flip">
          <div class="member-face member-front"><img src="assets/img/team/team-${img}.webp" alt="" width="800" height="1000" loading="lazy"></div>
          <div class="member-face member-back">
            <p class="mb-role"></p>
            <dl>
              <div><dt></dt><dd><a class="mb-phone" href="tel:${phone.replace(/\s/g, "")}">${phone}</a></dd></div>
              <div><dt></dt><dd><a class="mb-tg" href="https://t.me/${tg}" target="_blank" rel="noopener">@${tg}</a></dd></div>
              <div><dt></dt><dd class="mb-exp"></dd></div>
              <div><dt></dt><dd><b>${proj}</b></dd></div>
            </dl>
          </div>
        </div>
        <button class="member-plus" type="button" aria-expanded="false">+</button>
      </div>
      <p class="member-role"></p>
    </article>`).join("");

  const paint = () => {
    const l = lang(), k = idx[l], t = L[l];
    grid.querySelectorAll(".member").forEach((el) => {
      const m = M[+el.dataset.i];
      const name = l === "ru" ? m[2] : m[1];
      const role = ROLES[m[3]][k];
      el.querySelector(".member-name").textContent = name;
      el.querySelector(".member-role").textContent = role;
      el.querySelector(".mb-role").textContent = role;
      el.querySelector(".mb-exp").innerHTML = `<b>${m[6]}</b> ${yr(m[6], l)}`;
      const dts = el.querySelectorAll("dt");
      [t.phone, t.tg, t.exp, t.proj].forEach((s, j) => { dts[j].textContent = s; });
      el.querySelector(".member-plus").setAttribute("aria-label", t.open);
      el.querySelector(".member-front img").alt = name;
    });
  };
  paint();
  document.addEventListener("langchange", paint);

  grid.addEventListener("click", (e) => {
    const b = e.target.closest(".member-plus");
    if (!b) return;
    const el = b.closest(".member");
    const on = !el.classList.contains("is-flipped");
    closeAll();
    if (on) { el.classList.add("is-flipped"); b.setAttribute("aria-expanded", "true"); }
  });

  // Bir vaqtda faqat bitta kartochka ochiq turadi
  function closeAll() {
    grid.querySelectorAll(".member.is-flipped").forEach((m) => {
      m.classList.remove("is-flipped");
      m.querySelector(".member-plus").setAttribute("aria-expanded", "false");
    });
  }
  // "Yashirish" bosilganda ochiq kartochka ham yopiladi
  document.getElementById("team-more")?.addEventListener("click", closeAll);
})();
