/* =========================================================
   UY MARKET — xizmat sahifalari ma'lumotlari (UZ / RU / EN)
   service.html?s=<slug> shu fayldan chiziladi.
   Raqamlar, narxlar va loyihalarni shu yerda yangilang.
   ========================================================= */

// Har bir xizmatning tili bo'yicha o'zgarmaydigan qismi
const SERVICE_META = {
  ijara:       { form: "rent",     hero: "assets/img/services/hero-rent-2.webp",     extra: "checklist", icon: "M11.2 12.8a4.5 4.5 0 1 1-6.4 6.4 4.5 4.5 0 0 1 6.4-6.4zM11.2 12.8 20 4M16.5 7.5l2.5 2.5M14 10l2 2M7.5 16.5h.01" },
  sotuv:       { form: "sale",     hero: "assets/img/services/hero-sale-2.webp",     extra: "compare",   icon: "M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z" },
  novostroyka: { duo: "problem", form: "new",      hero: "assets/img/services/hero-new.webp",      extra: "portfolio", icon: "M4 21V8l8-5 8 5v13M9 21v-6h6v6M9 10h.01M15 10h.01" },
  ipoteka:     { form: "mortgage", hero: "assets/img/services/hero-mortgage-2.webp", extra: "calculator", icon: "M2 6h20v13H2zM2 10h20M6 15h4" },
  baholash:    { form: "eval",     hero: "assets/img/services/hero-eval-3.webp",     extra: "factors",   icon: "M3 3v18h18M7 14l4-4 3 3 5-6" },
  reklama:     { form: "ads",      hero: "assets/img/services/hero-ads.webp",      extra: "pricing",   icon: "M3 11v2a1 1 0 0 0 1 1h3l5 4V6L7 10H4a1 1 0 0 0-1 1zM16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12" },
};
const SERVICE_ORDER = ["sotuv", "ijara", "reklama", "novostroyka", "ipoteka", "baholash"];

// Novostroyka portfoliosi: hamkor quruvchilarning loyihalari.
// DIQQAT: hudud, davr, xonadon soni va narx NAMUNAVIY — haqiqiy raqamlar bilan almashtiring.
// start: "YYYY-MM" (savdo boshlangan oy), months: savdo davomiyligi, units: sotilgan xonadonlar, price: o'rtacha narx (mln so'm)
const PORTFOLIO = [
  { name: "HI-TECH CITY", img: "assets/img/portfolio/p1.webp", start: "2022-09", months: 14, units: 168, price: 520, area: ["Andijon sh., Boburshoh koʻchasi", "г. Андижан, ул. Бобуршох", "Andijan, Boburshoh St."] },
  { name: "MIMAR", img: "assets/img/portfolio/p2.webp", start: "2023-02", months: 11, units: 132, price: 480, area: ["Andijon sh., 1-mikrorayon", "г. Андижан, 1-й микрорайон", "Andijan, 1st microdistrict"] },
  { name: "DREAM HOUSE", img: "assets/img/portfolio/p3.webp", start: "2023-06", months: 16, units: 214, price: 455, area: ["Andijon sh., Yangi Andijon", "г. Андижан, Янги Андижан", "Andijan, Yangi Andijan"] },
  { name: "INDEX", img: "assets/img/portfolio/p4.webp", start: "2023-11", months: 9, units: 96, price: 560, area: ["Andijon sh., Bogʻishamol", "г. Андижан, Богишамол", "Andijan, Bogishamol"] },
  { name: "NUR", img: "assets/img/portfolio/p5.webp", start: "2024-03", months: 12, units: 144, price: 510, area: ["Andijon sh., Navoiy shoh koʻchasi", "г. Андижан, пр. Навои шох", "Andijan, Navoi Shoh Ave."] },
  { name: "MIRABAD AVENUE", img: "assets/img/portfolio/p6.webp", start: "2024-08", months: 10, units: 118, price: 590, area: ["Andijon sh., Mirabad mahallasi", "г. Андижан, махалля Мирабад", "Andijan, Mirabad district"] },
];

// Portfolio kartochkasi uchun hisoblangan ko'rsatkichlar (til bo'yicha formatlangan)
const PF_TEXT = {
  uz: { area: "Hudud", period: "Savdo davri", turnover: "Savdo aylanmasi", sold: "Sotilgan", avg: "Oʻrtacha oyiga", mo: "oy", unit: "xonadon", bn: "mlrd soʻm", mn: "mln soʻm", dec: "," },
  ru: { area: "Район", period: "Период продаж", turnover: "Оборот продаж", sold: "Продано", avg: "В среднем за месяц", mo: "мес.", unit: "квартир", bn: "млрд сум", mn: "млн сум", dec: "," },
  en: { area: "Location", period: "Sales period", turnover: "Sales turnover", sold: "Sold", avg: "Monthly average", mo: "mo", unit: "apartments", bn: "bn UZS", mn: "mn UZS", dec: "." },
};
function portfolioFacts(p, lang) {
  const T = PF_TEXT[lang] || PF_TEXT.uz, k = { uz: 0, ru: 1, en: 2 }[lang] ?? 0;
  const num = (n, d = 1) => (Math.round(n * 10 ** d) / 10 ** d).toString().replace(".", T.dec);
  const money = (mln) => (mln >= 1000 ? `${num(mln / 1000)} ${T.bn}` : `${num(mln, 0)} ${T.mn}`);
  const [y, m] = p.start.split("-").map(Number);
  const end = new Date(y, m - 1 + p.months - 1, 1);
  const fmt = (yy, mm) => `${String(mm).padStart(2, "0")}.${yy}`;
  const total = p.units * p.price;
  return {
    area: p.area[k],
    period: `${fmt(y, m)} – ${fmt(end.getFullYear(), end.getMonth() + 1)} · ${p.months} ${T.mo}`,
    months: `${p.months} ${T.mo}`,
    turnover: money(total),
    sold: `${p.units} ${T.unit} / ${p.months} ${T.mo}`,
    avg: `${num(p.units / p.months)} ${T.unit} · ${money(total / p.months)}`,
    labels: T,
  };
}

// Reklama narxlari (so'mda)
const AD_PRICES = {
  telegramNew: [[1, 400000], [2, 700000], [3, 1000000], [4, 1300000], [5, 1500000], [10, 2800000], [15, 3400000]],
  // Confirmed Telegram advertising rates
  instagramTM: [[1, 6000000], [2, 10000000], [3, 14000000]],
  telegramServices: [[1, 200000], [2, 350000], [3, 500000]],
  telegram: [[1, 100000], [2, 180000], [3, 250000], [4, 320000], [5, 400000]],
  instagram: [[1, 200000], [2, 350000], [3, 500000]],
};

// Reklama tariflari (3 kanal). DIQQAT: narxlar va paket tarkibi NAMUNAVIY — haqiqiy shartlar bilan almashtiring.
const AD_PLANS = {
  uz: {
    dlPng: "Yuklab olish", sharePng: "Ulashish", shareHint: "Rasm yuklab olindi — Telegram’ga qo‘lda yuboring",
    reachT: "Taxminiy natija (oyiga)", views: "koʻrishlar", calls: "qoʻngʻiroqlar", reachNote: "Taxminiy koʻrsatkich, aniq natija obyektga bogʻliq",
    vis: "Koʻrinish darajasi", premium: "Premium",
    banner: { telegram: { title: "Telegram kanalimiz", sub: "Yangi obyektlar va eng soʻnggi eʼlonlar — 100k+ obunachi", btn: "Kanalga oʻtish" }, instagram: { title: "Instagram sahifamiz", sub: "Video, Reels va Stories — 100k+ obunachi", btn: "Sahifaga oʻtish" }, website: { title: "UY MARKET sayti", sub: "Barcha obyektlar, narxlar va aloqa bir joyda", btn: "Saytga oʻtish" } },
    tabs: { telegram: "Telegram", instagram: "Instagram", website: "Website" },
    unitMonth: "oyiga", unitOne: "1 dona", audience: "100k+ auditoriya", posts: "ta eʼlon",
    tg: { qty: { title: "1 tadan 5 tagacha", sub: "Eʼlonlar sonini tanlang — narx avtomatik hisoblanadi", each: "Har bir eʼlon", save: "tejash" }, tag: "Doimiy maklerlar uchun", title: "Oylik paket", sub: "Muntazam eʼlon beruvchi maklerlar uchun alohida shart", price: 1200000, items: ["Oyiga 20 tagacha eʼlon", "Har bir eʼlonda chegirma", "Eʼlon vaqtini belgilash", "Oylik natija hisoboti"] },
    ig: {
      receipt: { price: 3000000, old: 3600000, tag: "Umumiy xarajatlar", title: "1 dona reklama qiymati", flow: "1 dona reklama — 5 bosqich", rows: [["Obyektga borish", 0, ""], ["Tasvirga olish", 300000, "Professional kamerada obyektda suratga olish"], ["Montaj", 200000, "Kesish, musiqa, sarlavha va effektlar"], ["Joylashtirish", 100000, "Reels, post yoki Stories sifatida eʼlon qilish"], ["Instagram Target", 0, ""]], total: "1 dona narxi", note: "Tasvirga olish, montaj va joylashtirish xarajatlari kiritilgan." },
      bulk: { tag: "Koʻp miqdor uchun", title: "5 talik paket", price: 12500000, old: 15000000, items: ["5 ta Reels / video", "Tasvirga olish va montaj kiritilgan", "Har bir dona 2 500 000 soʻm", "Haftalik joylashtirish jadvali"] },
      tm: { tag: "TM uchun tarif", title: "Turar-joy majmuasi", price: 12000000, items: ["3 ta post", "Majmua hududida suratga olish", "Stories va yangiliklar", "Oylik natija hisoboti"] },
    },
    web: [
      { name: "Standard", views: 1500, calls: 8, price: 50000, text: "Boshlangʻich koʻrinish", items: ["Saytda obyekt kartochkasi", "5 tagacha rasm", "30 kun joylashuv", "Asosiy filtrlarda koʻrinish"] },
      { name: "Silver", views: 4000, calls: 25, price: 100000, text: "Koʻproq eʼtibor", items: ["Standarddagi hamma narsa", "15 tagacha rasm va video", "Qidiruv natijalarida yuqori oʻrin", "Xaritada alohida belgi", "Haftalik statistika"] },
      { name: "Gold", views: 10000, calls: 70, price: 200000, text: "Maksimal qamrov", items: ["Silverdagi hamma narsa", "Bosh sahifada tavsiya etilgan blok", "Professional foto va video", "Shaxsiy menejer", "Kunlik statistika va hisobot"] },
    ],
  },
  ru: {
    dlPng: "Скачать", sharePng: "Поделиться", shareHint: "Изображение скачано — отправьте его в Telegram вручную",
    reachT: "Ориентировочный результат (в месяц)", views: "просмотров", calls: "звонков", reachNote: "Оценка, точный результат зависит от объекта",
    vis: "Уровень видимости", premium: "Премиум",
    banner: { telegram: { title: "Наш Telegram-канал", sub: "Новые объекты и свежие объявления — 100k+ подписчиков", btn: "Перейти в канал" }, instagram: { title: "Наша страница в Instagram", sub: "Видео, Reels и Stories — 100k+ подписчиков", btn: "Перейти на страницу" }, website: { title: "Сайт UY MARKET", sub: "Все объекты, цены и контакты в одном месте", btn: "Перейти на сайт" } },
    tabs: { telegram: "Telegram", instagram: "Instagram", website: "Сайт" },
    unitMonth: "в месяц", unitOne: "1 шт.", audience: "аудитория 100k+", posts: "объявл.",
    tg: { qty: { title: "От 1 до 5 объявлений", sub: "Выберите количество — цена рассчитается автоматически", each: "За объявление", save: "экономия" }, tag: "Для постоянных риелторов", title: "Месячный пакет", sub: "Отдельные условия для риелторов, которые размещаются регулярно", price: 1200000, items: ["До 20 объявлений в месяц", "Скидка на каждое объявление", "Выбор времени публикации", "Ежемесячный отчёт о результатах"] },
    ig: {
      receipt: { price: 3000000, old: 3600000, tag: "Общие расходы", title: "Стоимость 1 ролика", flow: "1 ролик — 5 этапов", rows: [["Выезд на объект", 0, ""], ["Съёмка", 300000, "Съёмка объекта на профессиональную камеру"], ["Монтаж", 200000, "Нарезка, музыка, заголовки и эффекты"], ["Размещение", 100000, "Публикация как Reels, пост или Stories"], ["Таргет в Instagram", 0, ""]], total: "Цена за 1 шт.", note: "В стоимость входят съёмка, монтаж и размещение." },
      bulk: { tag: "Для большого объёма", title: "Пакет из 5 шт.", price: 12500000, old: 15000000, items: ["5 Reels / видео", "Съёмка и монтаж включены", "Каждый ролик — 2 500 000 сум", "Недельный график публикаций"] },
      tm: { tag: "Тариф для ЖК", title: "Жилой комплекс", price: 12000000, items: ["3 поста", "Съёмка на территории комплекса", "Stories и новости", "Ежемесячный отчёт о результатах"] },
    },
    web: [
      { name: "Standard", views: 1500, calls: 8, price: 50000, text: "Базовая видимость", items: ["Карточка объекта на сайте", "До 5 фото", "Размещение 30 дней", "Показ в основных фильтрах"] },
      { name: "Silver", views: 4000, calls: 25, price: 100000, text: "Больше внимания", items: ["Всё из Standard", "До 15 фото и видео", "Высокая позиция в поиске", "Отдельная метка на карте", "Еженедельная статистика"] },
      { name: "Gold", views: 10000, calls: 70, price: 200000, text: "Максимальный охват", items: ["Всё из Silver", "Блок «Рекомендуем» на главной", "Профессиональное фото и видео", "Персональный менеджер", "Ежедневная статистика и отчёт"] },
    ],
  },
  en: {
    dlPng: "Download", sharePng: "Share", shareHint: "Image downloaded — send it to Telegram manually",
    reachT: "Estimated result (per month)", views: "views", calls: "calls", reachNote: "An estimate; the exact result depends on the property",
    vis: "Visibility", premium: "Premium",
    banner: { telegram: { title: "Our Telegram channel", sub: "New properties and the latest listings — 100k+ subscribers", btn: "Open the channel" }, instagram: { title: "Our Instagram page", sub: "Videos, Reels and Stories — 100k+ followers", btn: "Open the page" }, website: { title: "The UY MARKET website", sub: "All properties, prices and contacts in one place", btn: "Open the website" } },
    tabs: { telegram: "Telegram", instagram: "Instagram", website: "Website" },
    unitMonth: "per month", unitOne: "1 unit", audience: "100k+ audience", posts: "posts",
    tg: { qty: { title: "From 1 to 5 posts", sub: "Pick the number of posts — the price updates instantly", each: "Per post", save: "saved" }, tag: "For regular realtors", title: "Monthly package", sub: "A separate deal for realtors who post regularly", price: 1200000, items: ["Up to 20 posts per month", "Discount on every post", "Choose the publication time", "Monthly results report"] },
    ig: {
      receipt: { price: 3000000, old: 3600000, tag: "Total costs", title: "Cost of 1 video", flow: "1 video — 5 steps", rows: [["Visit the property", 0, ""], ["Filming", 300000, "Shooting the property on a professional camera"], ["Editing", 200000, "Cutting, music, titles and effects"], ["Publishing", 100000, "Posted as a Reel, post or Stories"], ["Instagram targeting", 0, ""]], total: "Price per 1 unit", note: "Filming, editing and publishing costs are included." },
      bulk: { tag: "For large volumes", title: "Pack of 5", price: 12500000, old: 15000000, items: ["5 Reels / videos", "Filming and editing included", "2 500 000 UZS per video", "Weekly publishing schedule"] },
      tm: { tag: "Residential complex plan", title: "Housing complex", price: 12000000, items: ["3 posts", "Filming on the complex grounds", "Stories and news", "Monthly results report"] },
    },
    web: [
      { name: "Standard", views: 1500, calls: 8, price: 50000, text: "Basic visibility", items: ["Property card on the website", "Up to 5 photos", "30 days of listing", "Shown in the main filters"] },
      { name: "Silver", views: 4000, calls: 25, price: 100000, text: "More attention", items: ["Everything in Standard", "Up to 15 photos and video", "High position in search results", "Separate marker on the map", "Weekly statistics"] },
      { name: "Gold", views: 10000, calls: 70, price: 200000, text: "Maximum reach", items: ["Everything in Silver", "Featured block on the home page", "Professional photo and video", "Personal manager", "Daily statistics and report"] },
    ],
  },
};

// Reklama kanallari havolalari va banner rasmlari. DIQQAT: url — haqiqiy kanal/sahifa manzili bilan almashtiring ("#" = hozircha ulanmagan).
const AD_LINKS = {
  telegram: { url: "https://t.me/uymarket_andijon", img: "assets/img/hero-complex.jpg", pos: "50% 55%" },
  instagram: { url: "https://www.instagram.com/uymarket_andijon?utm_source=ig_web_button_share_sheet&mdxt=ZDNlZDc0MzIxNw==", img: "assets/presentation/p12-office.jpg", pos: "50% 45%" },
  website: { url: "https://uymarket.com", img: "assets/img/building.jpg", pos: "50% 42%" },
};

const SERVICE_CONTENT = {
  /* ======================= O'ZBEKCHA ======================= */
  uz: {
    ui: {
      crumb: "Xizmatlar", consult: "Bepul konsultatsiya", how: "Biz qanday ishlaymiz", about: "Xizmat haqida",
      step: "bosqich", faq: "Koʻp beriladigan savollar", partners: "Bizning hamkorlarimiz", legal: "Yuridik nazorat",
      verified: "Tekshirilgan obyektlar", portfolio: "Portfolio", portfolioMeta: "Hamkor quruvchi · Andijon",
      advantages: "Afzalliklarimiz", prev: "Oldingi", next: "Keyingi", perTimes: "marta", currency: "soʻm",
      order: "Buyurtma berish", pricingTitle: "Reklama narxlari", pricingNote: "Baʼzi holatlarda Instagram va YouTube tarif narxlari kelishiladi.",
      calcTitle: "Ipoteka kalkulyatori", calcPrice: "Uy narxi (USD)", calcOver: "Foiz hisobidan toʻlov", calcPerMonth: " / oy", calcDown: "Boshlangʻich toʻlov", calcYears: "Muddat", calcRate: "Yillik foiz",
      calcMonthly: "Oylik toʻlov", calcLoan: "Kredit summasi", calcTotal: "Jami toʻlov", calcYearsUnit: "yil",
      calcNote: "Hisob taxminiy. Aniq shartlarni bank va mutaxassisimiz bilan kelishasiz.",
      compareTitle: "Oʻzingiz sotsangiz va UY MARKET bilan", compareSelf: "Oʻzingiz", compareUs: "UY MARKET bilan",
      factorsTitle: "Baholashda nimalar hisobga olinadi", checklistTitle: "Ijara shartnomasida nimalar boʻladi",
    },
    ijara: {
      name: "Ijara",
      t1: "Obyektni ishonchli", t2: "ijaraga bering yoki oling",
      sub: "Uy va tijorat obyektlarini xavfsiz va tez ijaraga berish yoki olish.",
      aboutLead: "Bozor tahlili, narx belgilash, mijoz topish va shartnoma tuzish jarayoni toʻliq nazorat qilinadi.",
      aboutText: "Har bir bitim — chuqur tahlil, professional muzokara va toʻliq yuridik nazorat asosida amalga oshiriladi. Biz uchun eng muhimi — mijozning xotirjamligi.",
      stats: [[80, "%", "Obyektlar 10 kun ichida ijaraga beriladi", "Toʻgʻri narx va samarali marketing natijasi."], [24, " soat", "ichida professional baholash", "Tezkor start, vaqt yoʻqotmasdan jarayon boshlanadi."], [5000, "+", "aktiv mijozlar bazasi", "Tayyor ijarachilar va keng auditoriya imkoniyati."]],
      steps: [["Obyektni tahlil qilish", "Ekspertimiz obyektning joylashuvi, holati, sharoitlari va bozor talabini chuqur oʻrganadi."], ["Ijara narxini aniqlash", "Bozor koʻrsatkichlari va hududiy talab asosida real va raqobatbardosh narx belgilanadi."], ["Reklama joylashtirish", "Obyekt professional foto va izoh bilan tayyorlanib, Telegram va Instagramda maqsadli auditoriyaga yetkaziladi."], ["Shartnoma qilish", "Ijarachi tanlangach, shartnoma qonunchilik talablariga muvofiq tuziladi va jarayon toʻliq nazorat qilinadi."], ["Toʻlov va uyni topshirish", "Toʻlovlar amalga oshiriladi, uy ijarachiga topshiriladi. Xizmat haqini ijarachi toʻlaydi. Keyingi ijara munosabatlarini tomonlar oʻzlari yuritadi."]],
      blocks: [["Kimlar uchun?", ["Uy egalari", "Ijaraga oluvchilar", "Tijorat obyekt egalari", "Chet elda yashovchi mulk egalari"]], ["Afzalliklar", ["Aktiv mijozlar bazasi", "Shaffof shartnoma", "Tezkor mijoz topish", "Toʻlov intizomi nazorati"]]],
      checklist: ["Taraflar va obyekt maʼlumotlari", "Oylik toʻlov va toʻlov sanasi", "Depozit va uning qaytarilish tartibi", "Kommunal xarajatlar kim tomonidan toʻlanishi", "Ijara muddati va uzaytirish shartlari", "Mebel va jihozlar roʻyxati (dalolatnoma)", "Shartnomani bekor qilish tartibi", "Taraflarning javobgarligi"],
      faq: [["Uyimni qancha muddatda ijaraga berish mumkin?", "Toʻgʻri narx va reklama bilan obyektlarning aksariyati 10 kun ichida ijaraga beriladi."], ["Ijarachilar qanday tanlanadi?", "Nomzodlar suhbat va tekshiruvdan oʻtkaziladi. Toʻlov intizomi va ishonchliligi baholanadi."], ["Xizmat haqi qanday hisoblanadi?", "Xizmat haqi kelishilgan holda belgilanadi va faqat ijarachi topilib, shartnoma tuzilgandan keyin toʻlanadi."], ["Mening ishtirokim qanchalik kerak boʻladi?", "Minimal. Koʻrsatuvlar, muzokaralar va hujjatlarni oʻzimiz olib boramiz — siz faqat yakuniy qarorni qabul qilasiz."], ["Shartnoma tuziladimi?", "Ha, har bir ijara yozma shartnoma va jihozlar dalolatnomasi bilan rasmiylashtiriladi."], ["Uy kalitini topshirmasam ham boʻladimi?", "Ha, kalitni oʻzingizda qoldirishingiz mumkin. Bunda har bir koʻrsatuv vaqtida oʻzingiz kelib, uyni mijozga ochib koʻrsatishingiz kerak boʻladi."], ["UY MARKET xizmat haqini kim toʻlaydi?", "Xizmat haqini uyni ijaraga olgan ijarachi toʻlaydi. Uy egasidan xizmat haqi olinmaydi. Toʻlov miqdori oldindan kelishiladi."], ["Shartnomadan keyin ijarachi bilan munosabatlarni kim yuritadi?", "Shartnoma tuzilgach, ijara toʻlovlari, uy holati va kundalik masalalarni uy egasi va ijarachi oʻzaro hal qiladi. UY MARKET keyingi ijara boshqaruvini olib bormaydi va taraflarning shartnomani bajarishi uchun javobgar emas. UY MARKET bilan alohida kelishilgan xizmatlar bundan mustasno."], ["Uy kalitini UY MARKET’ga topshirish qanchalik ishonchli?", "Kalitni qabul qilishdan oldin xodimimiz siz bilan birga uyga boradi. Uyning holati foto va videoga olinadi, mebel, texnika va boshqa buyumlar roʻyxatga kiritiladi. Uyni topshirishda uning holati dastlabki qaydlar bilan taqqoslanadi. Shu tariqa nimalar qabul qilingani va qanday holatda topshirilgani aniq boʻladi."]],
    },
    sotuv: {
      name: "Sotuv",
      t1: "Koʻchmas mulkingizni tez, xavfsiz", t2: "va maksimal narxda soting",
      sub: "Bozor tahlili, professional marketing va yuridik nazorat asosida bitimni muvaffaqiyatli yopamiz.",
      aboutLead: "Uy-joy sotuvi — bu shunchaki eʼlon joylashtirish emas.",
      aboutText: "Biz obyektni bozor tahlili asosida baholaymiz, strategik marketing ishlab chiqamiz va bitimni yuridik nazorat ostida xavfsiz yakunlaymiz.",
      stats: [[1200, "+", "Muvaffaqiyatli sotuv", "Bozordagi katta tajriba va ishonchli natija."], [75, "%", "Obyektlar 30 kun ichida sotiladi", "Toʻgʻri narx va kuchli marketing natijasi."], [100, "%", "Yuridik nazorat", "Har bir hujjat va bitim toʻliq tekshiruvdan oʻtadi."]],
      steps: [["Professional baholash", "Obyektning real bozor qiymati aniqlanadi. Narx, auditoriya va marketing rejasi belgilanadi."], ["Marketing", "Professional foto/video, Telegram, Instagram va YouTube orqali keng qamrov."], ["Muzokara", "Xaridor bilan narx va shartlar boʻyicha professional muzokara."], ["Yuridik rasmiylashtirish", "Bitim xavfsiz va qonuniy tarzda notarius orqali yakunlanadi."]],
      blocks: [["Nima uchun UY MARKET?", ["Samarali marketing", "Shaffof jarayon", "Professional baholash", "Xavfsiz bitim kafolati"]], ["Afzalliklar", ["Tezkor mijoz topish", "Aktiv xaridorlar bazasi", "Tajribali muzokarachilar", "Har bosqichda hisobot"]]],
      compare: [["Narx belgilash", "Taxminan, tanishlar maslahati bilan", "Bozor tahlili asosida real narx"], ["Reklama", "Bir-ikki eʼlon sayti", "Foto/video va 100k+ auditoriya"], ["Xaridorlar", "Tasodifiy qoʻngʻiroqlar", "Saralangan, toʻlovga tayyor xaridorlar"], ["Muzokara", "Narxni tushirishga majbur boʻlasiz", "Professional muzokarachi"], ["Hujjatlar", "Xatolar va kechikish xavfi", "Yuristlar toʻliq tekshiradi"], ["Muddat", "Bir necha oy", "Oʻrtacha 30 kun"]],
      faq: [["Uyim albatta sotiladimi?", "Buni 100% kafolatlab boʻlmaydi. Sotuv uyning narxi, joylashuvi, holati va xaridorlar talabiga bogʻliq. Biz shu omillarni oʻrganib, mos narx va reklama usulini tanlashga yordam beramiz."], ["Uyimni sotish uchun nimadan boshlayman?", "Bizga murojaat qilasiz. Mutaxassisimiz uyingizni koʻrib, hujjatlari va bozor narxini oʻrganadi. Keyin sotuv narxi va reklama rejasini siz bilan kelishadi."], ["Uyim qancha vaqtda sotiladi?", "Odatda 1 haftadan 1 oygacha vaqt ketadi. Bu muddat uyning narxi, holati, joylashuvi va xaridorlar talabiga qarab oʻzgarishi mumkin."], ["Xizmat haqi qancha boʻladi?", "Xizmat haqi va uni qachon toʻlashni oldindan kelishamiz. Kelishilgan summa yoki foiz shartnomada yoziladi."], ["Uyni xaridorga oʻzim koʻrsatishim kerakmi?", "Har safar qatnashishingiz shart emas. Vaqtni siz bilan kelishib, uyni agentimiz koʻrsatadi. Muhim muzokara va bitimda siz bilan birga ishlaymiz."], ["Qanday hujjatlar tayyorlayman?", "Avvalo kadastr hujjati va mulk huquqini tasdiqlovchi hujjat kerak. Qoʻshimcha hujjat talab qilinsa, mutaxassisimiz tushuntiradi."], ["Instagram uchun videoni kim oladi?", "Videoni professional videoperator oladi. Uy haqida UY MARKET brend vakili gapirib beradi."], ["Uy kalitini UY MARKET’ga topshirish qanchalik ishonchli?", "Kalitni qabul qilishdan oldin xodimimiz siz bilan birga uyga boradi. Uyning holati foto va videoga olinadi, mebel, texnika va boshqa buyumlar roʻyxatga kiritiladi. Uyni topshirishda uning holati dastlabki qaydlar bilan taqqoslanadi. Shu tariqa nimalar qabul qilingani va qanday holatda topshirilgani aniq boʻladi."]],
    },
    novostroyka: {
      name: "Novostroyka",
      t1: "Siz sifatli quring —", t2: "biz esa sotishni kafolatlaymiz.",
      sub: "Siz bino quring — biz kassani ishga tushiramiz.",
      aboutLead: "Uy-joy sotuvi — bu shunchaki eʼlon joylashtirish emas.",
      aboutText: "Biz obyektni bozor tahlili asosida baholaymiz, strategik marketing ishlab chiqamiz va bitimni yuridik nazorat ostida xavfsiz yakunlaymiz.",
      stats: [[1200, "+", "Muvaffaqiyatli sotuv", "Bozordagi katta tajriba va ishonchli natija."], [95, "%", "Obyektlar 30 kun ichida sotiladi", "Toʻgʻri narx va kuchli marketing natijasi."], [100, "%", "Yuridik nazorat", "Har bir hujjat va bitim toʻliq tekshiruvdan oʻtadi."]],
      steps: [["Audit", "Loyiha konsepsiyasi va joylashuvi tahlili, raqobatchilar narxi va taklifi, maqsadli auditoriya va sotuv voronkasi."], ["Strategiya", "Narx pozitsiyasi, toʻlov rejasi strategiyasi, marketing kanallari va sotuv rejasi."], ["Start", "Target va reklama, blogerlar bilan ishlash, call-center va CRM integratsiyasi, sotuv menejerlari."], ["Monitoring", "Haftalik KPI monitoring, konversiya tahlili, marketing ROI va strategiyani optimallashtirish."]],
      blocks: [["Quruvchilarning muammosi", ["Sotuv boʻlimi sust ishlaydi", "Marketing byudjeti yonadi, lekin lid sifatsiz", "Boʻsh qolgan kvartiralar — muzlatilgan kapital", "Pul oqimi uziladi"]], ["Bizning yechim", ["Bozor va narx strategiyasi", "Sotuv oqimini qurish", "Professional marketing (SMM, blogerlar)", "Call-center va lid qayta ishlash", "100% yuridik kuzatuv"]]],
      advantages: [["Tizimli sotuv boʻlimi", "Quruvchi uchun tayyor sotuv jamoasi: menejerlar, call-center va CRM — hammasi bir joyda."], ["Sifatli lidlar", "Har bir reklama soʻmi hisoblanadi: faqat haqiqiy xaridorlar sotuv boʻlimiga yetib boradi."], ["Shaffof hisobot", "Har hafta KPI, konversiya va marketing ROI boʻyicha aniq hisobot olasiz."], ["Tez aylanma", "Boʻsh kvartiralar tez sotiladi — kapital muzlab qolmaydi, qurilish toʻxtamaydi."]],
      faq: [["Qaysi bosqichdagi loyihalar bilan ishlaysiz?", "Qurilish boshlanishidan tortib topshirilgan binolargacha — har bir bosqich uchun alohida strategiya tuzamiz."], ["Sotuvni qancha vaqtda boshlaysiz?", "Audit va strategiyadan soʻng odatda 2–3 hafta ichida reklama va sotuv ishga tushadi."], ["Hamkorlik qanday hisoblanadi?", "Sotilgan kvartiralardan kelishilgan foiz asosida — natija boʻlmasa, xarajat ham boʻlmaydi."], ["Oʻz sotuv boʻlimimiz bor, siz kerakmisiz?", "Biz mavjud jamoangizni kuchaytiramiz: lid oqimi, skriptlar, CRM va nazorat tizimini quramiz."], ["Natijani qanday kuzatamiz?", "Har haftalik hisobot va CRM ga toʻgʻridan-toʻgʻri kirish orqali."]],
    },
    ipoteka: {
      name: "Ipoteka",
      t1: "Ipoteka orqali uy olishni", t2: "oson va tushunarli qilamiz",
      sub: "Banklar bilan hamkorlikda eng foydali kredit variantini tanlaymiz va hujjatlarni tayyorlaymiz.",
      aboutLead: "Ipoteka — bu murakkab hujjatlar va navbatlar degani emas.",
      aboutText: "Biz sizning daromadingiz va imkoniyatlaringizga mos bankni tanlaymiz, hujjatlarni tayyorlaymiz va kredit tasdiqlanguncha jarayonni kuzatib boramiz.",
      stats: [[10, "+", "Hamkor banklar", "Eng qulay foiz va shartlarni solishtiramiz."], [3, " kun", "ichida bank tanlovi", "Hujjatlaringiz asosida tezkor tahlil."], [100, "%", "Hujjatlar nazorati", "Har bir hujjat bankka topshirishdan oldin tekshiriladi."]],
      steps: [["Konsultatsiya", "Daromad, boshlangʻich toʻlov va maqsadingizni aniqlaymiz."], ["Bank tanlash", "Bir nechta bank takliflarini solishtirib, eng foydalisini tanlaymiz."], ["Hujjatlar", "Ariza va hujjatlar paketini tayyorlab, bankka topshiramiz."], ["Tasdiq va bitim", "Kredit tasdiqlangach, uy sotib olish bitimi xavfsiz rasmiylashtiriladi."]],
      blocks: [["Kimlar uchun?", ["Birinchi uyini olayotgan oilalar", "Yosh oilalar", "Ijarada yashashdan charchaganlar", "Yangi binodan uy olmoqchi boʻlganlar"]], ["Afzalliklar", ["Eng past foizni topish", "Hujjatlarni tayyorlash", "Bank bilan muloqot biz tomondan", "Uy tanlashda ham yordam"]]],
      faq: [["Boshlangʻich toʻlov qancha boʻlishi kerak?", "Odatda uy narxining 20–30 foizi. Aniq miqdor bank va dasturga bogʻliq."], ["Rasmiy daromad shartmi?", "Koʻpchilik banklar rasmiy daromadni talab qiladi, lekin muqobil variantlar ham bor — konsultatsiyada aniqlaymiz."], ["Kredit qancha vaqtda tasdiqlanadi?", "Hujjatlar toʻliq boʻlsa, odatda 1–3 hafta ichida."], ["Ikkilamchi bozordan uy olsa boʻladimi?", "Ha, ham yangi bino, ham ikkilamchi bozor uchun ipoteka dasturlari mavjud."], ["Xizmatingiz pullikmi?", "Birinchi konsultatsiya bepul. Keyingi xizmat narxi kelishilgan holda belgilanadi."]],
    },
    baholash: {
      name: "Baholash",
      t1: "Koʻchmas mulkingizning", t2: "haqiqiy bozor qiymatini biling",
      sub: "Real bitimlar va bozor maʼlumotlari asosida xolis va asoslangan baho beramiz.",
      aboutLead: "Toʻgʻri narx — tez va foydali bitimning asosi.",
      aboutText: "Mutaxassisimiz obyektni joyida koʻrib chiqadi, hududdagi real bitimlarni tahlil qiladi va narxni asoslab beradi. Sotish, ijara, meros yoki bank uchun baho kerak boʻlsa — yordam beramiz.",
      stats: [[24, " soat", "ichida xulosa", "Obyekt koʻrikdan soʻng bir kunda natija."], [1200, "+", "Bitimlar tajribasi", "Bahomiz real sotuvlarga asoslanadi."], [100, "%", "Xolis yondashuv", "Narx faktlar va bozor maʼlumotlari bilan asoslanadi."]],
      steps: [["Ariza", "Obyekt va baholash maqsadini aniqlaymiz."], ["Joyida koʻrik", "Mutaxassis obyektni koʻzdan kechiradi va oʻlchaydi."], ["Bozor tahlili", "Hududdagi oʻxshash obyektlar va real bitimlar solishtiriladi."], ["Xulosa", "Asoslangan narx va tavsiyalar bilan hisobot topshiriladi."]],
      blocks: [["Nima uchun UY MARKET?", ["Real bitimlar bazasi", "Joyida koʻrik", "Shaffof hisob-kitob", "Sotish strategiyasi bilan birga"]], ["Afzalliklar", ["Tezkor natija", "Tushunarli hisobot", "Narxni asoslash", "Bepul konsultatsiya"]]],
      factors: [["Joylashuv", "Tuman, transport, maktab va bogʻchalarga yaqinlik."], ["Maydon va planirovka", "Umumiy va yashash maydoni, xonalar joylashuvi."], ["Qavat va bino", "Qavat, bino turi, yoshi va lift mavjudligi."], ["Taʼmir holati", "Taʼmir sifati, kommunikatsiyalar va jihozlar."], ["Hujjatlar", "Egalik hujjatlari, taqiqlar va qayta rejalashtirish."], ["Bozor talabi", "Hududdagi talab, taklif va oxirgi bitimlar narxi."]],
      faq: [["Baholash qancha vaqt oladi?", "Obyekt koʻrigidan soʻng odatda 24 soat ichida xulosa beramiz."], ["Baho qanday aniqlanadi?", "Hududdagi oʻxshash obyektlar va real bitimlar narxi, obyekt holati va hujjatlari asosida."], ["Baholash pullikmi?", "Sotish yoki ijara uchun bizga murojaat qilsangiz, baholash bepul."], ["Bank uchun rasmiy baho berasizmi?", "Rasmiy (litsenziyali) baho kerak boʻlsa, hamkor baholovchilar orqali tayyorlab beramiz."], ["Masofadan baholash mumkinmi?", "Dastlabki taxminiy narxni rasm va hujjatlar asosida aytamiz, aniq baho uchun koʻrik kerak."]],
    },
    reklama: {
      name: "Reklama",
      t1: "Obyektlaringizni keng", t2: "auditoriyaga yetkazamiz",
      sub: "Telegram, Instagram, YouTube — kuchli reklama tizimi.",
      aboutLead: "Yaxshi obyekt koʻrinmasa — sotilmaydi.",
      aboutText: "Professional foto va video, sotuvchi matn va toʻgʻri tanlangan kanallar bilan obyektingizni haqiqiy xaridorlarga yetkazamiz.",
      stats: [[100, "k+", "Telegram kanal obunachilari soni", "Andijondagi eng katta koʻchmas mulk auditoriyasidan biri."], [5000, "+", "Oʻrtacha koʻrishlar soni", "Har bir eʼlon minglab odamlarga yetib boradi."], [40, "+", "Kunlik eʼlonlar soni", "Har kuni yangi obyektlar va faol auditoriya."]],
      steps: [["Obyekt tahlili", "Obyektning kuchli tomonlari va maqsadli auditoriya aniqlanadi."], ["Foto va video", "Professional suratga olish va qisqa video tayyorlanadi."], ["Joylashtirish", "Telegram, Instagram va YouTube da eʼlon chiqariladi."], ["Hisobot", "Koʻrishlar, qoʻngʻiroqlar va natija boʻyicha hisobot beriladi."]],
      blocks: [["Kimlar uchun?", ["Uy egalari", "Quruvchilar", "Rieltorlar", "Tijorat obyekt egalari"]], ["Afzalliklar", ["100k+ obunachi", "Professional kontent", "Maqsadli auditoriya", "Tez natija"]]],
      faq: [["Eʼlon qachon chiqadi?", "Toʻlov va materiallar tayyor boʻlgach, odatda shu kunning oʻzida."], ["Foto va videoni oʻzingiz olasizmi?", "Ha, professional suratga olishni tashkil qilamiz yoki tayyor materiallaringizni ishlatamiz."], ["Eʼlon qancha vaqt kanalda turadi?", "Eʼlon kanalda doimiy qoladi, takroriy chiqishlar paketga qarab belgilanadi."], ["Natijani qanday bilaman?", "Har bir eʼlon boʻyicha koʻrishlar va murojaatlar soni haqida hisobot beramiz."], ["Paketni oʻzgartirsa boʻladimi?", "Ha, ehtiyojingizga qarab individual paket tuzamiz."]],
    },
  },

  /* ======================= РУССКИЙ ======================= */
  ru: {
    ui: {
      crumb: "Услуги", consult: "Бесплатная консультация", how: "Как мы работаем", about: "Об услуге",
      step: "этап", faq: "Частые вопросы", partners: "Наши партнёры", legal: "Юридический контроль",
      verified: "Проверенные объекты", portfolio: "Портфолио", portfolioMeta: "Партнёр-застройщик · Андижан",
      advantages: "Наши преимущества", prev: "Назад", next: "Вперёд", perTimes: "раз", currency: "сум",
      order: "Заказать", pricingTitle: "Стоимость рекламы", pricingNote: "В отдельных случаях стоимость рекламы в Instagram и YouTube согласовывается индивидуально.",
      calcTitle: "Ипотечный калькулятор", calcPrice: "Стоимость жилья (USD)", calcOver: "Переплата по процентам", calcPerMonth: " / мес.", calcDown: "Первоначальный взнос", calcYears: "Срок", calcRate: "Годовая ставка",
      calcMonthly: "Ежемесячный платёж", calcLoan: "Сумма кредита", calcTotal: "Общая выплата", calcYearsUnit: "лет",
      calcNote: "Расчёт ориентировочный. Точные условия согласуете с банком и нашим специалистом.",
      compareTitle: "Продавать самому или с UY MARKET", compareSelf: "Самостоятельно", compareUs: "С UY MARKET",
      factorsTitle: "Что учитывается при оценке", checklistTitle: "Что входит в договор аренды",
    },
    ijara: {
      name: "Аренда",
      t1: "Надёжно сдавайте", t2: "или арендуйте недвижимость",
      sub: "Безопасная и быстрая аренда жилой и коммерческой недвижимости.",
      aboutLead: "Анализ рынка, определение цены, поиск клиента и заключение договора — под полным контролем.",
      aboutText: "Каждая сделка проходит через глубокий анализ, профессиональные переговоры и полный юридический контроль. Для нас главное — спокойствие клиента.",
      stats: [[80, "%", "Объектов сдаются за 10 дней", "Результат правильной цены и эффективного маркетинга."], [24, " часа", "на профессиональную оценку", "Быстрый старт без потери времени."], [5000, "+", "клиентов в активной базе", "Готовые арендаторы и широкая аудитория."]],
      steps: [["Анализ объекта", "Эксперт изучает расположение, состояние, условия объекта и спрос на рынке."], ["Определение цены", "Реальная и конкурентная цена на основе рыночных показателей и спроса в районе."], ["Размещение рекламы", "Объект с профессиональными фото и описанием продвигается в Telegram и Instagram."], ["Заключение договора", "После выбора арендатора договор составляется по закону, процесс полностью контролируется."]],
      blocks: [["Для кого?", ["Собственники жилья", "Арендаторы", "Владельцы коммерческих объектов", "Собственники, живущие за рубежом"]], ["Преимущества", ["Активная база клиентов", "Прозрачный договор", "Быстрый поиск арендатора", "Контроль платёжной дисциплины"]]],
      checklist: ["Данные сторон и объекта", "Сумма и дата ежемесячной оплаты", "Депозит и порядок его возврата", "Кто оплачивает коммунальные услуги", "Срок аренды и условия продления", "Опись мебели и техники (акт)", "Порядок расторжения договора", "Ответственность сторон"],
      faq: [["За какой срок можно сдать квартиру?", "При правильной цене и рекламе большинство объектов сдаются в течение 10 дней."], ["Как выбираются арендаторы?", "Кандидаты проходят собеседование и проверку. Оценивается платёжная дисциплина и надёжность."], ["Как рассчитывается стоимость услуг?", "Стоимость согласуется заранее и оплачивается только после заключения договора с арендатором."], ["Насколько нужно моё участие?", "Минимально. Показы, переговоры и документы ведём мы — вы принимаете только итоговое решение."], ["Заключается ли договор?", "Да, каждая аренда оформляется письменным договором и актом приёма имущества."]],
    },
    sotuv: {
      name: "Продажа",
      t1: "Продайте недвижимость быстро,", t2: "безопасно и по максимальной цене",
      sub: "Закрываем сделку на основе анализа рынка, профессионального маркетинга и юридического контроля.",
      aboutLead: "Продажа жилья — это не просто объявление.",
      aboutText: "Мы оцениваем объект на основе анализа рынка, разрабатываем маркетинговую стратегию и безопасно закрываем сделку под юридическим контролем.",
      stats: [[1200, "+", "Успешных продаж", "Большой опыт и надёжный результат."], [75, "%", "Объектов продаются за 30 дней", "Результат правильной цены и сильного маркетинга."], [100, "%", "Юридический контроль", "Каждый документ и сделка проходят полную проверку."]],
      steps: [["Профессиональная оценка", "Определяем реальную рыночную стоимость, аудиторию и маркетинговый план."], ["Маркетинг", "Профессиональные фото/видео, Telegram, Instagram и YouTube."], ["Переговоры", "Профессиональные переговоры с покупателем по цене и условиям."], ["Юридическое оформление", "Сделка безопасно и законно завершается у нотариуса."]],
      blocks: [["Почему UY MARKET?", ["Эффективный маркетинг", "Прозрачный процесс", "Профессиональная оценка", "Гарантия безопасной сделки"]], ["Преимущества", ["Быстрый поиск покупателя", "Активная база покупателей", "Опытные переговорщики", "Отчёт на каждом этапе"]]],
      compare: [["Цена", "Наугад, по советам знакомых", "Реальная цена по анализу рынка"], ["Реклама", "Пара сайтов объявлений", "Фото/видео и 100k+ аудитории"], ["Покупатели", "Случайные звонки", "Отобранные, готовые к оплате покупатели"], ["Переговоры", "Приходится снижать цену", "Профессиональный переговорщик"], ["Документы", "Риск ошибок и задержек", "Полная проверка юристами"], ["Срок", "Несколько месяцев", "В среднем 30 дней"]],
      faq: [["С чего начинается продажа?", "Специалист осматривает объект, предлагает цену по анализу рынка и составляет маркетинговый план."], ["За какой срок продаётся квартира?", "В зависимости от цены и стратегии реальный покупатель находится в среднем за 30 дней."], ["Как рассчитывается стоимость услуг?", "Это согласованный процент от суммы сделки, оплачивается только после её завершения."], ["Нужно ли мне присутствовать на показах?", "Нет. Показы проводит наш агент, вы встречаетесь только с серьёзными покупателями."], ["Какие документы нужны?", "Кадастровый документ и свидетельство о собственности. С остальным поможем."], ["Гарантирована ли продажа моего дома на 100%?", "Гарантировать продажу на 100% нельзя. Результат зависит от расположения и состояния дома, спроса покупателей и соответствия цены рынку. UY MARKET анализирует эти факторы и помогает выбрать цену и рекламную стратегию."], ["Кто готовит видео для Instagram?", "Видео снимает профессиональный видеоператор с участием представителя бренда UY MARKET."]],
    },
    novostroyka: {
      name: "Новостройки",
      t1: "Вы стройте качественно —", t2: "а продажи гарантируем мы.",
      sub: "Вы строите дом — мы запускаем кассу.",
      aboutLead: "Продажа жилья — это не просто объявление.",
      aboutText: "Мы оцениваем объект на основе анализа рынка, разрабатываем маркетинговую стратегию и безопасно закрываем сделку под юридическим контролем.",
      stats: [[1200, "+", "Успешных продаж", "Большой опыт и надёжный результат."], [95, "%", "Объектов продаются за 30 дней", "Результат правильной цены и сильного маркетинга."], [100, "%", "Юридический контроль", "Каждый документ и сделка проходят полную проверку."]],
      steps: [["Аудит", "Анализ концепции и локации, цен и предложений конкурентов, целевой аудитории и воронки продаж."], ["Стратегия", "Ценовое позиционирование, стратегия рассрочки, маркетинговые каналы и план продаж."], ["Старт", "Таргет и реклама, работа с блогерами, call-центр и CRM, менеджеры по продажам."], ["Мониторинг", "Еженедельный KPI, анализ конверсии, ROI маркетинга и оптимизация стратегии."]],
      blocks: [["Проблемы застройщиков", ["Отдел продаж работает слабо", "Маркетинговый бюджет сгорает, а лиды некачественные", "Пустые квартиры — замороженный капитал", "Прерывается денежный поток"]], ["Наше решение", ["Рыночная и ценовая стратегия", "Построение потока продаж", "Профессиональный маркетинг (SMM, блогеры)", "Call-центр и обработка лидов", "100% юридическое сопровождение"]]],
      advantages: [["Системный отдел продаж", "Готовая команда для застройщика: менеджеры, call-центр и CRM — всё в одном месте."], ["Качественные лиды", "Каждый сум рекламы на счету: до отдела продаж доходят только реальные покупатели."], ["Прозрачная отчётность", "Каждую неделю — отчёт по KPI, конверсии и ROI маркетинга."], ["Быстрый оборот", "Пустые квартиры продаются быстро — капитал не замораживается, стройка не стоит."]],
      faq: [["С проектами на какой стадии вы работаете?", "От начала строительства до сданных домов — для каждой стадии своя стратегия."], ["Когда стартуют продажи?", "После аудита и стратегии реклама и продажи обычно запускаются за 2–3 недели."], ["Как строится сотрудничество?", "Согласованный процент от проданных квартир — нет результата, нет расходов."], ["У нас есть свой отдел продаж — вы нужны?", "Мы усилим вашу команду: поток лидов, скрипты, CRM и система контроля."], ["Как отслеживать результат?", "Еженедельные отчёты и прямой доступ к CRM."]],
    },
    ipoteka: {
      name: "Ипотека",
      t1: "Сделаем покупку жилья в ипотеку", t2: "простой и понятной",
      sub: "Подберём самый выгодный кредит в партнёрстве с банками и подготовим документы.",
      aboutLead: "Ипотека — это не сложные документы и очереди.",
      aboutText: "Подбираем банк под ваш доход и возможности, готовим документы и сопровождаем процесс до одобрения кредита.",
      stats: [[10, "+", "Банков-партнёров", "Сравниваем самые выгодные ставки и условия."], [3, " дня", "на выбор банка", "Быстрый анализ по вашим документам."], [100, "%", "Контроль документов", "Каждый документ проверяется до подачи в банк."]],
      steps: [["Консультация", "Определяем доход, первоначальный взнос и вашу цель."], ["Выбор банка", "Сравниваем предложения нескольких банков и выбираем лучшее."], ["Документы", "Готовим заявку и пакет документов, подаём в банк."], ["Одобрение и сделка", "После одобрения сделка купли-продажи безопасно оформляется."]],
      blocks: [["Для кого?", ["Семьи, покупающие первое жильё", "Молодые семьи", "Те, кто устал от аренды", "Покупатели в новостройках"]], ["Преимущества", ["Поиск минимальной ставки", "Подготовка документов", "Общение с банком берём на себя", "Помощь в выборе квартиры"]]],
      faq: [["Каким должен быть первоначальный взнос?", "Обычно 20–30% стоимости жилья. Точная сумма зависит от банка и программы."], ["Нужен ли официальный доход?", "Большинство банков требуют официальный доход, но есть альтернативы — уточним на консультации."], ["Сколько длится одобрение?", "При полном пакете документов обычно 1–3 недели."], ["Можно ли купить на вторичном рынке?", "Да, ипотечные программы есть и для новостроек, и для вторичного жилья."], ["Ваша услуга платная?", "Первая консультация бесплатная. Стоимость дальнейших услуг — по договорённости."]],
    },
    baholash: {
      name: "Оценка",
      t1: "Узнайте реальную", t2: "рыночную стоимость недвижимости",
      sub: "Объективная и обоснованная оценка на основе реальных сделок и рыночных данных.",
      aboutLead: "Правильная цена — основа быстрой и выгодной сделки.",
      aboutText: "Специалист осматривает объект на месте, анализирует реальные сделки в районе и обосновывает цену. Нужна оценка для продажи, аренды, наследства или банка — поможем.",
      stats: [[24, " часа", "на заключение", "Результат в течение дня после осмотра."], [1200, "+", "Опыт сделок", "Оценка основана на реальных продажах."], [100, "%", "Объективный подход", "Цена подтверждена фактами и данными рынка."]],
      steps: [["Заявка", "Определяем объект и цель оценки."], ["Осмотр на месте", "Специалист осматривает и измеряет объект."], ["Анализ рынка", "Сравниваем похожие объекты и реальные сделки в районе."], ["Заключение", "Передаём отчёт с обоснованной ценой и рекомендациями."]],
      blocks: [["Почему UY MARKET?", ["База реальных сделок", "Осмотр на месте", "Прозрачный расчёт", "Вместе со стратегией продажи"]], ["Преимущества", ["Быстрый результат", "Понятный отчёт", "Обоснование цены", "Бесплатная консультация"]]],
      factors: [["Расположение", "Район, транспорт, близость школ и детских садов."], ["Площадь и планировка", "Общая и жилая площадь, расположение комнат."], ["Этаж и дом", "Этаж, тип дома, возраст и наличие лифта."], ["Состояние ремонта", "Качество ремонта, коммуникации и техника."], ["Документы", "Правоустанавливающие документы, запреты и перепланировка."], ["Спрос на рынке", "Спрос и предложение в районе, цены последних сделок."]],
      faq: [["Сколько времени занимает оценка?", "Обычно заключение готово в течение 24 часов после осмотра."], ["Как определяется цена?", "По ценам похожих объектов и реальных сделок в районе, состоянию и документам объекта."], ["Оценка платная?", "Если вы продаёте или сдаёте объект через нас, оценка бесплатная."], ["Делаете официальную оценку для банка?", "Если нужна официальная (лицензированная) оценка, подготовим через партнёров-оценщиков."], ["Можно ли оценить удалённо?", "Предварительную цену назовём по фото и документам, для точной оценки нужен осмотр."]],
    },
    reklama: {
      name: "Реклама",
      t1: "Донесём ваши объекты", t2: "до широкой аудитории",
      sub: "Telegram, Instagram, YouTube — мощная рекламная система.",
      aboutLead: "Хороший объект, которого не видно, не продаётся.",
      aboutText: "Профессиональные фото и видео, продающий текст и правильно подобранные каналы донесут ваш объект до реальных покупателей.",
      stats: [[100, "k+", "Подписчиков Telegram-канала", "Одна из крупнейших аудиторий недвижимости в Андижане."], [5000, "+", "Средний охват", "Каждое объявление видят тысячи людей."], [40, "+", "Объявлений в день", "Новые объекты каждый день и активная аудитория."]],
      steps: [["Анализ объекта", "Определяем сильные стороны объекта и целевую аудиторию."], ["Фото и видео", "Профессиональная съёмка и короткое видео."], ["Размещение", "Публикация в Telegram, Instagram и YouTube."], ["Отчёт", "Отчёт по просмотрам, звонкам и результату."]],
      blocks: [["Для кого?", ["Собственники жилья", "Застройщики", "Риелторы", "Владельцы коммерческих объектов"]], ["Преимущества", ["100k+ подписчиков", "Профессиональный контент", "Целевая аудитория", "Быстрый результат"]]],
      faq: [["Когда выйдет объявление?", "Обычно в тот же день после оплаты и подготовки материалов."], ["Вы сами делаете фото и видео?", "Да, организуем профессиональную съёмку или используем ваши готовые материалы."], ["Сколько объявление висит в канале?", "Объявление остаётся в канале постоянно, повторные публикации — по пакету."], ["Как узнать результат?", "Даём отчёт по просмотрам и обращениям по каждому объявлению."], ["Можно изменить пакет?", "Да, составим индивидуальный пакет под ваши задачи."]],
    },
  },

  /* ======================= ENGLISH ======================= */
  en: {
    ui: {
      crumb: "Services", consult: "Free consultation", how: "How we work", about: "About the service",
      step: "step", faq: "Frequently asked questions", partners: "Our partners", legal: "Legal oversight",
      verified: "Verified listings", portfolio: "Portfolio", portfolioMeta: "Partner developer · Andijan",
      advantages: "Our advantages", prev: "Previous", next: "Next", perTimes: "×", currency: "UZS",
      order: "Order", pricingTitle: "Advertising prices", pricingNote: "In some cases, Instagram and YouTube advertising rates are agreed individually.",
      calcTitle: "Mortgage calculator", calcPrice: "Home price (USD)", calcOver: "Interest paid", calcPerMonth: " / mo", calcDown: "Down payment", calcYears: "Term", calcRate: "Annual rate",
      calcMonthly: "Monthly payment", calcLoan: "Loan amount", calcTotal: "Total payment", calcYearsUnit: "years",
      calcNote: "This is an estimate. Final terms are agreed with the bank and our specialist.",
      compareTitle: "Selling yourself vs with UY MARKET", compareSelf: "On your own", compareUs: "With UY MARKET",
      factorsTitle: "What a valuation takes into account", checklistTitle: "What a rental contract includes",
    },
    ijara: {
      name: "Rental",
      t1: "Rent out or rent", t2: "property with confidence",
      sub: "Safe and fast rental of residential and commercial property.",
      aboutLead: "Market analysis, pricing, finding tenants and signing the contract — fully under control.",
      aboutText: "Every deal is built on in-depth analysis, professional negotiation and full legal oversight. Our top priority is our client's peace of mind.",
      stats: [[80, "%", "Of listings rented within 10 days", "The result of the right price and effective marketing."], [24, " h", "to a professional valuation", "A fast start with no time wasted."], [5000, "+", "clients in our active base", "Ready tenants and a wide audience."]],
      steps: [["Property analysis", "Our expert studies the location, condition, amenities and market demand."], ["Setting the rent", "A realistic, competitive price based on market data and local demand."], ["Advertising", "The listing gets professional photos and copy and is promoted on Telegram and Instagram."], ["Signing the contract", "Once a tenant is chosen, the contract is drawn up by law and the process is fully supervised."]],
      blocks: [["Who is it for?", ["Homeowners", "Tenants", "Commercial property owners", "Owners living abroad"]], ["Advantages", ["Active client base", "Transparent contract", "Fast tenant search", "Payment discipline checks"]]],
      checklist: ["Party and property details", "Monthly rent and due date", "Deposit and how it is returned", "Who pays the utilities", "Rental term and renewal terms", "Furniture and appliance inventory", "Termination procedure", "Responsibilities of each party"],
      faq: [["How fast can I rent out my home?", "With the right price and advertising, most listings are rented within 10 days."], ["How are tenants selected?", "Candidates are interviewed and checked. Payment discipline and reliability are assessed."], ["How is the fee calculated?", "The fee is agreed in advance and paid only after a contract with the tenant is signed."], ["How involved do I need to be?", "Minimally. We handle viewings, negotiations and documents — you only make the final decision."], ["Is a contract signed?", "Yes, every rental is formalised with a written contract and an inventory report."]],
    },
    sotuv: {
      name: "Sales",
      t1: "Sell your property fast, safely", t2: "and at the best price",
      sub: "We close the deal with market analysis, professional marketing and legal oversight.",
      aboutLead: "Selling a home is more than posting an ad.",
      aboutText: "We value the property based on market analysis, build a marketing strategy and close the deal safely under legal oversight.",
      stats: [[1200, "+", "Successful sales", "Extensive experience and reliable results."], [75, "%", "Of listings sold within 30 days", "The result of the right price and strong marketing."], [100, "%", "Legal oversight", "Every document and deal is fully checked."]],
      steps: [["Professional valuation", "We set the real market value, audience and marketing plan."], ["Marketing", "Professional photo/video, Telegram, Instagram and YouTube."], ["Negotiation", "Professional negotiation with the buyer on price and terms."], ["Legal closing", "The deal is closed safely and legally with a notary."]],
      blocks: [["Why UY MARKET?", ["Effective marketing", "Transparent process", "Professional valuation", "Safe deal guarantee"]], ["Advantages", ["Fast buyer search", "Active buyer base", "Experienced negotiators", "Reports at every stage"]]],
      compare: [["Pricing", "A guess, based on friends' advice", "A real price based on market analysis"], ["Advertising", "A couple of listing sites", "Photo/video and a 100k+ audience"], ["Buyers", "Random calls", "Pre-qualified, ready-to-pay buyers"], ["Negotiation", "You end up lowering the price", "A professional negotiator"], ["Documents", "Risk of errors and delays", "Fully checked by lawyers"], ["Time", "Several months", "30 days on average"]],
      faq: [["How does the sale start?", "Our specialist inspects the property, proposes a price based on market analysis and drafts a marketing plan."], ["How long does it take to sell?", "Depending on price and strategy, a real buyer is found in about 30 days on average."], ["How is the fee calculated?", "It's an agreed percentage of the deal, paid only after closing."], ["Do I need to attend viewings?", "No. Our agent handles viewings; you only meet serious buyers."], ["What documents are needed?", "Cadastral document and ownership certificate. We help with the rest."], ["Is the sale of my home 100% guaranteed?", "A sale cannot be guaranteed 100%. The result depends on the home’s location and condition, buyer demand, and how well the asking price matches the market. UY MARKET analyses these factors and helps choose the price and advertising strategy."], ["Who produces the Instagram video?", "A professional camera operator films the video with a UY MARKET brand representative."]],
    },
    novostroyka: {
      name: "New builds",
      t1: "You build with quality —", t2: "we guarantee the sales.",
      sub: "You build the house — we start the cash flow.",
      aboutLead: "Selling homes is more than posting ads.",
      aboutText: "We value the project based on market analysis, build a marketing strategy and close every deal safely under legal oversight.",
      stats: [[1200, "+", "Successful sales", "Extensive experience and reliable results."], [95, "%", "Of units sold within 30 days", "The result of the right price and strong marketing."], [100, "%", "Legal oversight", "Every document and deal is fully checked."]],
      steps: [["Audit", "Concept and location analysis, competitor pricing, target audience and sales funnel."], ["Strategy", "Price positioning, instalment strategy, marketing channels and sales plan."], ["Launch", "Targeting and ads, bloggers, call centre and CRM, sales managers."], ["Monitoring", "Weekly KPIs, conversion analysis, marketing ROI and strategy optimisation."]],
      blocks: [["Developers' pain points", ["The sales team underperforms", "Marketing budget burns, leads are poor", "Unsold units — frozen capital", "Cash flow breaks"]], ["Our solution", ["Market and pricing strategy", "Building a sales pipeline", "Professional marketing (SMM, bloggers)", "Call centre and lead handling", "100% legal support"]]],
      advantages: [["A systemised sales team", "A ready team for developers: managers, call centre and CRM — all in one place."], ["Quality leads", "Every ad dollar counts: only real buyers reach the sales team."], ["Transparent reporting", "A weekly report on KPIs, conversion and marketing ROI."], ["Fast turnover", "Units sell fast — capital isn't frozen and construction keeps moving."]],
      faq: [["At what stage do you take on projects?", "From groundbreaking to completed buildings — each stage gets its own strategy."], ["How soon do sales start?", "After the audit and strategy, ads and sales usually launch within 2–3 weeks."], ["How does the partnership work?", "An agreed percentage of units sold — no results, no cost."], ["We have our own sales team — do we need you?", "We strengthen your team: lead flow, scripts, CRM and a control system."], ["How do we track results?", "Weekly reports and direct CRM access."]],
    },
    ipoteka: {
      name: "Mortgage",
      t1: "We make buying a home with a mortgage", t2: "simple and clear",
      sub: "We find the best loan with our partner banks and prepare all the documents.",
      aboutLead: "A mortgage doesn't have to mean paperwork and queues.",
      aboutText: "We match a bank to your income and options, prepare the documents and guide the process until the loan is approved.",
      stats: [[10, "+", "Partner banks", "We compare the best rates and terms."], [3, " days", "to choose a bank", "A fast review of your documents."], [100, "%", "Document control", "Every document is checked before it goes to the bank."]],
      steps: [["Consultation", "We clarify your income, down payment and goal."], ["Choosing a bank", "We compare several offers and pick the best one."], ["Documents", "We prepare the application and document pack and submit it."], ["Approval and deal", "Once approved, the purchase is closed safely."]],
      blocks: [["Who is it for?", ["Families buying their first home", "Young families", "Those tired of renting", "Buyers of new-build homes"]], ["Advantages", ["Finding the lowest rate", "Document preparation", "We talk to the bank for you", "Help choosing the home too"]]],
      faq: [["How big should the down payment be?", "Usually 20–30% of the home price. The exact amount depends on the bank and programme."], ["Do I need official income?", "Most banks require it, but there are alternatives — we'll check in the consultation."], ["How long does approval take?", "With a complete document pack, usually 1–3 weeks."], ["Can I buy on the resale market?", "Yes, there are mortgage programmes for both new builds and resale homes."], ["Is your service paid?", "The first consultation is free. Further service fees are agreed individually."]],
    },
    baholash: {
      name: "Valuation",
      t1: "Find out the real", t2: "market value of your property",
      sub: "An objective, well-founded valuation based on real deals and market data.",
      aboutLead: "The right price is the foundation of a fast, profitable deal.",
      aboutText: "Our specialist inspects the property, analyses real deals in the area and justifies the price. Need a valuation for a sale, rental, inheritance or bank? We can help.",
      stats: [[24, " h", "to a conclusion", "Results within a day of the inspection."], [1200, "+", "Deals of experience", "Our valuation is based on real sales."], [100, "%", "Objective approach", "The price is backed by facts and market data."]],
      steps: [["Request", "We define the property and the purpose of the valuation."], ["On-site inspection", "A specialist inspects and measures the property."], ["Market analysis", "We compare similar properties and real deals in the area."], ["Report", "You receive a report with a justified price and recommendations."]],
      blocks: [["Why UY MARKET?", ["A base of real deals", "On-site inspection", "Transparent calculation", "Comes with a sales strategy"]], ["Advantages", ["Fast results", "A clear report", "A justified price", "Free consultation"]]],
      factors: [["Location", "District, transport, proximity to schools and kindergartens."], ["Area and layout", "Total and living area, room layout."], ["Floor and building", "Floor, building type, age and lift."], ["Renovation", "Quality of renovation, utilities and appliances."], ["Documents", "Title documents, encumbrances and replanning."], ["Market demand", "Local supply and demand and recent sale prices."]],
      faq: [["How long does a valuation take?", "Usually we deliver the conclusion within 24 hours of the inspection."], ["How is the price determined?", "From prices of similar properties and real local deals, plus the property's condition and documents."], ["Is the valuation paid?", "It's free if you sell or rent the property through us."], ["Do you provide official valuations for banks?", "If you need an official (licensed) valuation, we prepare it through partner appraisers."], ["Can you value remotely?", "We can give an estimate from photos and documents; an accurate valuation needs an inspection."]],
    },
    reklama: {
      name: "Advertising",
      t1: "We bring your listings", t2: "to a wide audience",
      sub: "Telegram, Instagram, YouTube — a powerful advertising system.",
      aboutLead: "A great property nobody sees doesn't sell.",
      aboutText: "Professional photos and video, persuasive copy and the right channels put your property in front of real buyers.",
      stats: [[100, "k+", "Telegram channel subscribers", "One of the largest real estate audiences in Andijan."], [5000, "+", "Average views", "Every listing reaches thousands of people."], [40, "+", "Listings per day", "New properties daily and an active audience."]],
      steps: [["Property analysis", "We find the property's strengths and target audience."], ["Photo and video", "Professional shoot and a short video."], ["Publishing", "Posting on Telegram, Instagram and YouTube."], ["Report", "A report on views, calls and results."]],
      blocks: [["Who is it for?", ["Homeowners", "Developers", "Realtors", "Commercial property owners"]], ["Advantages", ["100k+ subscribers", "Professional content", "Targeted audience", "Fast results"]]],
      faq: [["When will the listing go live?", "Usually the same day once payment and materials are ready."], ["Do you shoot the photos and video?", "Yes, we organise a professional shoot or use your existing materials."], ["How long does a listing stay in the channel?", "It stays permanently; repeat posts depend on the package."], ["How will I see results?", "We report views and enquiries for every listing."], ["Can I change the package?", "Yes, we'll build a custom package for your needs."]],
    },
  },
};
